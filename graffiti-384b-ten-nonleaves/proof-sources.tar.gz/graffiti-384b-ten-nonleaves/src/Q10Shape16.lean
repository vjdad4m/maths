import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape16T12 : Tree := (.tip (.cover 0 1 2 3 6))
private theorem q10Shape16T12OK : fastTreeOK (forms 16) 0 239067136 q10Shape16T12=true := by decide

private def q10Shape16T14 : Tree := (.split 23 (.tip (.cover 0 1 2 3 9)) (.split 24 (.split 4 (.split 1 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 1 3 4 5 6))) (.split 1 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 5 6)))) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))))
private theorem q10Shape16T14OK : fastTreeOK (forms 16) 2097152 241164288 q10Shape16T14=true := by decide

private def q10Shape16T15 : Tree := (.split 23 (.split 24 (.split 4 (.split 5 (.split 1 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 1 3 4 5 6))) (.split 1 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 5 6)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T15OK : fastTreeOK (forms 16) 6291456 236969984 q10Shape16T15=true := by decide

private def q10Shape16T13 : Tree := .split 22 q10Shape16T14 q10Shape16T15
private theorem q10Shape16T13OK : fastTreeOK (forms 16) 2097152 236969984 q10Shape16T13=true := by
  change (fastTreeOK (forms 16) 2097152 (236969984 ||| 2^22) q10Shape16T14 &&
    fastTreeOK (forms 16) (2097152 ||| 2^22) 236969984 q10Shape16T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T14OK,q10Shape16T15OK⟩

private def q10Shape16T11 : Tree := .split 21 q10Shape16T12 q10Shape16T13
private theorem q10Shape16T11OK : fastTreeOK (forms 16) 0 236969984 q10Shape16T11=true := by
  change (fastTreeOK (forms 16) 0 (236969984 ||| 2^21) q10Shape16T12 &&
    fastTreeOK (forms 16) (0 ||| 2^21) 236969984 q10Shape16T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T12OK,q10Shape16T13OK⟩

private def q10Shape16T18 : Tree := (.split 24 (.tip (.cover 0 1 2 3 8)) (.split 23 (.split 4 (.split 1 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 1 3 4 5 6))) (.split 1 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 5 6)))) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))))
private theorem q10Shape16T18OK : fastTreeOK (forms 16) 1048576 242212864 q10Shape16T18=true := by decide

private def q10Shape16T19 : Tree := (.split 24 (.split 23 (.split 4 (.split 5 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T19OK : fastTreeOK (forms 16) 5242880 238018560 q10Shape16T19=true := by decide

private def q10Shape16T17 : Tree := .split 22 q10Shape16T18 q10Shape16T19
private theorem q10Shape16T17OK : fastTreeOK (forms 16) 1048576 238018560 q10Shape16T17=true := by
  change (fastTreeOK (forms 16) 1048576 (238018560 ||| 2^22) q10Shape16T18 &&
    fastTreeOK (forms 16) (1048576 ||| 2^22) 238018560 q10Shape16T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T18OK,q10Shape16T19OK⟩

private def q10Shape16T20 : Tree := (.split 22 (.split 23 (.split 24 (.tip (.cover 0 1 2 3 5)) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T20OK : fastTreeOK (forms 16) 3145728 235921408 q10Shape16T20=true := by decide

private def q10Shape16T16 : Tree := .split 21 q10Shape16T17 q10Shape16T20
private theorem q10Shape16T16OK : fastTreeOK (forms 16) 1048576 235921408 q10Shape16T16=true := by
  change (fastTreeOK (forms 16) 1048576 (235921408 ||| 2^21) q10Shape16T17 &&
    fastTreeOK (forms 16) (1048576 ||| 2^21) 235921408 q10Shape16T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T17OK,q10Shape16T20OK⟩

private def q10Shape16T10 : Tree := .split 20 q10Shape16T11 q10Shape16T16
private theorem q10Shape16T10OK : fastTreeOK (forms 16) 0 235921408 q10Shape16T10=true := by
  change (fastTreeOK (forms 16) 0 (235921408 ||| 2^20) q10Shape16T11 &&
    fastTreeOK (forms 16) (0 ||| 2^20) 235921408 q10Shape16T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T11OK,q10Shape16T16OK⟩

private def q10Shape16T25 : Tree := (.split 24 (.tip (.cover 0 1 2 3 5)) (.split 4 (.split 5 (.split 1 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 1 3 4 5 6))) (.split 1 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 5 6)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))))
private theorem q10Shape16T25OK : fastTreeOK (forms 16) 524288 251125760 q10Shape16T25=true := by decide

private def q10Shape16T26 : Tree := (.split 24 (.split 4 (.split 5 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T26OK : fastTreeOK (forms 16) 8912896 242737152 q10Shape16T26=true := by decide

private def q10Shape16T24 : Tree := .split 23 q10Shape16T25 q10Shape16T26
private theorem q10Shape16T24OK : fastTreeOK (forms 16) 524288 242737152 q10Shape16T24=true := by
  change (fastTreeOK (forms 16) 524288 (242737152 ||| 2^23) q10Shape16T25 &&
    fastTreeOK (forms 16) (524288 ||| 2^23) 242737152 q10Shape16T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T25OK,q10Shape16T26OK⟩

private def q10Shape16T27 : Tree := (.split 2 (.split 23 (.split 24 (.tip (.cover 0 1 2 3 7)) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.split 24 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T27OK : fastTreeOK (forms 16) 4718592 238542848 q10Shape16T27=true := by decide

private def q10Shape16T23 : Tree := .split 22 q10Shape16T24 q10Shape16T27
private theorem q10Shape16T23OK : fastTreeOK (forms 16) 524288 238542848 q10Shape16T23=true := by
  change (fastTreeOK (forms 16) 524288 (238542848 ||| 2^22) q10Shape16T24 &&
    fastTreeOK (forms 16) (524288 ||| 2^22) 238542848 q10Shape16T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T24OK,q10Shape16T27OK⟩

private def q10Shape16T28 : Tree := (.split 23 (.split 22 (.split 24 (.tip (.cover 0 1 2 3 5)) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T28OK : fastTreeOK (forms 16) 2621440 236445696 q10Shape16T28=true := by decide

private def q10Shape16T22 : Tree := .split 21 q10Shape16T23 q10Shape16T28
private theorem q10Shape16T22OK : fastTreeOK (forms 16) 524288 236445696 q10Shape16T22=true := by
  change (fastTreeOK (forms 16) 524288 (236445696 ||| 2^21) q10Shape16T23 &&
    fastTreeOK (forms 16) (524288 ||| 2^21) 236445696 q10Shape16T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T23OK,q10Shape16T28OK⟩

private def q10Shape16T29 : Tree := (.split 21 (.split 24 (.split 22 (.split 23 (.tip (.cover 0 1 2 3 5)) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T29OK : fastTreeOK (forms 16) 1572864 235397120 q10Shape16T29=true := by decide

private def q10Shape16T21 : Tree := .split 20 q10Shape16T22 q10Shape16T29
private theorem q10Shape16T21OK : fastTreeOK (forms 16) 524288 235397120 q10Shape16T21=true := by
  change (fastTreeOK (forms 16) 524288 (235397120 ||| 2^20) q10Shape16T22 &&
    fastTreeOK (forms 16) (524288 ||| 2^20) 235397120 q10Shape16T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T22OK,q10Shape16T29OK⟩

private def q10Shape16T9 : Tree := .split 19 q10Shape16T10 q10Shape16T21
private theorem q10Shape16T9OK : fastTreeOK (forms 16) 0 235397120 q10Shape16T9=true := by
  change (fastTreeOK (forms 16) 0 (235397120 ||| 2^19) q10Shape16T10 &&
    fastTreeOK (forms 16) (0 ||| 2^19) 235397120 q10Shape16T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T10OK,q10Shape16T21OK⟩

private def q10Shape16T34 : Tree := (.split 23 (.tip (.cover 0 1 2 3 9)) (.split 24 (.split 4 (.split 2 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 1 3 4 5 6))) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 6)))) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))))
private theorem q10Shape16T34OK : fastTreeOK (forms 16) 131072 243130368 q10Shape16T34=true := by decide

private def q10Shape16T35 : Tree := (.split 23 (.split 24 (.split 4 (.split 5 (.split 2 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 1 3 4 5 6))) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 6)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T35OK : fastTreeOK (forms 16) 4325376 238936064 q10Shape16T35=true := by decide

private def q10Shape16T33 : Tree := .split 22 q10Shape16T34 q10Shape16T35
private theorem q10Shape16T33OK : fastTreeOK (forms 16) 131072 238936064 q10Shape16T33=true := by
  change (fastTreeOK (forms 16) 131072 (238936064 ||| 2^22) q10Shape16T34 &&
    fastTreeOK (forms 16) (131072 ||| 2^22) 238936064 q10Shape16T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T34OK,q10Shape16T35OK⟩

private def q10Shape16T36 : Tree := (.split 22 (.split 23 (.tip (.cover 0 1 2 3 9)) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape16T36OK : fastTreeOK (forms 16) 2228224 236838912 q10Shape16T36=true := by decide

private def q10Shape16T32 : Tree := .split 21 q10Shape16T33 q10Shape16T36
private theorem q10Shape16T32OK : fastTreeOK (forms 16) 131072 236838912 q10Shape16T32=true := by
  change (fastTreeOK (forms 16) 131072 (236838912 ||| 2^21) q10Shape16T33 &&
    fastTreeOK (forms 16) (131072 ||| 2^21) 236838912 q10Shape16T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T33OK,q10Shape16T36OK⟩

private def q10Shape16T37 : Tree := (.split 22 (.split 23 (.split 24 (.split 21 (.split 4 (.split 3 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 1 3 4 5 6))) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 5)))) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T37OK : fastTreeOK (forms 16) 1179648 235790336 q10Shape16T37=true := by decide

private def q10Shape16T31 : Tree := .split 20 q10Shape16T32 q10Shape16T37
private theorem q10Shape16T31OK : fastTreeOK (forms 16) 131072 235790336 q10Shape16T31=true := by
  change (fastTreeOK (forms 16) 131072 (235790336 ||| 2^20) q10Shape16T32 &&
    fastTreeOK (forms 16) (131072 ||| 2^20) 235790336 q10Shape16T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T32OK,q10Shape16T37OK⟩

private def q10Shape16T38 : Tree := (.split 20 (.split 22 (.split 23 (.split 24 (.split 21 (.split 4 (.split 5 (.split 3 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 1 3 4 5 6))) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 5)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T38OK : fastTreeOK (forms 16) 655360 235266048 q10Shape16T38=true := by decide

private def q10Shape16T30 : Tree := .split 19 q10Shape16T31 q10Shape16T38
private theorem q10Shape16T30OK : fastTreeOK (forms 16) 131072 235266048 q10Shape16T30=true := by
  change (fastTreeOK (forms 16) 131072 (235266048 ||| 2^19) q10Shape16T31 &&
    fastTreeOK (forms 16) (131072 ||| 2^19) 235266048 q10Shape16T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T31OK,q10Shape16T38OK⟩

private def q10Shape16T8 : Tree := .split 17 q10Shape16T9 q10Shape16T30
private theorem q10Shape16T8OK : fastTreeOK (forms 16) 0 235266048 q10Shape16T8=true := by
  change (fastTreeOK (forms 16) 0 (235266048 ||| 2^17) q10Shape16T9 &&
    fastTreeOK (forms 16) (0 ||| 2^17) 235266048 q10Shape16T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T9OK,q10Shape16T30OK⟩

private def q10Shape16T44 : Tree := (.split 24 (.tip (.cover 0 1 2 3 8)) (.split 23 (.split 4 (.split 2 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 1 3 4 5 6))) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 6)))) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))))
private theorem q10Shape16T44OK : fastTreeOK (forms 16) 65536 243195904 q10Shape16T44=true := by decide

private def q10Shape16T45 : Tree := (.split 24 (.split 23 (.split 4 (.split 5 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T45OK : fastTreeOK (forms 16) 4259840 239001600 q10Shape16T45=true := by decide

private def q10Shape16T43 : Tree := .split 22 q10Shape16T44 q10Shape16T45
private theorem q10Shape16T43OK : fastTreeOK (forms 16) 65536 239001600 q10Shape16T43=true := by
  change (fastTreeOK (forms 16) 65536 (239001600 ||| 2^22) q10Shape16T44 &&
    fastTreeOK (forms 16) (65536 ||| 2^22) 239001600 q10Shape16T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T44OK,q10Shape16T45OK⟩

private def q10Shape16T46 : Tree := (.split 22 (.split 23 (.split 24 (.split 4 (.split 3 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 1 3 4 5 6))) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T46OK : fastTreeOK (forms 16) 2162688 236904448 q10Shape16T46=true := by decide

private def q10Shape16T42 : Tree := .split 21 q10Shape16T43 q10Shape16T46
private theorem q10Shape16T42OK : fastTreeOK (forms 16) 65536 236904448 q10Shape16T42=true := by
  change (fastTreeOK (forms 16) 65536 (236904448 ||| 2^21) q10Shape16T43 &&
    fastTreeOK (forms 16) (65536 ||| 2^21) 236904448 q10Shape16T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T43OK,q10Shape16T46OK⟩

private def q10Shape16T47 : Tree := (.split 22 (.split 23 (.split 24 (.split 21 (.tip (.cover 0 1 2 3 8)) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 7 8 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape16T47OK : fastTreeOK (forms 16) 1114112 235855872 q10Shape16T47=true := by decide

private def q10Shape16T41 : Tree := .split 20 q10Shape16T42 q10Shape16T47
private theorem q10Shape16T41OK : fastTreeOK (forms 16) 65536 235855872 q10Shape16T41=true := by
  change (fastTreeOK (forms 16) 65536 (235855872 ||| 2^20) q10Shape16T42 &&
    fastTreeOK (forms 16) (65536 ||| 2^20) 235855872 q10Shape16T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T42OK,q10Shape16T47OK⟩

private def q10Shape16T49 : Tree := (.split 22 (.split 23 (.split 24 (.split 20 (.split 4 (.split 5 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 7 9)))
private theorem q10Shape16T49OK : fastTreeOK (forms 16) 589824 237428736 q10Shape16T49=true := by decide

private def q10Shape16T50 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T50OK : fastTreeOK (forms 16) 2686976 235331584 q10Shape16T50=true := by decide

private def q10Shape16T48 : Tree := .split 21 q10Shape16T49 q10Shape16T50
private theorem q10Shape16T48OK : fastTreeOK (forms 16) 589824 235331584 q10Shape16T48=true := by
  change (fastTreeOK (forms 16) 589824 (235331584 ||| 2^21) q10Shape16T49 &&
    fastTreeOK (forms 16) (589824 ||| 2^21) 235331584 q10Shape16T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T49OK,q10Shape16T50OK⟩

private def q10Shape16T40 : Tree := .split 19 q10Shape16T41 q10Shape16T48
private theorem q10Shape16T40OK : fastTreeOK (forms 16) 65536 235331584 q10Shape16T40=true := by
  change (fastTreeOK (forms 16) 65536 (235331584 ||| 2^19) q10Shape16T41 &&
    fastTreeOK (forms 16) (65536 ||| 2^19) 235331584 q10Shape16T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T41OK,q10Shape16T48OK⟩

private def q10Shape16T54 : Tree := (.split 21 (.split 23 (.split 24 (.tip (.cover 0 1 2 3 4)) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.split 23 (.split 24 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 5 7 8))))
private theorem q10Shape16T54OK : fastTreeOK (forms 16) 196608 240967680 q10Shape16T54=true := by decide

private def q10Shape16T55 : Tree := (.split 23 (.split 24 (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape16T55OK : fastTreeOK (forms 16) 1245184 239919104 q10Shape16T55=true := by decide

private def q10Shape16T53 : Tree := .split 20 q10Shape16T54 q10Shape16T55
private theorem q10Shape16T53OK : fastTreeOK (forms 16) 196608 239919104 q10Shape16T53=true := by
  change (fastTreeOK (forms 16) 196608 (239919104 ||| 2^20) q10Shape16T54 &&
    fastTreeOK (forms 16) (196608 ||| 2^20) 239919104 q10Shape16T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T54OK,q10Shape16T55OK⟩

private def q10Shape16T56 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T56OK : fastTreeOK (forms 16) 4390912 235724800 q10Shape16T56=true := by decide

private def q10Shape16T52 : Tree := .split 22 q10Shape16T53 q10Shape16T56
private theorem q10Shape16T52OK : fastTreeOK (forms 16) 196608 235724800 q10Shape16T52=true := by
  change (fastTreeOK (forms 16) 196608 (235724800 ||| 2^22) q10Shape16T53 &&
    fastTreeOK (forms 16) (196608 ||| 2^22) 235724800 q10Shape16T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T53OK,q10Shape16T56OK⟩

private def q10Shape16T57 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T57OK : fastTreeOK (forms 16) 720896 235200512 q10Shape16T57=true := by decide

private def q10Shape16T51 : Tree := .split 19 q10Shape16T52 q10Shape16T57
private theorem q10Shape16T51OK : fastTreeOK (forms 16) 196608 235200512 q10Shape16T51=true := by
  change (fastTreeOK (forms 16) 196608 (235200512 ||| 2^19) q10Shape16T52 &&
    fastTreeOK (forms 16) (196608 ||| 2^19) 235200512 q10Shape16T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T52OK,q10Shape16T57OK⟩

private def q10Shape16T39 : Tree := .split 17 q10Shape16T40 q10Shape16T51
private theorem q10Shape16T39OK : fastTreeOK (forms 16) 65536 235200512 q10Shape16T39=true := by
  change (fastTreeOK (forms 16) 65536 (235200512 ||| 2^17) q10Shape16T40 &&
    fastTreeOK (forms 16) (65536 ||| 2^17) 235200512 q10Shape16T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T40OK,q10Shape16T51OK⟩

private def q10Shape16T7 : Tree := .split 16 q10Shape16T8 q10Shape16T39
private theorem q10Shape16T7OK : fastTreeOK (forms 16) 0 235200512 q10Shape16T7=true := by
  change (fastTreeOK (forms 16) 0 (235200512 ||| 2^16) q10Shape16T8 &&
    fastTreeOK (forms 16) (0 ||| 2^16) 235200512 q10Shape16T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T8OK,q10Shape16T39OK⟩

private def q10Shape16T65 : Tree := (.split 24 (.tip (.cover 0 1 2 3 4)) (.split 4 (.split 5 (.split 2 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 1 3 4 5 6))) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 6)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))))
private theorem q10Shape16T65OK : fastTreeOK (forms 16) 32768 251617280 q10Shape16T65=true := by decide

private def q10Shape16T66 : Tree := (.split 24 (.split 4 (.split 5 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T66OK : fastTreeOK (forms 16) 8421376 243228672 q10Shape16T66=true := by decide

private def q10Shape16T64 : Tree := .split 23 q10Shape16T65 q10Shape16T66
private theorem q10Shape16T64OK : fastTreeOK (forms 16) 32768 243228672 q10Shape16T64=true := by
  change (fastTreeOK (forms 16) 32768 (243228672 ||| 2^23) q10Shape16T65 &&
    fastTreeOK (forms 16) (32768 ||| 2^23) 243228672 q10Shape16T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T65OK,q10Shape16T66OK⟩

private def q10Shape16T67 : Tree := (.split 1 (.split 23 (.split 24 (.tip (.cover 0 1 2 3 7)) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.split 24 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T67OK : fastTreeOK (forms 16) 4227072 239034368 q10Shape16T67=true := by decide

private def q10Shape16T63 : Tree := .split 22 q10Shape16T64 q10Shape16T67
private theorem q10Shape16T63OK : fastTreeOK (forms 16) 32768 239034368 q10Shape16T63=true := by
  change (fastTreeOK (forms 16) 32768 (239034368 ||| 2^22) q10Shape16T64 &&
    fastTreeOK (forms 16) (32768 ||| 2^22) 239034368 q10Shape16T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T64OK,q10Shape16T67OK⟩

private def q10Shape16T68 : Tree := (.split 22 (.split 23 (.split 24 (.split 4 (.split 5 (.split 3 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 1 3 4 5 6))) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 1 2 4 5)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 5 7 8)))
private theorem q10Shape16T68OK : fastTreeOK (forms 16) 2129920 236937216 q10Shape16T68=true := by decide

private def q10Shape16T62 : Tree := .split 21 q10Shape16T63 q10Shape16T68
private theorem q10Shape16T62OK : fastTreeOK (forms 16) 32768 236937216 q10Shape16T62=true := by
  change (fastTreeOK (forms 16) 32768 (236937216 ||| 2^21) q10Shape16T63 &&
    fastTreeOK (forms 16) (32768 ||| 2^21) 236937216 q10Shape16T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T63OK,q10Shape16T68OK⟩

private def q10Shape16T69 : Tree := (.split 21 (.split 22 (.split 23 (.split 24 (.split 4 (.split 5 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T69OK : fastTreeOK (forms 16) 1081344 235888640 q10Shape16T69=true := by decide

private def q10Shape16T61 : Tree := .split 20 q10Shape16T62 q10Shape16T69
private theorem q10Shape16T61OK : fastTreeOK (forms 16) 32768 235888640 q10Shape16T61=true := by
  change (fastTreeOK (forms 16) 32768 (235888640 ||| 2^20) q10Shape16T62 &&
    fastTreeOK (forms 16) (32768 ||| 2^20) 235888640 q10Shape16T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T62OK,q10Shape16T69OK⟩

private def q10Shape16T70 : Tree := (.split 22 (.split 23 (.split 24 (.split 1 (.split 20 (.split 21 (.tip (.cover 0 1 2 3 7)) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.split 21 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 7 8 9)))
private theorem q10Shape16T70OK : fastTreeOK (forms 16) 557056 235364352 q10Shape16T70=true := by decide

private def q10Shape16T60 : Tree := .split 19 q10Shape16T61 q10Shape16T70
private theorem q10Shape16T60OK : fastTreeOK (forms 16) 32768 235364352 q10Shape16T60=true := by
  change (fastTreeOK (forms 16) 32768 (235364352 ||| 2^19) q10Shape16T61 &&
    fastTreeOK (forms 16) (32768 ||| 2^19) 235364352 q10Shape16T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T61OK,q10Shape16T70OK⟩

private def q10Shape16T74 : Tree := (.split 21 (.split 22 (.split 24 (.tip (.cover 0 1 2 3 4)) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9)))) (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.split 22 (.split 24 (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 5 7 8))))
private theorem q10Shape16T74OK : fastTreeOK (forms 16) 163840 245194752 q10Shape16T74=true := by decide

private def q10Shape16T75 : Tree := (.split 22 (.split 24 (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape16T75OK : fastTreeOK (forms 16) 688128 244670464 q10Shape16T75=true := by decide

private def q10Shape16T73 : Tree := .split 19 q10Shape16T74 q10Shape16T75
private theorem q10Shape16T73OK : fastTreeOK (forms 16) 163840 244670464 q10Shape16T73=true := by
  change (fastTreeOK (forms 16) 163840 (244670464 ||| 2^19) q10Shape16T74 &&
    fastTreeOK (forms 16) (163840 ||| 2^19) 244670464 q10Shape16T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T74OK,q10Shape16T75OK⟩

private def q10Shape16T76 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T76OK : fastTreeOK (forms 16) 8552448 236281856 q10Shape16T76=true := by decide

private def q10Shape16T72 : Tree := .split 23 q10Shape16T73 q10Shape16T76
private theorem q10Shape16T72OK : fastTreeOK (forms 16) 163840 236281856 q10Shape16T72=true := by
  change (fastTreeOK (forms 16) 163840 (236281856 ||| 2^23) q10Shape16T73 &&
    fastTreeOK (forms 16) (163840 ||| 2^23) 236281856 q10Shape16T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T73OK,q10Shape16T76OK⟩

private def q10Shape16T77 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T77OK : fastTreeOK (forms 16) 1212416 235233280 q10Shape16T77=true := by decide

private def q10Shape16T71 : Tree := .split 20 q10Shape16T72 q10Shape16T77
private theorem q10Shape16T71OK : fastTreeOK (forms 16) 163840 235233280 q10Shape16T71=true := by
  change (fastTreeOK (forms 16) 163840 (235233280 ||| 2^20) q10Shape16T72 &&
    fastTreeOK (forms 16) (163840 ||| 2^20) 235233280 q10Shape16T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T72OK,q10Shape16T77OK⟩

private def q10Shape16T59 : Tree := .split 17 q10Shape16T60 q10Shape16T71
private theorem q10Shape16T59OK : fastTreeOK (forms 16) 32768 235233280 q10Shape16T59=true := by
  change (fastTreeOK (forms 16) 32768 (235233280 ||| 2^17) q10Shape16T60 &&
    fastTreeOK (forms 16) (32768 ||| 2^17) 235233280 q10Shape16T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T60OK,q10Shape16T71OK⟩

private def q10Shape16T82 : Tree := (.split 20 (.split 22 (.split 23 (.tip (.cover 0 1 2 3 4)) (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8)))) (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7)))) (.split 22 (.split 23 (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 5 7 9))))
private theorem q10Shape16T82OK : fastTreeOK (forms 16) 98304 254697472 q10Shape16T82=true := by decide

private def q10Shape16T83 : Tree := (.split 22 (.split 23 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 7 9)))
private theorem q10Shape16T83OK : fastTreeOK (forms 16) 622592 254173184 q10Shape16T83=true := by decide

private def q10Shape16T81 : Tree := .split 19 q10Shape16T82 q10Shape16T83
private theorem q10Shape16T81OK : fastTreeOK (forms 16) 98304 254173184 q10Shape16T81=true := by
  change (fastTreeOK (forms 16) 98304 (254173184 ||| 2^19) q10Shape16T82 &&
    fastTreeOK (forms 16) (98304 ||| 2^19) 254173184 q10Shape16T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T82OK,q10Shape16T83OK⟩

private def q10Shape16T84 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T84OK : fastTreeOK (forms 16) 16875520 237395968 q10Shape16T84=true := by decide

private def q10Shape16T80 : Tree := .split 24 q10Shape16T81 q10Shape16T84
private theorem q10Shape16T80OK : fastTreeOK (forms 16) 98304 237395968 q10Shape16T80=true := by
  change (fastTreeOK (forms 16) 98304 (237395968 ||| 2^24) q10Shape16T81 &&
    fastTreeOK (forms 16) (98304 ||| 2^24) 237395968 q10Shape16T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T81OK,q10Shape16T84OK⟩

private def q10Shape16T85 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T85OK : fastTreeOK (forms 16) 2195456 235298816 q10Shape16T85=true := by decide

private def q10Shape16T79 : Tree := .split 21 q10Shape16T80 q10Shape16T85
private theorem q10Shape16T79OK : fastTreeOK (forms 16) 98304 235298816 q10Shape16T79=true := by
  change (fastTreeOK (forms 16) 98304 (235298816 ||| 2^21) q10Shape16T80 &&
    fastTreeOK (forms 16) (98304 ||| 2^21) 235298816 q10Shape16T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T80OK,q10Shape16T85OK⟩

private def q10Shape16T86 : Tree := (.tip (.cover 0 1 4 5 6))
private theorem q10Shape16T86OK : fastTreeOK (forms 16) 229376 235167744 q10Shape16T86=true := by decide

private def q10Shape16T78 : Tree := .split 17 q10Shape16T79 q10Shape16T86
private theorem q10Shape16T78OK : fastTreeOK (forms 16) 98304 235167744 q10Shape16T78=true := by
  change (fastTreeOK (forms 16) 98304 (235167744 ||| 2^17) q10Shape16T79 &&
    fastTreeOK (forms 16) (98304 ||| 2^17) 235167744 q10Shape16T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T79OK,q10Shape16T86OK⟩

private def q10Shape16T58 : Tree := .split 16 q10Shape16T59 q10Shape16T78
private theorem q10Shape16T58OK : fastTreeOK (forms 16) 32768 235167744 q10Shape16T58=true := by
  change (fastTreeOK (forms 16) 32768 (235167744 ||| 2^16) q10Shape16T59 &&
    fastTreeOK (forms 16) (32768 ||| 2^16) 235167744 q10Shape16T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T59OK,q10Shape16T78OK⟩

private def q10Shape16T6 : Tree := .split 15 q10Shape16T7 q10Shape16T58
private theorem q10Shape16T6OK : fastTreeOK (forms 16) 0 235167744 q10Shape16T6=true := by
  change (fastTreeOK (forms 16) 0 (235167744 ||| 2^15) q10Shape16T7 &&
    fastTreeOK (forms 16) (0 ||| 2^15) 235167744 q10Shape16T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T7OK,q10Shape16T58OK⟩

private def q10Shape16T91 : Tree := (.split 20 (.split 21 (.tip (.cover 0 1 2 3 6)) (.split 24 (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.split 21 (.split 23 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 4 5 7))))
private theorem q10Shape16T91OK : fastTreeOK (forms 16) 262144 235659264 q10Shape16T91=true := by decide

private def q10Shape16T92 : Tree := (.split 20 (.split 21 (.split 22 (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9)))
private theorem q10Shape16T92OK : fastTreeOK (forms 16) 786432 235134976 q10Shape16T92=true := by decide

private def q10Shape16T90 : Tree := .split 19 q10Shape16T91 q10Shape16T92
private theorem q10Shape16T90OK : fastTreeOK (forms 16) 262144 235134976 q10Shape16T90=true := by
  change (fastTreeOK (forms 16) 262144 (235134976 ||| 2^19) q10Shape16T91 &&
    fastTreeOK (forms 16) (262144 ||| 2^19) 235134976 q10Shape16T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T91OK,q10Shape16T92OK⟩

private def q10Shape16T93 : Tree := (.split 19 (.split 20 (.split 22 (.split 23 (.split 2 (.split 3 (.split 21 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 4 6))) (.split 24 (.split 1 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 6 9))) (.tip (.cover 1 2 3 6 9))) (.tip (.cover 0 1 7 8 9)))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape16T93OK : fastTreeOK (forms 16) 393216 235003904 q10Shape16T93=true := by decide

private def q10Shape16T89 : Tree := .split 17 q10Shape16T90 q10Shape16T93
private theorem q10Shape16T89OK : fastTreeOK (forms 16) 262144 235003904 q10Shape16T89=true := by
  change (fastTreeOK (forms 16) 262144 (235003904 ||| 2^17) q10Shape16T90 &&
    fastTreeOK (forms 16) (262144 ||| 2^17) 235003904 q10Shape16T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T90OK,q10Shape16T93OK⟩

private def q10Shape16T94 : Tree := (.split 17 (.split 19 (.split 21 (.split 22 (.split 24 (.split 2 (.split 3 (.split 20 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 4 6))) (.split 23 (.split 1 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 6 8))) (.tip (.cover 1 2 3 6 8))) (.tip (.cover 0 1 7 8 9)))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 7)))
private theorem q10Shape16T94OK : fastTreeOK (forms 16) 327680 234938368 q10Shape16T94=true := by decide

private def q10Shape16T88 : Tree := .split 16 q10Shape16T89 q10Shape16T94
private theorem q10Shape16T88OK : fastTreeOK (forms 16) 262144 234938368 q10Shape16T88=true := by
  change (fastTreeOK (forms 16) 262144 (234938368 ||| 2^16) q10Shape16T89 &&
    fastTreeOK (forms 16) (262144 ||| 2^16) 234938368 q10Shape16T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T89OK,q10Shape16T94OK⟩

private def q10Shape16T95 : Tree := (.split 16 (.split 17 (.split 20 (.split 21 (.split 23 (.split 24 (.split 2 (.split 3 (.split 19 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 4 6))) (.split 22 (.split 1 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 6 7))) (.tip (.cover 1 2 3 6 7))) (.tip (.cover 0 1 7 8 9)))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9)))
private theorem q10Shape16T95OK : fastTreeOK (forms 16) 294912 234905600 q10Shape16T95=true := by decide

private def q10Shape16T87 : Tree := .split 15 q10Shape16T88 q10Shape16T95
private theorem q10Shape16T87OK : fastTreeOK (forms 16) 262144 234905600 q10Shape16T87=true := by
  change (fastTreeOK (forms 16) 262144 (234905600 ||| 2^15) q10Shape16T88 &&
    fastTreeOK (forms 16) (262144 ||| 2^15) 234905600 q10Shape16T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T88OK,q10Shape16T95OK⟩

private def q10Shape16T5 : Tree := .split 18 q10Shape16T6 q10Shape16T87
private theorem q10Shape16T5OK : fastTreeOK (forms 16) 0 234905600 q10Shape16T5=true := by
  change (fastTreeOK (forms 16) 0 (234905600 ||| 2^18) q10Shape16T6 &&
    fastTreeOK (forms 16) (0 ||| 2^18) 234905600 q10Shape16T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T6OK,q10Shape16T87OK⟩

private def q10Shape16T101 : Tree := (.split 20 (.split 21 (.tip (.cover 0 1 2 3 6)) (.split 22 (.split 23 (.split 1 (.split 3 (.split 7 (.split 9 (.tip (.small 0)) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 8)))) (.split 21 (.split 22 (.split 24 (.split 1 (.split 3 (.split 7 (.split 9 (.tip (.small 0)) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 5 7))))
private theorem q10Shape16T101OK : fastTreeOK (forms 16) 16384 235905024 q10Shape16T101=true := by decide

private def q10Shape16T102 : Tree := (.split 20 (.split 21 (.split 23 (.split 24 (.split 1 (.split 3 (.split 7 (.split 9 (.tip (.small 0)) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9)))
private theorem q10Shape16T102OK : fastTreeOK (forms 16) 540672 235380736 q10Shape16T102=true := by decide

private def q10Shape16T100 : Tree := .split 19 q10Shape16T101 q10Shape16T102
private theorem q10Shape16T100OK : fastTreeOK (forms 16) 16384 235380736 q10Shape16T100=true := by
  change (fastTreeOK (forms 16) 16384 (235380736 ||| 2^19) q10Shape16T101 &&
    fastTreeOK (forms 16) (16384 ||| 2^19) 235380736 q10Shape16T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T101OK,q10Shape16T102OK⟩

private def q10Shape16T103 : Tree := (.split 19 (.split 20 (.split 21 (.split 24 (.split 6 (.split 12 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.split 22 (.split 23 (.split 24 (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 6 9))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 7 8 9))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 8)))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape16T103OK : fastTreeOK (forms 16) 147456 235249664 q10Shape16T103=true := by decide

private def q10Shape16T99 : Tree := .split 17 q10Shape16T100 q10Shape16T103
private theorem q10Shape16T99OK : fastTreeOK (forms 16) 16384 235249664 q10Shape16T99=true := by
  change (fastTreeOK (forms 16) 16384 (235249664 ||| 2^17) q10Shape16T100 &&
    fastTreeOK (forms 16) (16384 ||| 2^17) 235249664 q10Shape16T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T100OK,q10Shape16T103OK⟩

private def q10Shape16T104 : Tree := (.split 17 (.split 19 (.split 21 (.split 20 (.split 23 (.split 5 (.split 11 (.split 4 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.split 22 (.split 23 (.split 24 (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 6 8))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 7 8 9))) (.tip (.cover 0 1 5 6 9)))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 7)))
private theorem q10Shape16T104OK : fastTreeOK (forms 16) 81920 235184128 q10Shape16T104=true := by decide

private def q10Shape16T98 : Tree := .split 16 q10Shape16T99 q10Shape16T104
private theorem q10Shape16T98OK : fastTreeOK (forms 16) 16384 235184128 q10Shape16T98=true := by
  change (fastTreeOK (forms 16) 16384 (235184128 ||| 2^16) q10Shape16T99 &&
    fastTreeOK (forms 16) (16384 ||| 2^16) 235184128 q10Shape16T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T99OK,q10Shape16T104OK⟩

private def q10Shape16T105 : Tree := (.split 16 (.split 17 (.split 20 (.split 21 (.split 19 (.split 22 (.split 4 (.split 10 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.split 22 (.split 23 (.split 24 (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 5))) (.tip (.cover 1 2 3 6 7))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 7 8 9)))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9)))
private theorem q10Shape16T105OK : fastTreeOK (forms 16) 49152 235151360 q10Shape16T105=true := by decide

private def q10Shape16T97 : Tree := .split 15 q10Shape16T98 q10Shape16T105
private theorem q10Shape16T97OK : fastTreeOK (forms 16) 16384 235151360 q10Shape16T97=true := by
  change (fastTreeOK (forms 16) 16384 (235151360 ||| 2^15) q10Shape16T98 &&
    fastTreeOK (forms 16) (16384 ||| 2^15) 235151360 q10Shape16T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T98OK,q10Shape16T105OK⟩

private def q10Shape16T106 : Tree := (.split 22 (.split 23 (.split 24 (.tip (.cover 1 2 3 4 5)) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape16T106OK : fastTreeOK (forms 16) 278528 234889216 q10Shape16T106=true := by decide

private def q10Shape16T96 : Tree := .split 18 q10Shape16T97 q10Shape16T106
private theorem q10Shape16T96OK : fastTreeOK (forms 16) 16384 234889216 q10Shape16T96=true := by
  change (fastTreeOK (forms 16) 16384 (234889216 ||| 2^18) q10Shape16T97 &&
    fastTreeOK (forms 16) (16384 ||| 2^18) 234889216 q10Shape16T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T97OK,q10Shape16T106OK⟩

private def q10Shape16T4 : Tree := .split 14 q10Shape16T5 q10Shape16T96
private theorem q10Shape16T4OK : fastTreeOK (forms 16) 0 234889216 q10Shape16T4=true := by
  change (fastTreeOK (forms 16) 0 (234889216 ||| 2^14) q10Shape16T5 &&
    fastTreeOK (forms 16) (0 ||| 2^14) 234889216 q10Shape16T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T5OK,q10Shape16T96OK⟩

private def q10Shape16T114 : Tree := (.split 21 (.split 1 (.split 2 (.split 22 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6))) (.split 23 (.split 24 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9)))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6))) (.split 22 (.split 23 (.split 24 (.tip (.cover 0 1 2 3 5)) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 9))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6)))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 8))))
private theorem q10Shape16T114OK : fastTreeOK (forms 16) 8192 236961792 q10Shape16T114=true := by decide

private def q10Shape16T115 : Tree := (.split 21 (.split 22 (.split 24 (.split 23 (.tip (.cover 0 1 2 3 5)) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 8))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6)))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape16T115OK : fastTreeOK (forms 16) 1056768 235913216 q10Shape16T115=true := by decide

private def q10Shape16T113 : Tree := .split 20 q10Shape16T114 q10Shape16T115
private theorem q10Shape16T113OK : fastTreeOK (forms 16) 8192 235913216 q10Shape16T113=true := by
  change (fastTreeOK (forms 16) 8192 (235913216 ||| 2^20) q10Shape16T114 &&
    fastTreeOK (forms 16) (8192 ||| 2^20) 235913216 q10Shape16T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T114OK,q10Shape16T115OK⟩

private def q10Shape16T116 : Tree := (.split 20 (.split 21 (.split 23 (.split 24 (.split 22 (.tip (.cover 0 1 2 3 5)) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 4 7))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6)))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape16T116OK : fastTreeOK (forms 16) 532480 235388928 q10Shape16T116=true := by decide

private def q10Shape16T112 : Tree := .split 19 q10Shape16T113 q10Shape16T116
private theorem q10Shape16T112OK : fastTreeOK (forms 16) 8192 235388928 q10Shape16T112=true := by
  change (fastTreeOK (forms 16) 8192 (235388928 ||| 2^19) q10Shape16T113 &&
    fastTreeOK (forms 16) (8192 ||| 2^19) 235388928 q10Shape16T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T113OK,q10Shape16T116OK⟩

private def q10Shape16T120 : Tree := (.split 20 (.split 21 (.split 24 (.tip (.cover 0 1 2 3 4)) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 5 9))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6)))) (.tip (.cover 0 1 2 3 9))) (.split 21 (.split 24 (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape16T120OK : fastTreeOK (forms 16) 139264 248365056 q10Shape16T120=true := by decide

private def q10Shape16T121 : Tree := (.split 20 (.split 21 (.split 24 (.split 4 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 4 5 6)))
private theorem q10Shape16T121OK : fastTreeOK (forms 16) 663552 247840768 q10Shape16T121=true := by decide

private def q10Shape16T119 : Tree := .split 19 q10Shape16T120 q10Shape16T121
private theorem q10Shape16T119OK : fastTreeOK (forms 16) 139264 247840768 q10Shape16T119=true := by
  change (fastTreeOK (forms 16) 139264 (247840768 ||| 2^19) q10Shape16T120 &&
    fastTreeOK (forms 16) (139264 ||| 2^19) 247840768 q10Shape16T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T120OK,q10Shape16T121OK⟩

private def q10Shape16T122 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T122OK : fastTreeOK (forms 16) 8527872 239452160 q10Shape16T122=true := by decide

private def q10Shape16T118 : Tree := .split 23 q10Shape16T119 q10Shape16T122
private theorem q10Shape16T118OK : fastTreeOK (forms 16) 139264 239452160 q10Shape16T118=true := by
  change (fastTreeOK (forms 16) 139264 (239452160 ||| 2^23) q10Shape16T119 &&
    fastTreeOK (forms 16) (139264 ||| 2^23) 239452160 q10Shape16T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T119OK,q10Shape16T122OK⟩

private def q10Shape16T123 : Tree := (.tip (.cover 0 1 4 6 8))
private theorem q10Shape16T123OK : fastTreeOK (forms 16) 4333568 235257856 q10Shape16T123=true := by decide

private def q10Shape16T117 : Tree := .split 22 q10Shape16T118 q10Shape16T123
private theorem q10Shape16T117OK : fastTreeOK (forms 16) 139264 235257856 q10Shape16T117=true := by
  change (fastTreeOK (forms 16) 139264 (235257856 ||| 2^22) q10Shape16T118 &&
    fastTreeOK (forms 16) (139264 ||| 2^22) 235257856 q10Shape16T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T118OK,q10Shape16T123OK⟩

private def q10Shape16T111 : Tree := .split 17 q10Shape16T112 q10Shape16T117
private theorem q10Shape16T111OK : fastTreeOK (forms 16) 8192 235257856 q10Shape16T111=true := by
  change (fastTreeOK (forms 16) 8192 (235257856 ||| 2^17) q10Shape16T112 &&
    fastTreeOK (forms 16) (8192 ||| 2^17) 235257856 q10Shape16T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T112OK,q10Shape16T117OK⟩

private def q10Shape16T128 : Tree := (.split 20 (.split 21 (.split 23 (.tip (.cover 0 1 2 3 4)) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 5 8))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6)))) (.split 23 (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 5 6 7)))) (.split 21 (.tip (.cover 0 1 2 3 8)) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape16T128OK : fastTreeOK (forms 16) 73728 256819200 q10Shape16T128=true := by decide

private def q10Shape16T129 : Tree := (.split 20 (.split 21 (.split 23 (.split 4 (.split 5 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape16T129OK : fastTreeOK (forms 16) 598016 256294912 q10Shape16T129=true := by decide

private def q10Shape16T127 : Tree := .split 19 q10Shape16T128 q10Shape16T129
private theorem q10Shape16T127OK : fastTreeOK (forms 16) 73728 256294912 q10Shape16T127=true := by
  change (fastTreeOK (forms 16) 73728 (256294912 ||| 2^19) q10Shape16T128 &&
    fastTreeOK (forms 16) (73728 ||| 2^19) 256294912 q10Shape16T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T128OK,q10Shape16T129OK⟩

private def q10Shape16T130 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T130OK : fastTreeOK (forms 16) 16850944 239517696 q10Shape16T130=true := by decide

private def q10Shape16T126 : Tree := .split 24 q10Shape16T127 q10Shape16T130
private theorem q10Shape16T126OK : fastTreeOK (forms 16) 73728 239517696 q10Shape16T126=true := by
  change (fastTreeOK (forms 16) 73728 (239517696 ||| 2^24) q10Shape16T127 &&
    fastTreeOK (forms 16) (73728 ||| 2^24) 239517696 q10Shape16T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T127OK,q10Shape16T130OK⟩

private def q10Shape16T131 : Tree := (.tip (.cover 0 1 4 6 9))
private theorem q10Shape16T131OK : fastTreeOK (forms 16) 4268032 235323392 q10Shape16T131=true := by decide

private def q10Shape16T125 : Tree := .split 22 q10Shape16T126 q10Shape16T131
private theorem q10Shape16T125OK : fastTreeOK (forms 16) 73728 235323392 q10Shape16T125=true := by
  change (fastTreeOK (forms 16) 73728 (235323392 ||| 2^22) q10Shape16T126 &&
    fastTreeOK (forms 16) (73728 ||| 2^22) 235323392 q10Shape16T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T126OK,q10Shape16T131OK⟩

private def q10Shape16T132 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T132OK : fastTreeOK (forms 16) 204800 235192320 q10Shape16T132=true := by decide

private def q10Shape16T124 : Tree := .split 17 q10Shape16T125 q10Shape16T132
private theorem q10Shape16T124OK : fastTreeOK (forms 16) 73728 235192320 q10Shape16T124=true := by
  change (fastTreeOK (forms 16) 73728 (235192320 ||| 2^17) q10Shape16T125 &&
    fastTreeOK (forms 16) (73728 ||| 2^17) 235192320 q10Shape16T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T125OK,q10Shape16T132OK⟩

private def q10Shape16T110 : Tree := .split 16 q10Shape16T111 q10Shape16T124
private theorem q10Shape16T110OK : fastTreeOK (forms 16) 8192 235192320 q10Shape16T110=true := by
  change (fastTreeOK (forms 16) 8192 (235192320 ||| 2^16) q10Shape16T111 &&
    fastTreeOK (forms 16) (8192 ||| 2^16) 235192320 q10Shape16T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T111OK,q10Shape16T124OK⟩

private def q10Shape16T138 : Tree := (.split 20 (.split 21 (.split 22 (.tip (.cover 0 1 2 3 4)) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 1 2 3 5 7))) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 1 2 3 5 6)))) (.split 22 (.split 4 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 5 6 8)))) (.split 21 (.split 22 (.split 4 (.split 5 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 5 6))))
private theorem q10Shape16T138OK : fastTreeOK (forms 16) 40960 261046272 q10Shape16T138=true := by decide

private def q10Shape16T139 : Tree := (.split 22 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 1 7 8 9)))
private theorem q10Shape16T139OK : fastTreeOK (forms 16) 565248 260521984 q10Shape16T139=true := by decide

private def q10Shape16T137 : Tree := .split 19 q10Shape16T138 q10Shape16T139
private theorem q10Shape16T137OK : fastTreeOK (forms 16) 40960 260521984 q10Shape16T137=true := by
  change (fastTreeOK (forms 16) 40960 (260521984 ||| 2^19) q10Shape16T138 &&
    fastTreeOK (forms 16) (40960 ||| 2^19) 260521984 q10Shape16T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T138OK,q10Shape16T139OK⟩

private def q10Shape16T140 : Tree := (.tip (.cover 0 1 4 6 8))
private theorem q10Shape16T140OK : fastTreeOK (forms 16) 16818176 243744768 q10Shape16T140=true := by decide

private def q10Shape16T136 : Tree := .split 24 q10Shape16T137 q10Shape16T140
private theorem q10Shape16T136OK : fastTreeOK (forms 16) 40960 243744768 q10Shape16T136=true := by
  change (fastTreeOK (forms 16) 40960 (243744768 ||| 2^24) q10Shape16T137 &&
    fastTreeOK (forms 16) (40960 ||| 2^24) 243744768 q10Shape16T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T137OK,q10Shape16T140OK⟩

private def q10Shape16T141 : Tree := (.tip (.cover 0 1 4 6 9))
private theorem q10Shape16T141OK : fastTreeOK (forms 16) 8429568 235356160 q10Shape16T141=true := by decide

private def q10Shape16T135 : Tree := .split 23 q10Shape16T136 q10Shape16T141
private theorem q10Shape16T135OK : fastTreeOK (forms 16) 40960 235356160 q10Shape16T135=true := by
  change (fastTreeOK (forms 16) 40960 (235356160 ||| 2^23) q10Shape16T136 &&
    fastTreeOK (forms 16) (40960 ||| 2^23) 235356160 q10Shape16T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T136OK,q10Shape16T141OK⟩

private def q10Shape16T142 : Tree := (.tip (.cover 0 1 4 6 8))
private theorem q10Shape16T142OK : fastTreeOK (forms 16) 172032 235225088 q10Shape16T142=true := by decide

private def q10Shape16T134 : Tree := .split 17 q10Shape16T135 q10Shape16T142
private theorem q10Shape16T134OK : fastTreeOK (forms 16) 40960 235225088 q10Shape16T134=true := by
  change (fastTreeOK (forms 16) 40960 (235225088 ||| 2^17) q10Shape16T135 &&
    fastTreeOK (forms 16) (40960 ||| 2^17) 235225088 q10Shape16T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T135OK,q10Shape16T142OK⟩

private def q10Shape16T143 : Tree := (.tip (.cover 0 1 4 6 9))
private theorem q10Shape16T143OK : fastTreeOK (forms 16) 106496 235159552 q10Shape16T143=true := by decide

private def q10Shape16T133 : Tree := .split 16 q10Shape16T134 q10Shape16T143
private theorem q10Shape16T133OK : fastTreeOK (forms 16) 40960 235159552 q10Shape16T133=true := by
  change (fastTreeOK (forms 16) 40960 (235159552 ||| 2^16) q10Shape16T134 &&
    fastTreeOK (forms 16) (40960 ||| 2^16) 235159552 q10Shape16T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T134OK,q10Shape16T143OK⟩

private def q10Shape16T109 : Tree := .split 15 q10Shape16T110 q10Shape16T133
private theorem q10Shape16T109OK : fastTreeOK (forms 16) 8192 235159552 q10Shape16T109=true := by
  change (fastTreeOK (forms 16) 8192 (235159552 ||| 2^15) q10Shape16T110 &&
    fastTreeOK (forms 16) (8192 ||| 2^15) 235159552 q10Shape16T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T110OK,q10Shape16T133OK⟩

private def q10Shape16T144 : Tree := (.split 19 (.split 20 (.split 21 (.tip (.cover 1 2 3 4 6)) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape16T144OK : fastTreeOK (forms 16) 270336 234897408 q10Shape16T144=true := by decide

private def q10Shape16T108 : Tree := .split 18 q10Shape16T109 q10Shape16T144
private theorem q10Shape16T108OK : fastTreeOK (forms 16) 8192 234897408 q10Shape16T108=true := by
  change (fastTreeOK (forms 16) 8192 (234897408 ||| 2^18) q10Shape16T109 &&
    fastTreeOK (forms 16) (8192 ||| 2^18) 234897408 q10Shape16T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T109OK,q10Shape16T144OK⟩

private def q10Shape16T145 : Tree := (.split 15 (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape16T145OK : fastTreeOK (forms 16) 24576 234881024 q10Shape16T145=true := by decide

private def q10Shape16T107 : Tree := .split 14 q10Shape16T108 q10Shape16T145
private theorem q10Shape16T107OK : fastTreeOK (forms 16) 8192 234881024 q10Shape16T107=true := by
  change (fastTreeOK (forms 16) 8192 (234881024 ||| 2^14) q10Shape16T108 &&
    fastTreeOK (forms 16) (8192 ||| 2^14) 234881024 q10Shape16T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T108OK,q10Shape16T145OK⟩

private def q10Shape16T3 : Tree := .split 13 q10Shape16T4 q10Shape16T107
private theorem q10Shape16T3OK : fastTreeOK (forms 16) 0 234881024 q10Shape16T3=true := by
  change (fastTreeOK (forms 16) 0 (234881024 ||| 2^13) q10Shape16T4 &&
    fastTreeOK (forms 16) (0 ||| 2^13) 234881024 q10Shape16T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T4OK,q10Shape16T107OK⟩

private def q10Shape16T154 : Tree := (.split 21 (.split 22 (.split 23 (.tip (.cover 0 1 2 3 9)) (.tip (.cover 0 1 2 3 8))) (.split 5 (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9)))) (.split 22 (.split 23 (.tip (.cover 0 1 2 3 9)) (.split 24 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 4 7 9)))) (.tip (.cover 0 1 4 6 9))))
private theorem q10Shape16T154OK : fastTreeOK (forms 16) 134217728 102752256 q10Shape16T154=true := by decide

private def q10Shape16T155 : Tree := (.split 22 (.split 23 (.split 21 (.split 24 (.tip (.cover 0 1 2 3 8)) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape16T155OK : fastTreeOK (forms 16) 135266304 101703680 q10Shape16T155=true := by decide

private def q10Shape16T153 : Tree := .split 20 q10Shape16T154 q10Shape16T155
private theorem q10Shape16T153OK : fastTreeOK (forms 16) 134217728 101703680 q10Shape16T153=true := by
  change (fastTreeOK (forms 16) 134217728 (101703680 ||| 2^20) q10Shape16T154 &&
    fastTreeOK (forms 16) (134217728 ||| 2^20) 101703680 q10Shape16T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T154OK,q10Shape16T155OK⟩

private def q10Shape16T156 : Tree := (.split 22 (.split 23 (.split 24 (.split 5 (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape16T156OK : fastTreeOK (forms 16) 134742016 101179392 q10Shape16T156=true := by decide

private def q10Shape16T152 : Tree := .split 19 q10Shape16T153 q10Shape16T156
private theorem q10Shape16T152OK : fastTreeOK (forms 16) 134217728 101179392 q10Shape16T152=true := by
  change (fastTreeOK (forms 16) 134217728 (101179392 ||| 2^19) q10Shape16T153 &&
    fastTreeOK (forms 16) (134217728 ||| 2^19) 101179392 q10Shape16T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T153OK,q10Shape16T156OK⟩

private def q10Shape16T157 : Tree := (.split 19 (.split 21 (.split 22 (.split 24 (.split 1 (.split 20 (.split 23 (.tip (.cover 0 1 2 3 9)) (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 9)))) (.split 23 (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 4 7 8)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape16T157OK : fastTreeOK (forms 16) 134348800 101048320 q10Shape16T157=true := by decide

private def q10Shape16T151 : Tree := .split 17 q10Shape16T152 q10Shape16T157
private theorem q10Shape16T151OK : fastTreeOK (forms 16) 134217728 101048320 q10Shape16T151=true := by
  change (fastTreeOK (forms 16) 134217728 (101048320 ||| 2^17) q10Shape16T152 &&
    fastTreeOK (forms 16) (134217728 ||| 2^17) 101048320 q10Shape16T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T152OK,q10Shape16T157OK⟩

private def q10Shape16T158 : Tree := (.split 19 (.split 20 (.split 22 (.split 23 (.split 17 (.split 1 (.split 21 (.split 24 (.tip (.cover 0 1 2 3 8)) (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 8)))) (.split 24 (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 4 7 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape16T158OK : fastTreeOK (forms 16) 134283264 100982784 q10Shape16T158=true := by decide

private def q10Shape16T150 : Tree := .split 16 q10Shape16T151 q10Shape16T158
private theorem q10Shape16T150OK : fastTreeOK (forms 16) 134217728 100982784 q10Shape16T150=true := by
  change (fastTreeOK (forms 16) 134217728 (100982784 ||| 2^16) q10Shape16T151 &&
    fastTreeOK (forms 16) (134217728 ||| 2^16) 100982784 q10Shape16T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T151OK,q10Shape16T158OK⟩

private def q10Shape16T159 : Tree := (.split 19 (.split 20 (.split 21 (.split 22 (.split 23 (.split 24 (.split 5 (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 6 7 8)))
private theorem q10Shape16T159OK : fastTreeOK (forms 16) 134250496 100950016 q10Shape16T159=true := by decide

private def q10Shape16T149 : Tree := .split 15 q10Shape16T150 q10Shape16T159
private theorem q10Shape16T149OK : fastTreeOK (forms 16) 134217728 100950016 q10Shape16T149=true := by
  change (fastTreeOK (forms 16) 134217728 (100950016 ||| 2^15) q10Shape16T150 &&
    fastTreeOK (forms 16) (134217728 ||| 2^15) 100950016 q10Shape16T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T150OK,q10Shape16T159OK⟩

private def q10Shape16T169 : Tree := (.split 4 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 1 (.tip (.cover 0 1 3 5 8)) (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 4 5)))) (.tip (.cover 0 2 5 7 8))) (.tip (.cover 0 2 5 7 9))))) (.split 1 (.split 10 (.split 11 (.split 12 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 3 5 7 8))) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 1 2 5 8))))
private theorem q10Shape16T169OK : fastTreeOK (forms 16) 134479872 133947392 q10Shape16T169=true := by decide

private def q10Shape16T170 : Tree := (.split 5 (.split 11 (.split 2 (.split 8 (.split 4 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 5 9))) (.split 1 (.tip (.cover 0 3 6 7 8)) (.tip (.cover 0 1 2 5 8)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T170OK : fastTreeOK (forms 16) 151257088 117170176 q10Shape16T170=true := by decide

private def q10Shape16T168 : Tree := .split 24 q10Shape16T169 q10Shape16T170
private theorem q10Shape16T168OK : fastTreeOK (forms 16) 134479872 117170176 q10Shape16T168=true := by
  change (fastTreeOK (forms 16) 134479872 (117170176 ||| 2^24) q10Shape16T169 &&
    fastTreeOK (forms 16) (134479872 ||| 2^24) 117170176 q10Shape16T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T169OK,q10Shape16T170OK⟩

private def q10Shape16T171 : Tree := (.split 24 (.split 6 (.split 12 (.split 2 (.split 8 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 3 4 5 8))) (.split 1 (.tip (.cover 0 3 6 7 9)) (.tip (.cover 0 1 2 5 8)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape16T171OK : fastTreeOK (forms 16) 142868480 108781568 q10Shape16T171=true := by decide

private def q10Shape16T167 : Tree := .split 23 q10Shape16T168 q10Shape16T171
private theorem q10Shape16T167OK : fastTreeOK (forms 16) 134479872 108781568 q10Shape16T167=true := by
  change (fastTreeOK (forms 16) 134479872 (108781568 ||| 2^23) q10Shape16T168 &&
    fastTreeOK (forms 16) (134479872 ||| 2^23) 108781568 q10Shape16T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T168OK,q10Shape16T171OK⟩

private def q10Shape16T172 : Tree := (.split 24 (.split 5 (.split 11 (.split 3 (.split 9 (.split 23 (.split 4 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 6 9))) (.split 1 (.tip (.cover 0 3 5 7 8)) (.tip (.cover 0 1 2 5 8)))) (.split 6 (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 4 7 9)))
private theorem q10Shape16T172OK : fastTreeOK (forms 16) 136577024 106684416 q10Shape16T172=true := by decide

private def q10Shape16T166 : Tree := .split 21 q10Shape16T167 q10Shape16T172
private theorem q10Shape16T166OK : fastTreeOK (forms 16) 134479872 106684416 q10Shape16T166=true := by
  change (fastTreeOK (forms 16) 134479872 (106684416 ||| 2^21) q10Shape16T167 &&
    fastTreeOK (forms 16) (134479872 ||| 2^21) 106684416 q10Shape16T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T167OK,q10Shape16T172OK⟩

private def q10Shape16T173 : Tree := (.split 21 (.split 23 (.split 6 (.split 12 (.split 3 (.split 9 (.split 24 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 3 4 6 8))) (.split 1 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 2 5 8)))) (.split 5 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 5 7)))
private theorem q10Shape16T173OK : fastTreeOK (forms 16) 135528448 105635840 q10Shape16T173=true := by decide

private def q10Shape16T165 : Tree := .split 20 q10Shape16T166 q10Shape16T173
private theorem q10Shape16T165OK : fastTreeOK (forms 16) 134479872 105635840 q10Shape16T165=true := by
  change (fastTreeOK (forms 16) 134479872 (105635840 ||| 2^20) q10Shape16T166 &&
    fastTreeOK (forms 16) (134479872 ||| 2^20) 105635840 q10Shape16T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T166OK,q10Shape16T173OK⟩

private def q10Shape16T174 : Tree := (.tip (.cover 0 1 4 6 8))
private theorem q10Shape16T174OK : fastTreeOK (forms 16) 138674176 101441536 q10Shape16T174=true := by decide

private def q10Shape16T164 : Tree := .split 22 q10Shape16T165 q10Shape16T174
private theorem q10Shape16T164OK : fastTreeOK (forms 16) 134479872 101441536 q10Shape16T164=true := by
  change (fastTreeOK (forms 16) 134479872 (101441536 ||| 2^22) q10Shape16T165 &&
    fastTreeOK (forms 16) (134479872 ||| 2^22) 101441536 q10Shape16T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T165OK,q10Shape16T174OK⟩

private def q10Shape16T175 : Tree := (.tip (.cover 0 1 4 5 8))
private theorem q10Shape16T175OK : fastTreeOK (forms 16) 135004160 100917248 q10Shape16T175=true := by decide

private def q10Shape16T163 : Tree := .split 19 q10Shape16T164 q10Shape16T175
private theorem q10Shape16T163OK : fastTreeOK (forms 16) 134479872 100917248 q10Shape16T163=true := by
  change (fastTreeOK (forms 16) 134479872 (100917248 ||| 2^19) q10Shape16T164 &&
    fastTreeOK (forms 16) (134479872 ||| 2^19) 100917248 q10Shape16T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T164OK,q10Shape16T175OK⟩

private def q10Shape16T176 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape16T176OK : fastTreeOK (forms 16) 134610944 100786176 q10Shape16T176=true := by decide

private def q10Shape16T162 : Tree := .split 17 q10Shape16T163 q10Shape16T176
private theorem q10Shape16T162OK : fastTreeOK (forms 16) 134479872 100786176 q10Shape16T162=true := by
  change (fastTreeOK (forms 16) 134479872 (100786176 ||| 2^17) q10Shape16T163 &&
    fastTreeOK (forms 16) (134479872 ||| 2^17) 100786176 q10Shape16T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T163OK,q10Shape16T176OK⟩

private def q10Shape16T177 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape16T177OK : fastTreeOK (forms 16) 134545408 100720640 q10Shape16T177=true := by decide

private def q10Shape16T161 : Tree := .split 16 q10Shape16T162 q10Shape16T177
private theorem q10Shape16T161OK : fastTreeOK (forms 16) 134479872 100720640 q10Shape16T161=true := by
  change (fastTreeOK (forms 16) 134479872 (100720640 ||| 2^16) q10Shape16T162 &&
    fastTreeOK (forms 16) (134479872 ||| 2^16) 100720640 q10Shape16T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T162OK,q10Shape16T177OK⟩

private def q10Shape16T178 : Tree := (.tip (.cover 0 1 4 5 8))
private theorem q10Shape16T178OK : fastTreeOK (forms 16) 134512640 100687872 q10Shape16T178=true := by decide

private def q10Shape16T160 : Tree := .split 15 q10Shape16T161 q10Shape16T178
private theorem q10Shape16T160OK : fastTreeOK (forms 16) 134479872 100687872 q10Shape16T160=true := by
  change (fastTreeOK (forms 16) 134479872 (100687872 ||| 2^15) q10Shape16T161 &&
    fastTreeOK (forms 16) (134479872 ||| 2^15) 100687872 q10Shape16T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T161OK,q10Shape16T178OK⟩

private def q10Shape16T148 : Tree := .split 18 q10Shape16T149 q10Shape16T160
private theorem q10Shape16T148OK : fastTreeOK (forms 16) 134217728 100687872 q10Shape16T148=true := by
  change (fastTreeOK (forms 16) 134217728 (100687872 ||| 2^18) q10Shape16T149 &&
    fastTreeOK (forms 16) (134217728 ||| 2^18) 100687872 q10Shape16T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T149OK,q10Shape16T160OK⟩

private def q10Shape16T189 : Tree := (.split 4 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 2 (.tip (.cover 0 1 3 4 8)) (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 4 5)))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 4 7 9))))) (.split 2 (.split 10 (.split 11 (.split 12 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 2 4 8))))
private theorem q10Shape16T189OK : fastTreeOK (forms 16) 134234112 134193152 q10Shape16T189=true := by decide

private def q10Shape16T190 : Tree := (.split 5 (.split 11 (.split 1 (.split 7 (.split 4 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 5 9))) (.split 2 (.tip (.cover 0 3 6 7 8)) (.tip (.cover 0 1 2 4 8)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T190OK : fastTreeOK (forms 16) 151011328 117415936 q10Shape16T190=true := by decide

private def q10Shape16T188 : Tree := .split 24 q10Shape16T189 q10Shape16T190
private theorem q10Shape16T188OK : fastTreeOK (forms 16) 134234112 117415936 q10Shape16T188=true := by
  change (fastTreeOK (forms 16) 134234112 (117415936 ||| 2^24) q10Shape16T189 &&
    fastTreeOK (forms 16) (134234112 ||| 2^24) 117415936 q10Shape16T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T189OK,q10Shape16T190OK⟩

private def q10Shape16T191 : Tree := (.split 24 (.split 6 (.split 12 (.split 1 (.split 7 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 3 4 5 8))) (.split 2 (.tip (.cover 0 3 6 7 9)) (.tip (.cover 0 1 2 4 8)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape16T191OK : fastTreeOK (forms 16) 142622720 109027328 q10Shape16T191=true := by decide

private def q10Shape16T187 : Tree := .split 23 q10Shape16T188 q10Shape16T191
private theorem q10Shape16T187OK : fastTreeOK (forms 16) 134234112 109027328 q10Shape16T187=true := by
  change (fastTreeOK (forms 16) 134234112 (109027328 ||| 2^23) q10Shape16T188 &&
    fastTreeOK (forms 16) (134234112 ||| 2^23) 109027328 q10Shape16T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T188OK,q10Shape16T191OK⟩

private def q10Shape16T192 : Tree := (.split 24 (.split 5 (.split 11 (.split 3 (.split 9 (.split 23 (.split 4 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9))) (.split 2 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 4 8)))) (.split 6 (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 7 9)))
private theorem q10Shape16T192OK : fastTreeOK (forms 16) 134365184 108896256 q10Shape16T192=true := by decide

private def q10Shape16T186 : Tree := .split 17 q10Shape16T187 q10Shape16T192
private theorem q10Shape16T186OK : fastTreeOK (forms 16) 134234112 108896256 q10Shape16T186=true := by
  change (fastTreeOK (forms 16) 134234112 (108896256 ||| 2^17) q10Shape16T187 &&
    fastTreeOK (forms 16) (134234112 ||| 2^17) 108896256 q10Shape16T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T187OK,q10Shape16T192OK⟩

private def q10Shape16T193 : Tree := (.split 17 (.split 23 (.split 6 (.split 12 (.split 3 (.split 9 (.split 24 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 3 5 6 8))) (.split 2 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 4 8)))) (.split 5 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 4 5 7)))
private theorem q10Shape16T193OK : fastTreeOK (forms 16) 134299648 108830720 q10Shape16T193=true := by decide

private def q10Shape16T185 : Tree := .split 16 q10Shape16T186 q10Shape16T193
private theorem q10Shape16T185OK : fastTreeOK (forms 16) 134234112 108830720 q10Shape16T185=true := by
  change (fastTreeOK (forms 16) 134234112 (108830720 ||| 2^16) q10Shape16T186 &&
    fastTreeOK (forms 16) (134234112 ||| 2^16) 108830720 q10Shape16T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T186OK,q10Shape16T193OK⟩

private def q10Shape16T194 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape16T194OK : fastTreeOK (forms 16) 138428416 104636416 q10Shape16T194=true := by decide

private def q10Shape16T184 : Tree := .split 22 q10Shape16T185 q10Shape16T194
private theorem q10Shape16T184OK : fastTreeOK (forms 16) 134234112 104636416 q10Shape16T184=true := by
  change (fastTreeOK (forms 16) 134234112 (104636416 ||| 2^22) q10Shape16T185 &&
    fastTreeOK (forms 16) (134234112 ||| 2^22) 104636416 q10Shape16T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T185OK,q10Shape16T194OK⟩

private def q10Shape16T195 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape16T195OK : fastTreeOK (forms 16) 136331264 102539264 q10Shape16T195=true := by decide

private def q10Shape16T183 : Tree := .split 21 q10Shape16T184 q10Shape16T195
private theorem q10Shape16T183OK : fastTreeOK (forms 16) 134234112 102539264 q10Shape16T183=true := by
  change (fastTreeOK (forms 16) 134234112 (102539264 ||| 2^21) q10Shape16T184 &&
    fastTreeOK (forms 16) (134234112 ||| 2^21) 102539264 q10Shape16T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T184OK,q10Shape16T195OK⟩

private def q10Shape16T196 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape16T196OK : fastTreeOK (forms 16) 135282688 101490688 q10Shape16T196=true := by decide

private def q10Shape16T182 : Tree := .split 20 q10Shape16T183 q10Shape16T196
private theorem q10Shape16T182OK : fastTreeOK (forms 16) 134234112 101490688 q10Shape16T182=true := by
  change (fastTreeOK (forms 16) 134234112 (101490688 ||| 2^20) q10Shape16T183 &&
    fastTreeOK (forms 16) (134234112 ||| 2^20) 101490688 q10Shape16T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T183OK,q10Shape16T196OK⟩

private def q10Shape16T197 : Tree := (.tip (.cover 0 1 4 5 8))
private theorem q10Shape16T197OK : fastTreeOK (forms 16) 134758400 100966400 q10Shape16T197=true := by decide

private def q10Shape16T181 : Tree := .split 19 q10Shape16T182 q10Shape16T197
private theorem q10Shape16T181OK : fastTreeOK (forms 16) 134234112 100966400 q10Shape16T181=true := by
  change (fastTreeOK (forms 16) 134234112 (100966400 ||| 2^19) q10Shape16T182 &&
    fastTreeOK (forms 16) (134234112 ||| 2^19) 100966400 q10Shape16T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T182OK,q10Shape16T197OK⟩

private def q10Shape16T198 : Tree := (.tip (.cover 0 1 4 5 8))
private theorem q10Shape16T198OK : fastTreeOK (forms 16) 134266880 100933632 q10Shape16T198=true := by decide

private def q10Shape16T180 : Tree := .split 15 q10Shape16T181 q10Shape16T198
private theorem q10Shape16T180OK : fastTreeOK (forms 16) 134234112 100933632 q10Shape16T180=true := by
  change (fastTreeOK (forms 16) 134234112 (100933632 ||| 2^15) q10Shape16T181 &&
    fastTreeOK (forms 16) (134234112 ||| 2^15) 100933632 q10Shape16T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T181OK,q10Shape16T198OK⟩

private def q10Shape16T199 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape16T199OK : fastTreeOK (forms 16) 134496256 100671488 q10Shape16T199=true := by decide

private def q10Shape16T179 : Tree := .split 18 q10Shape16T180 q10Shape16T199
private theorem q10Shape16T179OK : fastTreeOK (forms 16) 134234112 100671488 q10Shape16T179=true := by
  change (fastTreeOK (forms 16) 134234112 (100671488 ||| 2^18) q10Shape16T180 &&
    fastTreeOK (forms 16) (134234112 ||| 2^18) 100671488 q10Shape16T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T180OK,q10Shape16T199OK⟩

private def q10Shape16T147 : Tree := .split 14 q10Shape16T148 q10Shape16T179
private theorem q10Shape16T147OK : fastTreeOK (forms 16) 134217728 100671488 q10Shape16T147=true := by
  change (fastTreeOK (forms 16) 134217728 (100671488 ||| 2^14) q10Shape16T148 &&
    fastTreeOK (forms 16) (134217728 ||| 2^14) 100671488 q10Shape16T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T148OK,q10Shape16T179OK⟩

private def q10Shape16T211 : Tree := (.split 4 (.split 10 (.tip (.cover 0 1 4 6 8)) (.split 3 (.tip (.cover 0 1 3 4 8)) (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 4 6)))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 4 7 9))))) (.split 3 (.split 10 (.split 11 (.split 12 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 6)))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 2 4 8))))
private theorem q10Shape16T211OK : fastTreeOK (forms 16) 134225920 134201344 q10Shape16T211=true := by decide

private def q10Shape16T212 : Tree := (.split 5 (.split 11 (.split 1 (.split 7 (.split 4 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 6 9))) (.split 3 (.tip (.cover 0 3 5 7 8)) (.tip (.cover 0 1 2 4 8)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))
private theorem q10Shape16T212OK : fastTreeOK (forms 16) 136323072 132104192 q10Shape16T212=true := by decide

private def q10Shape16T210 : Tree := .split 21 q10Shape16T211 q10Shape16T212
private theorem q10Shape16T210OK : fastTreeOK (forms 16) 134225920 132104192 q10Shape16T210=true := by
  change (fastTreeOK (forms 16) 134225920 (132104192 ||| 2^21) q10Shape16T211 &&
    fastTreeOK (forms 16) (134225920 ||| 2^21) 132104192 q10Shape16T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T211OK,q10Shape16T212OK⟩

private def q10Shape16T213 : Tree := (.split 21 (.split 6 (.split 12 (.split 1 (.split 7 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 3 4 6 8))) (.split 3 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 2 4 8)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape16T213OK : fastTreeOK (forms 16) 135274496 131055616 q10Shape16T213=true := by decide

private def q10Shape16T209 : Tree := .split 20 q10Shape16T210 q10Shape16T213
private theorem q10Shape16T209OK : fastTreeOK (forms 16) 134225920 131055616 q10Shape16T209=true := by
  change (fastTreeOK (forms 16) 134225920 (131055616 ||| 2^20) q10Shape16T210 &&
    fastTreeOK (forms 16) (134225920 ||| 2^20) 131055616 q10Shape16T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T210OK,q10Shape16T213OK⟩

private def q10Shape16T214 : Tree := (.split 21 (.split 5 (.split 11 (.split 2 (.split 8 (.split 20 (.split 4 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9))) (.split 3 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 4 8)))) (.split 6 (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 6 7 9)))
private theorem q10Shape16T214OK : fastTreeOK (forms 16) 134356992 130924544 q10Shape16T214=true := by decide

private def q10Shape16T208 : Tree := .split 17 q10Shape16T209 q10Shape16T214
private theorem q10Shape16T208OK : fastTreeOK (forms 16) 134225920 130924544 q10Shape16T208=true := by
  change (fastTreeOK (forms 16) 134225920 (130924544 ||| 2^17) q10Shape16T209 &&
    fastTreeOK (forms 16) (134225920 ||| 2^17) 130924544 q10Shape16T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T209OK,q10Shape16T214OK⟩

private def q10Shape16T215 : Tree := (.split 17 (.split 20 (.split 6 (.split 12 (.split 2 (.split 8 (.split 21 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 3 5 6 8))) (.split 3 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 4 8)))) (.split 5 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape16T215OK : fastTreeOK (forms 16) 134291456 130859008 q10Shape16T215=true := by decide

private def q10Shape16T207 : Tree := .split 16 q10Shape16T208 q10Shape16T215
private theorem q10Shape16T207OK : fastTreeOK (forms 16) 134225920 130859008 q10Shape16T207=true := by
  change (fastTreeOK (forms 16) 134225920 (130859008 ||| 2^16) q10Shape16T208 &&
    fastTreeOK (forms 16) (134225920 ||| 2^16) 130859008 q10Shape16T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T208OK,q10Shape16T215OK⟩

private def q10Shape16T216 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape16T216OK : fastTreeOK (forms 16) 151003136 114081792 q10Shape16T216=true := by decide

private def q10Shape16T206 : Tree := .split 24 q10Shape16T207 q10Shape16T216
private theorem q10Shape16T206OK : fastTreeOK (forms 16) 134225920 114081792 q10Shape16T206=true := by
  change (fastTreeOK (forms 16) 134225920 (114081792 ||| 2^24) q10Shape16T207 &&
    fastTreeOK (forms 16) (134225920 ||| 2^24) 114081792 q10Shape16T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T207OK,q10Shape16T216OK⟩

private def q10Shape16T217 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape16T217OK : fastTreeOK (forms 16) 142614528 105693184 q10Shape16T217=true := by decide

private def q10Shape16T205 : Tree := .split 23 q10Shape16T206 q10Shape16T217
private theorem q10Shape16T205OK : fastTreeOK (forms 16) 134225920 105693184 q10Shape16T205=true := by
  change (fastTreeOK (forms 16) 134225920 (105693184 ||| 2^23) q10Shape16T206 &&
    fastTreeOK (forms 16) (134225920 ||| 2^23) 105693184 q10Shape16T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T206OK,q10Shape16T217OK⟩

private def q10Shape16T218 : Tree := (.tip (.cover 0 1 4 6 8))
private theorem q10Shape16T218OK : fastTreeOK (forms 16) 138420224 101498880 q10Shape16T218=true := by decide

private def q10Shape16T204 : Tree := .split 22 q10Shape16T205 q10Shape16T218
private theorem q10Shape16T204OK : fastTreeOK (forms 16) 134225920 101498880 q10Shape16T204=true := by
  change (fastTreeOK (forms 16) 134225920 (101498880 ||| 2^22) q10Shape16T205 &&
    fastTreeOK (forms 16) (134225920 ||| 2^22) 101498880 q10Shape16T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T205OK,q10Shape16T218OK⟩

private def q10Shape16T219 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape16T219OK : fastTreeOK (forms 16) 134750208 100974592 q10Shape16T219=true := by decide

private def q10Shape16T203 : Tree := .split 19 q10Shape16T204 q10Shape16T219
private theorem q10Shape16T203OK : fastTreeOK (forms 16) 134225920 100974592 q10Shape16T203=true := by
  change (fastTreeOK (forms 16) 134225920 (100974592 ||| 2^19) q10Shape16T204 &&
    fastTreeOK (forms 16) (134225920 ||| 2^19) 100974592 q10Shape16T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T204OK,q10Shape16T219OK⟩

private def q10Shape16T220 : Tree := (.tip (.cover 0 1 4 6 8))
private theorem q10Shape16T220OK : fastTreeOK (forms 16) 134258688 100941824 q10Shape16T220=true := by decide

private def q10Shape16T202 : Tree := .split 15 q10Shape16T203 q10Shape16T220
private theorem q10Shape16T202OK : fastTreeOK (forms 16) 134225920 100941824 q10Shape16T202=true := by
  change (fastTreeOK (forms 16) 134225920 (100941824 ||| 2^15) q10Shape16T203 &&
    fastTreeOK (forms 16) (134225920 ||| 2^15) 100941824 q10Shape16T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T203OK,q10Shape16T220OK⟩

private def q10Shape16T221 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape16T221OK : fastTreeOK (forms 16) 134488064 100679680 q10Shape16T221=true := by decide

private def q10Shape16T201 : Tree := .split 18 q10Shape16T202 q10Shape16T221
private theorem q10Shape16T201OK : fastTreeOK (forms 16) 134225920 100679680 q10Shape16T201=true := by
  change (fastTreeOK (forms 16) 134225920 (100679680 ||| 2^18) q10Shape16T202 &&
    fastTreeOK (forms 16) (134225920 ||| 2^18) 100679680 q10Shape16T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T202OK,q10Shape16T221OK⟩

private def q10Shape16T222 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape16T222OK : fastTreeOK (forms 16) 134242304 100663296 q10Shape16T222=true := by decide

private def q10Shape16T200 : Tree := .split 14 q10Shape16T201 q10Shape16T222
private theorem q10Shape16T200OK : fastTreeOK (forms 16) 134225920 100663296 q10Shape16T200=true := by
  change (fastTreeOK (forms 16) 134225920 (100663296 ||| 2^14) q10Shape16T201 &&
    fastTreeOK (forms 16) (134225920 ||| 2^14) 100663296 q10Shape16T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T201OK,q10Shape16T222OK⟩

private def q10Shape16T146 : Tree := .split 13 q10Shape16T147 q10Shape16T200
private theorem q10Shape16T146OK : fastTreeOK (forms 16) 134217728 100663296 q10Shape16T146=true := by
  change (fastTreeOK (forms 16) 134217728 (100663296 ||| 2^13) q10Shape16T147 &&
    fastTreeOK (forms 16) (134217728 ||| 2^13) 100663296 q10Shape16T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T147OK,q10Shape16T200OK⟩

private def q10Shape16T2 : Tree := .split 27 q10Shape16T3 q10Shape16T146
private theorem q10Shape16T2OK : fastTreeOK (forms 16) 0 100663296 q10Shape16T2=true := by
  change (fastTreeOK (forms 16) 0 (100663296 ||| 2^27) q10Shape16T3 &&
    fastTreeOK (forms 16) (0 ||| 2^27) 100663296 q10Shape16T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T3OK,q10Shape16T146OK⟩

private def q10Shape16T233 : Tree := (.split 22 (.split 23 (.tip (.cover 0 1 2 3 9)) (.split 4 (.split 6 (.split 10 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 8 9)))) (.split 23 (.tip (.cover 0 1 2 3 7)) (.split 24 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6)))))
private theorem q10Shape16T233OK : fastTreeOK (forms 16) 67108864 171958272 q10Shape16T233=true := by decide

private def q10Shape16T234 : Tree := (.split 23 (.split 22 (.tip (.cover 0 1 2 3 9)) (.split 24 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 4 6 9)))
private theorem q10Shape16T234OK : fastTreeOK (forms 16) 69206016 169861120 q10Shape16T234=true := by decide

private def q10Shape16T232 : Tree := .split 21 q10Shape16T233 q10Shape16T234
private theorem q10Shape16T232OK : fastTreeOK (forms 16) 67108864 169861120 q10Shape16T232=true := by
  change (fastTreeOK (forms 16) 67108864 (169861120 ||| 2^21) q10Shape16T233 &&
    fastTreeOK (forms 16) (67108864 ||| 2^21) 169861120 q10Shape16T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T233OK,q10Shape16T234OK⟩

private def q10Shape16T235 : Tree := (.split 22 (.split 23 (.split 24 (.split 4 (.split 6 (.split 10 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 5 7)))
private theorem q10Shape16T235OK : fastTreeOK (forms 16) 68157440 168812544 q10Shape16T235=true := by decide

private def q10Shape16T231 : Tree := .split 20 q10Shape16T232 q10Shape16T235
private theorem q10Shape16T231OK : fastTreeOK (forms 16) 67108864 168812544 q10Shape16T231=true := by
  change (fastTreeOK (forms 16) 67108864 (168812544 ||| 2^20) q10Shape16T232 &&
    fastTreeOK (forms 16) (67108864 ||| 2^20) 168812544 q10Shape16T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T232OK,q10Shape16T235OK⟩

private def q10Shape16T236 : Tree := (.split 22 (.split 23 (.split 20 (.split 21 (.split 24 (.tip (.cover 0 1 2 3 7)) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 2 3 9))) (.split 21 (.split 24 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape16T236OK : fastTreeOK (forms 16) 67633152 168288256 q10Shape16T236=true := by decide

private def q10Shape16T230 : Tree := .split 19 q10Shape16T231 q10Shape16T236
private theorem q10Shape16T230OK : fastTreeOK (forms 16) 67108864 168288256 q10Shape16T230=true := by
  change (fastTreeOK (forms 16) 67108864 (168288256 ||| 2^19) q10Shape16T231 &&
    fastTreeOK (forms 16) (67108864 ||| 2^19) 168288256 q10Shape16T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T231OK,q10Shape16T236OK⟩

private def q10Shape16T237 : Tree := (.split 20 (.split 21 (.split 23 (.split 24 (.split 1 (.split 19 (.split 22 (.tip (.cover 0 1 2 3 9)) (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 9)))) (.split 22 (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 4 7 8)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 6 8 9))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape16T237OK : fastTreeOK (forms 16) 67239936 168157184 q10Shape16T237=true := by decide

private def q10Shape16T229 : Tree := .split 17 q10Shape16T230 q10Shape16T237
private theorem q10Shape16T229OK : fastTreeOK (forms 16) 67108864 168157184 q10Shape16T229=true := by
  change (fastTreeOK (forms 16) 67108864 (168157184 ||| 2^17) q10Shape16T230 &&
    fastTreeOK (forms 16) (67108864 ||| 2^17) 168157184 q10Shape16T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T230OK,q10Shape16T237OK⟩

private def q10Shape16T238 : Tree := (.split 19 (.split 20 (.split 21 (.split 22 (.split 23 (.split 24 (.split 4 (.split 6 (.split 10 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape16T238OK : fastTreeOK (forms 16) 67174400 168091648 q10Shape16T238=true := by decide

private def q10Shape16T228 : Tree := .split 16 q10Shape16T229 q10Shape16T238
private theorem q10Shape16T228OK : fastTreeOK (forms 16) 67108864 168091648 q10Shape16T228=true := by
  change (fastTreeOK (forms 16) 67108864 (168091648 ||| 2^16) q10Shape16T229 &&
    fastTreeOK (forms 16) (67108864 ||| 2^16) 168091648 q10Shape16T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T229OK,q10Shape16T238OK⟩

private def q10Shape16T243 : Tree := (.split 16 (.split 17 (.split 1 (.split 21 (.split 24 (.tip (.cover 0 1 2 3 7)) (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 7)))) (.split 24 (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.split 17 (.split 21 (.split 24 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 6))))
private theorem q10Shape16T243OK : fastTreeOK (forms 16) 67141632 182214656 q10Shape16T243=true := by decide

private def q10Shape16T244 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T244OK : fastTreeOK (forms 16) 75530240 173826048 q10Shape16T244=true := by decide

private def q10Shape16T242 : Tree := .split 23 q10Shape16T243 q10Shape16T244
private theorem q10Shape16T242OK : fastTreeOK (forms 16) 67141632 173826048 q10Shape16T242=true := by
  change (fastTreeOK (forms 16) 67141632 (173826048 ||| 2^23) q10Shape16T243 &&
    fastTreeOK (forms 16) (67141632 ||| 2^23) 173826048 q10Shape16T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T243OK,q10Shape16T244OK⟩

private def q10Shape16T245 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape16T245OK : fastTreeOK (forms 16) 71335936 169631744 q10Shape16T245=true := by decide

private def q10Shape16T241 : Tree := .split 22 q10Shape16T242 q10Shape16T245
private theorem q10Shape16T241OK : fastTreeOK (forms 16) 67141632 169631744 q10Shape16T241=true := by
  change (fastTreeOK (forms 16) 67141632 (169631744 ||| 2^22) q10Shape16T242 &&
    fastTreeOK (forms 16) (67141632 ||| 2^22) 169631744 q10Shape16T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T242OK,q10Shape16T245OK⟩

private def q10Shape16T246 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T246OK : fastTreeOK (forms 16) 68190208 168583168 q10Shape16T246=true := by decide

private def q10Shape16T240 : Tree := .split 20 q10Shape16T241 q10Shape16T246
private theorem q10Shape16T240OK : fastTreeOK (forms 16) 67141632 168583168 q10Shape16T240=true := by
  change (fastTreeOK (forms 16) 67141632 (168583168 ||| 2^20) q10Shape16T241 &&
    fastTreeOK (forms 16) (67141632 ||| 2^20) 168583168 q10Shape16T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T241OK,q10Shape16T246OK⟩

private def q10Shape16T247 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape16T247OK : fastTreeOK (forms 16) 67665920 168058880 q10Shape16T247=true := by decide

private def q10Shape16T239 : Tree := .split 19 q10Shape16T240 q10Shape16T247
private theorem q10Shape16T239OK : fastTreeOK (forms 16) 67141632 168058880 q10Shape16T239=true := by
  change (fastTreeOK (forms 16) 67141632 (168058880 ||| 2^19) q10Shape16T240 &&
    fastTreeOK (forms 16) (67141632 ||| 2^19) 168058880 q10Shape16T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T240OK,q10Shape16T247OK⟩

private def q10Shape16T227 : Tree := .split 15 q10Shape16T228 q10Shape16T239
private theorem q10Shape16T227OK : fastTreeOK (forms 16) 67108864 168058880 q10Shape16T227=true := by
  change (fastTreeOK (forms 16) 67108864 (168058880 ||| 2^15) q10Shape16T228 &&
    fastTreeOK (forms 16) (67108864 ||| 2^15) 168058880 q10Shape16T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T228OK,q10Shape16T239OK⟩

private def q10Shape16T258 : Tree := (.split 5 (.split 11 (.tip (.cover 0 1 4 5 7)) (.split 1 (.tip (.cover 0 1 3 5 7)) (.split 6 (.split 10 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 4 5)))) (.tip (.cover 0 2 5 7 8))))) (.split 1 (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 3 5 7 8))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 1 2 5 7))))
private theorem q10Shape16T258OK : fastTreeOK (forms 16) 67371008 201056272 q10Shape16T258=true := by decide

private def q10Shape16T259 : Tree := (.split 6 (.split 12 (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 1 (.tip (.cover 0 1 3 5 7)) (.tip (.cover 0 2 5 8 9))))) (.split 11 (.split 10 (.tip (.small 1)) (.split 1 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 2 3 5 9)))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))
private theorem q10Shape16T259OK : fastTreeOK (forms 16) 67371024 201056256 q10Shape16T259=true := by decide

private def q10Shape16T257 : Tree := .split 4 q10Shape16T258 q10Shape16T259
private theorem q10Shape16T257OK : fastTreeOK (forms 16) 67371008 201056256 q10Shape16T257=true := by
  change (fastTreeOK (forms 16) 67371008 (201056256 ||| 2^4) q10Shape16T258 &&
    fastTreeOK (forms 16) (67371008 ||| 2^4) 201056256 q10Shape16T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T258OK,q10Shape16T259OK⟩

private def q10Shape16T260 : Tree := (.split 4 (.split 10 (.split 2 (.split 8 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 5 9))) (.split 1 (.tip (.cover 0 3 6 7 8)) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T260OK : fastTreeOK (forms 16) 84148224 184279040 q10Shape16T260=true := by decide

private def q10Shape16T256 : Tree := .split 24 q10Shape16T257 q10Shape16T260
private theorem q10Shape16T256OK : fastTreeOK (forms 16) 67371008 184279040 q10Shape16T256=true := by
  change (fastTreeOK (forms 16) 67371008 (184279040 ||| 2^24) q10Shape16T257 &&
    fastTreeOK (forms 16) (67371008 ||| 2^24) 184279040 q10Shape16T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T257OK,q10Shape16T260OK⟩

private def q10Shape16T261 : Tree := (.split 24 (.split 6 (.split 12 (.split 2 (.split 8 (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 5 7)))) (.split 5 (.tip (.cover 1 3 4 5 7)) (.split 1 (.tip (.cover 0 3 6 8 9)) (.tip (.cover 0 1 2 5 7))))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape16T261OK : fastTreeOK (forms 16) 71565312 180084736 q10Shape16T261=true := by decide

private def q10Shape16T255 : Tree := .split 22 q10Shape16T256 q10Shape16T261
private theorem q10Shape16T255OK : fastTreeOK (forms 16) 67371008 180084736 q10Shape16T255=true := by
  change (fastTreeOK (forms 16) 67371008 (180084736 ||| 2^22) q10Shape16T256 &&
    fastTreeOK (forms 16) (67371008 ||| 2^22) 180084736 q10Shape16T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T256OK,q10Shape16T261OK⟩

private def q10Shape16T262 : Tree := (.split 24 (.split 4 (.split 10 (.split 3 (.split 9 (.split 22 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 6 9))) (.split 1 (.tip (.cover 0 3 5 7 8)) (.tip (.cover 0 1 2 5 7)))) (.split 6 (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape16T262OK : fastTreeOK (forms 16) 69468160 177987584 q10Shape16T262=true := by decide

private def q10Shape16T254 : Tree := .split 21 q10Shape16T255 q10Shape16T262
private theorem q10Shape16T254OK : fastTreeOK (forms 16) 67371008 177987584 q10Shape16T254=true := by
  change (fastTreeOK (forms 16) 67371008 (177987584 ||| 2^21) q10Shape16T255 &&
    fastTreeOK (forms 16) (67371008 ||| 2^21) 177987584 q10Shape16T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T255OK,q10Shape16T262OK⟩

private def q10Shape16T263 : Tree := (.split 21 (.split 22 (.split 6 (.split 12 (.split 3 (.split 9 (.split 24 (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 6 7)))) (.split 5 (.tip (.cover 1 3 4 6 7)) (.split 1 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 2 5 7))))) (.split 4 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape16T263OK : fastTreeOK (forms 16) 67895296 177463296 q10Shape16T263=true := by decide

private def q10Shape16T253 : Tree := .split 19 q10Shape16T254 q10Shape16T263
private theorem q10Shape16T253OK : fastTreeOK (forms 16) 67371008 177463296 q10Shape16T253=true := by
  change (fastTreeOK (forms 16) 67371008 (177463296 ||| 2^19) q10Shape16T254 &&
    fastTreeOK (forms 16) (67371008 ||| 2^19) 177463296 q10Shape16T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T254OK,q10Shape16T263OK⟩

private def q10Shape16T264 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T264OK : fastTreeOK (forms 16) 75759616 169074688 q10Shape16T264=true := by decide

private def q10Shape16T252 : Tree := .split 23 q10Shape16T253 q10Shape16T264
private theorem q10Shape16T252OK : fastTreeOK (forms 16) 67371008 169074688 q10Shape16T252=true := by
  change (fastTreeOK (forms 16) 67371008 (169074688 ||| 2^23) q10Shape16T253 &&
    fastTreeOK (forms 16) (67371008 ||| 2^23) 169074688 q10Shape16T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T253OK,q10Shape16T264OK⟩

private def q10Shape16T265 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T265OK : fastTreeOK (forms 16) 68419584 168026112 q10Shape16T265=true := by decide

private def q10Shape16T251 : Tree := .split 20 q10Shape16T252 q10Shape16T265
private theorem q10Shape16T251OK : fastTreeOK (forms 16) 67371008 168026112 q10Shape16T251=true := by
  change (fastTreeOK (forms 16) 67371008 (168026112 ||| 2^20) q10Shape16T252 &&
    fastTreeOK (forms 16) (67371008 ||| 2^20) 168026112 q10Shape16T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T252OK,q10Shape16T265OK⟩

private def q10Shape16T266 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape16T266OK : fastTreeOK (forms 16) 67502080 167895040 q10Shape16T266=true := by decide

private def q10Shape16T250 : Tree := .split 17 q10Shape16T251 q10Shape16T266
private theorem q10Shape16T250OK : fastTreeOK (forms 16) 67371008 167895040 q10Shape16T250=true := by
  change (fastTreeOK (forms 16) 67371008 (167895040 ||| 2^17) q10Shape16T251 &&
    fastTreeOK (forms 16) (67371008 ||| 2^17) 167895040 q10Shape16T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T251OK,q10Shape16T266OK⟩

private def q10Shape16T267 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T267OK : fastTreeOK (forms 16) 67436544 167829504 q10Shape16T267=true := by decide

private def q10Shape16T249 : Tree := .split 16 q10Shape16T250 q10Shape16T267
private theorem q10Shape16T249OK : fastTreeOK (forms 16) 67371008 167829504 q10Shape16T249=true := by
  change (fastTreeOK (forms 16) 67371008 (167829504 ||| 2^16) q10Shape16T250 &&
    fastTreeOK (forms 16) (67371008 ||| 2^16) 167829504 q10Shape16T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T250OK,q10Shape16T267OK⟩

private def q10Shape16T268 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape16T268OK : fastTreeOK (forms 16) 67403776 167796736 q10Shape16T268=true := by decide

private def q10Shape16T248 : Tree := .split 15 q10Shape16T249 q10Shape16T268
private theorem q10Shape16T248OK : fastTreeOK (forms 16) 67371008 167796736 q10Shape16T248=true := by
  change (fastTreeOK (forms 16) 67371008 (167796736 ||| 2^15) q10Shape16T249 &&
    fastTreeOK (forms 16) (67371008 ||| 2^15) 167796736 q10Shape16T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T249OK,q10Shape16T268OK⟩

private def q10Shape16T226 : Tree := .split 18 q10Shape16T227 q10Shape16T248
private theorem q10Shape16T226OK : fastTreeOK (forms 16) 67108864 167796736 q10Shape16T226=true := by
  change (fastTreeOK (forms 16) 67108864 (167796736 ||| 2^18) q10Shape16T227 &&
    fastTreeOK (forms 16) (67108864 ||| 2^18) 167796736 q10Shape16T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T227OK,q10Shape16T248OK⟩

private def q10Shape16T280 : Tree := (.split 5 (.split 11 (.tip (.cover 0 1 4 5 7)) (.split 2 (.tip (.cover 0 1 3 4 7)) (.split 6 (.split 10 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 4 5)))) (.tip (.cover 0 2 4 7 8))))) (.split 2 (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 1 3 4 7))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 2 4 7))))
private theorem q10Shape16T280OK : fastTreeOK (forms 16) 67125248 201302032 q10Shape16T280=true := by decide

private def q10Shape16T281 : Tree := (.split 6 (.split 12 (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 2 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 4 8 9))))) (.split 11 (.split 10 (.tip (.small 1)) (.split 2 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 2 3 4 9)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape16T281OK : fastTreeOK (forms 16) 67125264 201302016 q10Shape16T281=true := by decide

private def q10Shape16T279 : Tree := .split 4 q10Shape16T280 q10Shape16T281
private theorem q10Shape16T279OK : fastTreeOK (forms 16) 67125248 201302016 q10Shape16T279=true := by
  change (fastTreeOK (forms 16) 67125248 (201302016 ||| 2^4) q10Shape16T280 &&
    fastTreeOK (forms 16) (67125248 ||| 2^4) 201302016 q10Shape16T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T280OK,q10Shape16T281OK⟩

private def q10Shape16T282 : Tree := (.split 4 (.split 10 (.split 1 (.split 7 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 5 9))) (.split 2 (.tip (.cover 0 3 6 7 8)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T282OK : fastTreeOK (forms 16) 83902464 184524800 q10Shape16T282=true := by decide

private def q10Shape16T278 : Tree := .split 24 q10Shape16T279 q10Shape16T282
private theorem q10Shape16T278OK : fastTreeOK (forms 16) 67125248 184524800 q10Shape16T278=true := by
  change (fastTreeOK (forms 16) 67125248 (184524800 ||| 2^24) q10Shape16T279 &&
    fastTreeOK (forms 16) (67125248 ||| 2^24) 184524800 q10Shape16T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T279OK,q10Shape16T282OK⟩

private def q10Shape16T283 : Tree := (.split 24 (.split 6 (.split 12 (.split 1 (.split 7 (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 5 7)))) (.split 5 (.tip (.cover 1 3 4 5 7)) (.split 2 (.tip (.cover 0 3 6 8 9)) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape16T283OK : fastTreeOK (forms 16) 71319552 180330496 q10Shape16T283=true := by decide

private def q10Shape16T277 : Tree := .split 22 q10Shape16T278 q10Shape16T283
private theorem q10Shape16T277OK : fastTreeOK (forms 16) 67125248 180330496 q10Shape16T277=true := by
  change (fastTreeOK (forms 16) 67125248 (180330496 ||| 2^22) q10Shape16T278 &&
    fastTreeOK (forms 16) (67125248 ||| 2^22) 180330496 q10Shape16T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T278OK,q10Shape16T283OK⟩

private def q10Shape16T284 : Tree := (.split 24 (.split 4 (.split 10 (.split 3 (.split 9 (.split 22 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9))) (.split 2 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 4 7)))) (.split 6 (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape16T284OK : fastTreeOK (forms 16) 67256320 180199424 q10Shape16T284=true := by decide

private def q10Shape16T276 : Tree := .split 17 q10Shape16T277 q10Shape16T284
private theorem q10Shape16T276OK : fastTreeOK (forms 16) 67125248 180199424 q10Shape16T276=true := by
  change (fastTreeOK (forms 16) 67125248 (180199424 ||| 2^17) q10Shape16T277 &&
    fastTreeOK (forms 16) (67125248 ||| 2^17) 180199424 q10Shape16T284)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T277OK,q10Shape16T284OK⟩

private def q10Shape16T285 : Tree := (.split 17 (.split 22 (.split 6 (.split 12 (.split 3 (.split 9 (.split 24 (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 5 6 7)))) (.split 5 (.tip (.cover 1 3 5 6 7)) (.split 2 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7))))) (.split 4 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape16T285OK : fastTreeOK (forms 16) 67158016 180166656 q10Shape16T285=true := by decide

private def q10Shape16T275 : Tree := .split 15 q10Shape16T276 q10Shape16T285
private theorem q10Shape16T275OK : fastTreeOK (forms 16) 67125248 180166656 q10Shape16T275=true := by
  change (fastTreeOK (forms 16) 67125248 (180166656 ||| 2^15) q10Shape16T276 &&
    fastTreeOK (forms 16) (67125248 ||| 2^15) 180166656 q10Shape16T285)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T276OK,q10Shape16T285OK⟩

private def q10Shape16T286 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T286OK : fastTreeOK (forms 16) 75513856 171778048 q10Shape16T286=true := by decide

private def q10Shape16T274 : Tree := .split 23 q10Shape16T275 q10Shape16T286
private theorem q10Shape16T274OK : fastTreeOK (forms 16) 67125248 171778048 q10Shape16T274=true := by
  change (fastTreeOK (forms 16) 67125248 (171778048 ||| 2^23) q10Shape16T275 &&
    fastTreeOK (forms 16) (67125248 ||| 2^23) 171778048 q10Shape16T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T275OK,q10Shape16T286OK⟩

private def q10Shape16T287 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape16T287OK : fastTreeOK (forms 16) 69222400 169680896 q10Shape16T287=true := by decide

private def q10Shape16T273 : Tree := .split 21 q10Shape16T274 q10Shape16T287
private theorem q10Shape16T273OK : fastTreeOK (forms 16) 67125248 169680896 q10Shape16T273=true := by
  change (fastTreeOK (forms 16) 67125248 (169680896 ||| 2^21) q10Shape16T274 &&
    fastTreeOK (forms 16) (67125248 ||| 2^21) 169680896 q10Shape16T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T274OK,q10Shape16T287OK⟩

private def q10Shape16T288 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T288OK : fastTreeOK (forms 16) 68173824 168632320 q10Shape16T288=true := by decide

private def q10Shape16T272 : Tree := .split 20 q10Shape16T273 q10Shape16T288
private theorem q10Shape16T272OK : fastTreeOK (forms 16) 67125248 168632320 q10Shape16T272=true := by
  change (fastTreeOK (forms 16) 67125248 (168632320 ||| 2^20) q10Shape16T273 &&
    fastTreeOK (forms 16) (67125248 ||| 2^20) 168632320 q10Shape16T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T273OK,q10Shape16T288OK⟩

private def q10Shape16T289 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape16T289OK : fastTreeOK (forms 16) 67649536 168108032 q10Shape16T289=true := by decide

private def q10Shape16T271 : Tree := .split 19 q10Shape16T272 q10Shape16T289
private theorem q10Shape16T271OK : fastTreeOK (forms 16) 67125248 168108032 q10Shape16T271=true := by
  change (fastTreeOK (forms 16) 67125248 (168108032 ||| 2^19) q10Shape16T272 &&
    fastTreeOK (forms 16) (67125248 ||| 2^19) 168108032 q10Shape16T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T272OK,q10Shape16T289OK⟩

private def q10Shape16T290 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T290OK : fastTreeOK (forms 16) 67190784 168042496 q10Shape16T290=true := by decide

private def q10Shape16T270 : Tree := .split 16 q10Shape16T271 q10Shape16T290
private theorem q10Shape16T270OK : fastTreeOK (forms 16) 67125248 168042496 q10Shape16T270=true := by
  change (fastTreeOK (forms 16) 67125248 (168042496 ||| 2^16) q10Shape16T271 &&
    fastTreeOK (forms 16) (67125248 ||| 2^16) 168042496 q10Shape16T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T271OK,q10Shape16T290OK⟩

private def q10Shape16T291 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape16T291OK : fastTreeOK (forms 16) 67387392 167780352 q10Shape16T291=true := by decide

private def q10Shape16T269 : Tree := .split 18 q10Shape16T270 q10Shape16T291
private theorem q10Shape16T269OK : fastTreeOK (forms 16) 67125248 167780352 q10Shape16T269=true := by
  change (fastTreeOK (forms 16) 67125248 (167780352 ||| 2^18) q10Shape16T270 &&
    fastTreeOK (forms 16) (67125248 ||| 2^18) 167780352 q10Shape16T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T270OK,q10Shape16T291OK⟩

private def q10Shape16T225 : Tree := .split 14 q10Shape16T226 q10Shape16T269
private theorem q10Shape16T225OK : fastTreeOK (forms 16) 67108864 167780352 q10Shape16T225=true := by
  change (fastTreeOK (forms 16) 67108864 (167780352 ||| 2^14) q10Shape16T226 &&
    fastTreeOK (forms 16) (67108864 ||| 2^14) 167780352 q10Shape16T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T226OK,q10Shape16T269OK⟩

private def q10Shape16T304 : Tree := (.split 5 (.split 11 (.tip (.cover 0 1 4 6 7)) (.split 3 (.tip (.cover 0 1 3 4 7)) (.split 6 (.split 10 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 4 6)))) (.tip (.cover 0 2 4 7 8))))) (.split 3 (.split 10 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 1 3 4 7))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 2 4 7))))
private theorem q10Shape16T304OK : fastTreeOK (forms 16) 67117056 201310224 q10Shape16T304=true := by decide

private def q10Shape16T305 : Tree := (.split 6 (.split 12 (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 3 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 4 8 9))))) (.split 11 (.split 10 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 2 3 4 9)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape16T305OK : fastTreeOK (forms 16) 67117072 201310208 q10Shape16T305=true := by decide

private def q10Shape16T303 : Tree := .split 4 q10Shape16T304 q10Shape16T305
private theorem q10Shape16T303OK : fastTreeOK (forms 16) 67117056 201310208 q10Shape16T303=true := by
  change (fastTreeOK (forms 16) 67117056 (201310208 ||| 2^4) q10Shape16T304 &&
    fastTreeOK (forms 16) (67117056 ||| 2^4) 201310208 q10Shape16T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T304OK,q10Shape16T305OK⟩

private def q10Shape16T306 : Tree := (.split 4 (.split 10 (.split 1 (.split 7 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 4 6 9))) (.split 3 (.tip (.cover 0 3 5 7 8)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))
private theorem q10Shape16T306OK : fastTreeOK (forms 16) 69214208 199213056 q10Shape16T306=true := by decide

private def q10Shape16T302 : Tree := .split 21 q10Shape16T303 q10Shape16T306
private theorem q10Shape16T302OK : fastTreeOK (forms 16) 67117056 199213056 q10Shape16T302=true := by
  change (fastTreeOK (forms 16) 67117056 (199213056 ||| 2^21) q10Shape16T303 &&
    fastTreeOK (forms 16) (67117056 ||| 2^21) 199213056 q10Shape16T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T303OK,q10Shape16T306OK⟩

private def q10Shape16T307 : Tree := (.split 21 (.split 6 (.split 12 (.split 1 (.split 7 (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 6 7)))) (.split 5 (.tip (.cover 1 3 4 6 7)) (.split 3 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape16T307OK : fastTreeOK (forms 16) 67641344 198688768 q10Shape16T307=true := by decide

private def q10Shape16T301 : Tree := .split 19 q10Shape16T302 q10Shape16T307
private theorem q10Shape16T301OK : fastTreeOK (forms 16) 67117056 198688768 q10Shape16T301=true := by
  change (fastTreeOK (forms 16) 67117056 (198688768 ||| 2^19) q10Shape16T302 &&
    fastTreeOK (forms 16) (67117056 ||| 2^19) 198688768 q10Shape16T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T302OK,q10Shape16T307OK⟩

private def q10Shape16T308 : Tree := (.split 21 (.split 4 (.split 10 (.split 2 (.split 8 (.split 19 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9))) (.split 3 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 4 7)))) (.split 6 (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape16T308OK : fastTreeOK (forms 16) 67248128 198557696 q10Shape16T308=true := by decide

private def q10Shape16T300 : Tree := .split 17 q10Shape16T301 q10Shape16T308
private theorem q10Shape16T300OK : fastTreeOK (forms 16) 67117056 198557696 q10Shape16T300=true := by
  change (fastTreeOK (forms 16) 67117056 (198557696 ||| 2^17) q10Shape16T301 &&
    fastTreeOK (forms 16) (67117056 ||| 2^17) 198557696 q10Shape16T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T301OK,q10Shape16T308OK⟩

private def q10Shape16T309 : Tree := (.split 17 (.split 19 (.split 6 (.split 12 (.split 2 (.split 8 (.split 21 (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 5 6 7)))) (.split 5 (.tip (.cover 1 3 5 6 7)) (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7))))) (.split 4 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape16T309OK : fastTreeOK (forms 16) 67149824 198524928 q10Shape16T309=true := by decide

private def q10Shape16T299 : Tree := .split 15 q10Shape16T300 q10Shape16T309
private theorem q10Shape16T299OK : fastTreeOK (forms 16) 67117056 198524928 q10Shape16T299=true := by
  change (fastTreeOK (forms 16) 67117056 (198524928 ||| 2^15) q10Shape16T300 &&
    fastTreeOK (forms 16) (67117056 ||| 2^15) 198524928 q10Shape16T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T300OK,q10Shape16T309OK⟩

private def q10Shape16T310 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape16T310OK : fastTreeOK (forms 16) 83894272 181747712 q10Shape16T310=true := by decide

private def q10Shape16T298 : Tree := .split 24 q10Shape16T299 q10Shape16T310
private theorem q10Shape16T298OK : fastTreeOK (forms 16) 67117056 181747712 q10Shape16T298=true := by
  change (fastTreeOK (forms 16) 67117056 (181747712 ||| 2^24) q10Shape16T299 &&
    fastTreeOK (forms 16) (67117056 ||| 2^24) 181747712 q10Shape16T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T299OK,q10Shape16T310OK⟩

private def q10Shape16T311 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T311OK : fastTreeOK (forms 16) 75505664 173359104 q10Shape16T311=true := by decide

private def q10Shape16T297 : Tree := .split 23 q10Shape16T298 q10Shape16T311
private theorem q10Shape16T297OK : fastTreeOK (forms 16) 67117056 173359104 q10Shape16T297=true := by
  change (fastTreeOK (forms 16) 67117056 (173359104 ||| 2^23) q10Shape16T298 &&
    fastTreeOK (forms 16) (67117056 ||| 2^23) 173359104 q10Shape16T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T298OK,q10Shape16T311OK⟩

private def q10Shape16T312 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape16T312OK : fastTreeOK (forms 16) 71311360 169164800 q10Shape16T312=true := by decide

private def q10Shape16T296 : Tree := .split 22 q10Shape16T297 q10Shape16T312
private theorem q10Shape16T296OK : fastTreeOK (forms 16) 67117056 169164800 q10Shape16T296=true := by
  change (fastTreeOK (forms 16) 67117056 (169164800 ||| 2^22) q10Shape16T297 &&
    fastTreeOK (forms 16) (67117056 ||| 2^22) 169164800 q10Shape16T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T297OK,q10Shape16T312OK⟩

private def q10Shape16T313 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T313OK : fastTreeOK (forms 16) 68165632 168116224 q10Shape16T313=true := by decide

private def q10Shape16T295 : Tree := .split 20 q10Shape16T296 q10Shape16T313
private theorem q10Shape16T295OK : fastTreeOK (forms 16) 67117056 168116224 q10Shape16T295=true := by
  change (fastTreeOK (forms 16) 67117056 (168116224 ||| 2^20) q10Shape16T296 &&
    fastTreeOK (forms 16) (67117056 ||| 2^20) 168116224 q10Shape16T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T296OK,q10Shape16T313OK⟩

private def q10Shape16T314 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T314OK : fastTreeOK (forms 16) 67182592 168050688 q10Shape16T314=true := by decide

private def q10Shape16T294 : Tree := .split 16 q10Shape16T295 q10Shape16T314
private theorem q10Shape16T294OK : fastTreeOK (forms 16) 67117056 168050688 q10Shape16T294=true := by
  change (fastTreeOK (forms 16) 67117056 (168050688 ||| 2^16) q10Shape16T295 &&
    fastTreeOK (forms 16) (67117056 ||| 2^16) 168050688 q10Shape16T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T295OK,q10Shape16T314OK⟩

private def q10Shape16T315 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape16T315OK : fastTreeOK (forms 16) 67379200 167788544 q10Shape16T315=true := by decide

private def q10Shape16T293 : Tree := .split 18 q10Shape16T294 q10Shape16T315
private theorem q10Shape16T293OK : fastTreeOK (forms 16) 67117056 167788544 q10Shape16T293=true := by
  change (fastTreeOK (forms 16) 67117056 (167788544 ||| 2^18) q10Shape16T294 &&
    fastTreeOK (forms 16) (67117056 ||| 2^18) 167788544 q10Shape16T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T294OK,q10Shape16T315OK⟩

private def q10Shape16T316 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape16T316OK : fastTreeOK (forms 16) 67133440 167772160 q10Shape16T316=true := by decide

private def q10Shape16T292 : Tree := .split 14 q10Shape16T293 q10Shape16T316
private theorem q10Shape16T292OK : fastTreeOK (forms 16) 67117056 167772160 q10Shape16T292=true := by
  change (fastTreeOK (forms 16) 67117056 (167772160 ||| 2^14) q10Shape16T293 &&
    fastTreeOK (forms 16) (67117056 ||| 2^14) 167772160 q10Shape16T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T293OK,q10Shape16T316OK⟩

private def q10Shape16T224 : Tree := .split 13 q10Shape16T225 q10Shape16T292
private theorem q10Shape16T224OK : fastTreeOK (forms 16) 67108864 167772160 q10Shape16T224=true := by
  change (fastTreeOK (forms 16) 67108864 (167772160 ||| 2^13) q10Shape16T225 &&
    fastTreeOK (forms 16) (67108864 ||| 2^13) 167772160 q10Shape16T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T225OK,q10Shape16T292OK⟩

private def q10Shape16T317 : Tree := (.split 13 (.split 14 (.split 18 (.split 17 (.split 21 (.split 24 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))
private theorem q10Shape16T317OK : fastTreeOK (forms 16) 201326592 33554432 q10Shape16T317=true := by decide

private def q10Shape16T223 : Tree := .split 27 q10Shape16T224 q10Shape16T317
private theorem q10Shape16T223OK : fastTreeOK (forms 16) 67108864 33554432 q10Shape16T223=true := by
  change (fastTreeOK (forms 16) 67108864 (33554432 ||| 2^27) q10Shape16T224 &&
    fastTreeOK (forms 16) (67108864 ||| 2^27) 33554432 q10Shape16T317)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T224OK,q10Shape16T317OK⟩

private def q10Shape16T1 : Tree := .split 26 q10Shape16T2 q10Shape16T223
private theorem q10Shape16T1OK : fastTreeOK (forms 16) 0 33554432 q10Shape16T1=true := by
  change (fastTreeOK (forms 16) 0 (33554432 ||| 2^26) q10Shape16T2 &&
    fastTreeOK (forms 16) (0 ||| 2^26) 33554432 q10Shape16T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T2OK,q10Shape16T223OK⟩

private def q10Shape16T329 : Tree := (.split 22 (.split 24 (.tip (.cover 0 1 2 3 8)) (.split 4 (.split 5 (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9)))) (.split 23 (.split 24 (.tip (.cover 0 1 2 3 7)) (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 2 3 6))))
private theorem q10Shape16T329OK : fastTreeOK (forms 16) 33554432 205512704 q10Shape16T329=true := by decide

private def q10Shape16T330 : Tree := (.split 22 (.split 23 (.split 24 (.split 4 (.split 5 (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 7)))
private theorem q10Shape16T330OK : fastTreeOK (forms 16) 35651584 203415552 q10Shape16T330=true := by decide

private def q10Shape16T328 : Tree := .split 21 q10Shape16T329 q10Shape16T330
private theorem q10Shape16T328OK : fastTreeOK (forms 16) 33554432 203415552 q10Shape16T328=true := by
  change (fastTreeOK (forms 16) 33554432 (203415552 ||| 2^21) q10Shape16T329 &&
    fastTreeOK (forms 16) (33554432 ||| 2^21) 203415552 q10Shape16T330)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T329OK,q10Shape16T330OK⟩

private def q10Shape16T331 : Tree := (.split 23 (.split 24 (.split 21 (.split 22 (.tip (.cover 0 1 2 3 8)) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 7)))) (.split 22 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape16T331OK : fastTreeOK (forms 16) 34603008 202366976 q10Shape16T331=true := by decide

private def q10Shape16T327 : Tree := .split 20 q10Shape16T328 q10Shape16T331
private theorem q10Shape16T327OK : fastTreeOK (forms 16) 33554432 202366976 q10Shape16T327=true := by
  change (fastTreeOK (forms 16) 33554432 (202366976 ||| 2^20) q10Shape16T328 &&
    fastTreeOK (forms 16) (33554432 ||| 2^20) 202366976 q10Shape16T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T328OK,q10Shape16T331OK⟩

private def q10Shape16T332 : Tree := (.split 22 (.split 24 (.split 20 (.split 21 (.split 23 (.tip (.cover 0 1 2 3 7)) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 8)))) (.split 23 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6)))) (.split 21 (.tip (.cover 0 1 2 3 8)) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 7 9)))
private theorem q10Shape16T332OK : fastTreeOK (forms 16) 34078720 201842688 q10Shape16T332=true := by decide

private def q10Shape16T326 : Tree := .split 19 q10Shape16T327 q10Shape16T332
private theorem q10Shape16T326OK : fastTreeOK (forms 16) 33554432 201842688 q10Shape16T326=true := by
  change (fastTreeOK (forms 16) 33554432 (201842688 ||| 2^19) q10Shape16T327 &&
    fastTreeOK (forms 16) (33554432 ||| 2^19) 201842688 q10Shape16T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T327OK,q10Shape16T332OK⟩

private def q10Shape16T333 : Tree := (.split 19 (.split 20 (.split 21 (.split 22 (.split 23 (.split 24 (.split 4 (.split 5 (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape16T333OK : fastTreeOK (forms 16) 33685504 201711616 q10Shape16T333=true := by decide

private def q10Shape16T325 : Tree := .split 17 q10Shape16T326 q10Shape16T333
private theorem q10Shape16T325OK : fastTreeOK (forms 16) 33554432 201711616 q10Shape16T325=true := by
  change (fastTreeOK (forms 16) 33554432 (201711616 ||| 2^17) q10Shape16T326 &&
    fastTreeOK (forms 16) (33554432 ||| 2^17) 201711616 q10Shape16T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T326OK,q10Shape16T333OK⟩

private def q10Shape16T336 : Tree := (.split 23 (.split 24 (.split 17 (.split 1 (.split 19 (.split 22 (.tip (.cover 0 1 2 3 8)) (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 8)))) (.split 22 (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 4 7 9)))) (.tip (.cover 0 1 2 3 7))) (.split 19 (.split 22 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 6)))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape16T336OK : fastTreeOK (forms 16) 33619968 204791808 q10Shape16T336=true := by decide

private def q10Shape16T337 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape16T337OK : fastTreeOK (forms 16) 35717120 202694656 q10Shape16T337=true := by decide

private def q10Shape16T335 : Tree := .split 21 q10Shape16T336 q10Shape16T337
private theorem q10Shape16T335OK : fastTreeOK (forms 16) 33619968 202694656 q10Shape16T335=true := by
  change (fastTreeOK (forms 16) 33619968 (202694656 ||| 2^21) q10Shape16T336 &&
    fastTreeOK (forms 16) (33619968 ||| 2^21) 202694656 q10Shape16T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T336OK,q10Shape16T337OK⟩

private def q10Shape16T338 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape16T338OK : fastTreeOK (forms 16) 34668544 201646080 q10Shape16T338=true := by decide

private def q10Shape16T334 : Tree := .split 20 q10Shape16T335 q10Shape16T338
private theorem q10Shape16T334OK : fastTreeOK (forms 16) 33619968 201646080 q10Shape16T334=true := by
  change (fastTreeOK (forms 16) 33619968 (201646080 ||| 2^20) q10Shape16T335 &&
    fastTreeOK (forms 16) (33619968 ||| 2^20) 201646080 q10Shape16T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T335OK,q10Shape16T338OK⟩

private def q10Shape16T324 : Tree := .split 16 q10Shape16T325 q10Shape16T334
private theorem q10Shape16T324OK : fastTreeOK (forms 16) 33554432 201646080 q10Shape16T324=true := by
  change (fastTreeOK (forms 16) 33554432 (201646080 ||| 2^16) q10Shape16T325 &&
    fastTreeOK (forms 16) (33554432 ||| 2^16) 201646080 q10Shape16T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T325OK,q10Shape16T334OK⟩

private def q10Shape16T343 : Tree := (.split 16 (.split 17 (.split 1 (.split 20 (.split 23 (.tip (.cover 0 1 2 3 7)) (.split 3 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 7)))) (.split 23 (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 2 3 8))) (.split 20 (.split 23 (.split 4 (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 6)))) (.split 17 (.tip (.cover 0 1 2 3 8)) (.tip (.cover 0 1 4 5 6))))
private theorem q10Shape16T343OK : fastTreeOK (forms 16) 33587200 225206272 q10Shape16T343=true := by decide

private def q10Shape16T344 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T344OK : fastTreeOK (forms 16) 50364416 208429056 q10Shape16T344=true := by decide

private def q10Shape16T342 : Tree := .split 24 q10Shape16T343 q10Shape16T344
private theorem q10Shape16T342OK : fastTreeOK (forms 16) 33587200 208429056 q10Shape16T342=true := by
  change (fastTreeOK (forms 16) 33587200 (208429056 ||| 2^24) q10Shape16T343 &&
    fastTreeOK (forms 16) (33587200 ||| 2^24) 208429056 q10Shape16T344)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T343OK,q10Shape16T344OK⟩

private def q10Shape16T345 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape16T345OK : fastTreeOK (forms 16) 37781504 204234752 q10Shape16T345=true := by decide

private def q10Shape16T341 : Tree := .split 22 q10Shape16T342 q10Shape16T345
private theorem q10Shape16T341OK : fastTreeOK (forms 16) 33587200 204234752 q10Shape16T341=true := by
  change (fastTreeOK (forms 16) 33587200 (204234752 ||| 2^22) q10Shape16T342 &&
    fastTreeOK (forms 16) (33587200 ||| 2^22) 204234752 q10Shape16T345)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T342OK,q10Shape16T345OK⟩

private def q10Shape16T346 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T346OK : fastTreeOK (forms 16) 35684352 202137600 q10Shape16T346=true := by decide

private def q10Shape16T340 : Tree := .split 21 q10Shape16T341 q10Shape16T346
private theorem q10Shape16T340OK : fastTreeOK (forms 16) 33587200 202137600 q10Shape16T340=true := by
  change (fastTreeOK (forms 16) 33587200 (202137600 ||| 2^21) q10Shape16T341 &&
    fastTreeOK (forms 16) (33587200 ||| 2^21) 202137600 q10Shape16T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T341OK,q10Shape16T346OK⟩

private def q10Shape16T347 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape16T347OK : fastTreeOK (forms 16) 34111488 201613312 q10Shape16T347=true := by decide

private def q10Shape16T339 : Tree := .split 19 q10Shape16T340 q10Shape16T347
private theorem q10Shape16T339OK : fastTreeOK (forms 16) 33587200 201613312 q10Shape16T339=true := by
  change (fastTreeOK (forms 16) 33587200 (201613312 ||| 2^19) q10Shape16T340 &&
    fastTreeOK (forms 16) (33587200 ||| 2^19) 201613312 q10Shape16T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T340OK,q10Shape16T347OK⟩

private def q10Shape16T323 : Tree := .split 15 q10Shape16T324 q10Shape16T339
private theorem q10Shape16T323OK : fastTreeOK (forms 16) 33554432 201613312 q10Shape16T323=true := by
  change (fastTreeOK (forms 16) 33554432 (201613312 ||| 2^15) q10Shape16T324 &&
    fastTreeOK (forms 16) (33554432 ||| 2^15) 201613312 q10Shape16T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T324OK,q10Shape16T339OK⟩

private def q10Shape16T358 : Tree := (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 3 4 5)))) (.split 1 (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 1 2 5 7)))) (.split 10 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.tip (.cover 0 1 3 5 7)) (.tip (.cover 0 2 5 7 9))))) (.split 12 (.split 11 (.tip (.small 1)) (.split 1 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 2 3 5 7)))) (.tip (.cover 0 1 2 3 5))))
private theorem q10Shape16T358OK : fastTreeOK (forms 16) 33816576 234610704 q10Shape16T358=true := by decide

private def q10Shape16T359 : Tree := (.split 5 (.split 11 (.split 6 (.split 10 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.tip (.cover 0 1 3 5 7)) (.tip (.cover 0 2 5 8 9))))) (.split 12 (.split 10 (.tip (.small 1)) (.split 1 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 2 3 5 8)))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))
private theorem q10Shape16T359OK : fastTreeOK (forms 16) 33816592 234610688 q10Shape16T359=true := by decide

private def q10Shape16T357 : Tree := .split 4 q10Shape16T358 q10Shape16T359
private theorem q10Shape16T357OK : fastTreeOK (forms 16) 33816576 234610688 q10Shape16T357=true := by
  change (fastTreeOK (forms 16) 33816576 (234610688 ||| 2^4) q10Shape16T358 &&
    fastTreeOK (forms 16) (33816576 ||| 2^4) 234610688 q10Shape16T359)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T358OK,q10Shape16T359OK⟩

private def q10Shape16T360 : Tree := (.split 4 (.split 10 (.split 2 (.split 8 (.split 5 (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 2 4 5 8)))) (.split 6 (.tip (.cover 1 3 4 5 8)) (.split 1 (.tip (.cover 0 3 6 7 9)) (.tip (.cover 0 1 2 5 7))))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T360OK : fastTreeOK (forms 16) 42205184 226222080 q10Shape16T360=true := by decide

private def q10Shape16T356 : Tree := .split 23 q10Shape16T357 q10Shape16T360
private theorem q10Shape16T356OK : fastTreeOK (forms 16) 33816576 226222080 q10Shape16T356=true := by
  change (fastTreeOK (forms 16) 33816576 (226222080 ||| 2^23) q10Shape16T357 &&
    fastTreeOK (forms 16) (33816576 ||| 2^23) 226222080 q10Shape16T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T357OK,q10Shape16T360OK⟩

private def q10Shape16T361 : Tree := (.split 23 (.split 5 (.split 11 (.split 2 (.split 8 (.split 4 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 5 7)))) (.split 6 (.tip (.cover 1 3 4 5 7)) (.split 1 (.tip (.cover 0 3 6 8 9)) (.tip (.cover 0 1 2 5 7))))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 4 6 9)))
private theorem q10Shape16T361OK : fastTreeOK (forms 16) 38010880 222027776 q10Shape16T361=true := by decide

private def q10Shape16T355 : Tree := .split 22 q10Shape16T356 q10Shape16T361
private theorem q10Shape16T355OK : fastTreeOK (forms 16) 33816576 222027776 q10Shape16T355=true := by
  change (fastTreeOK (forms 16) 33816576 (222027776 ||| 2^22) q10Shape16T356 &&
    fastTreeOK (forms 16) (33816576 ||| 2^22) 222027776 q10Shape16T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T356OK,q10Shape16T361OK⟩

private def q10Shape16T362 : Tree := (.split 23 (.split 4 (.split 10 (.split 3 (.split 9 (.split 22 (.split 5 (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 2 4 6 8)))) (.split 6 (.tip (.cover 1 3 4 6 8)) (.split 1 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 2 5 7))))) (.split 5 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape16T362OK : fastTreeOK (forms 16) 34865152 220979200 q10Shape16T362=true := by decide

private def q10Shape16T354 : Tree := .split 20 q10Shape16T355 q10Shape16T362
private theorem q10Shape16T354OK : fastTreeOK (forms 16) 33816576 220979200 q10Shape16T354=true := by
  change (fastTreeOK (forms 16) 33816576 (220979200 ||| 2^20) q10Shape16T355 &&
    fastTreeOK (forms 16) (33816576 ||| 2^20) 220979200 q10Shape16T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T355OK,q10Shape16T362OK⟩

private def q10Shape16T363 : Tree := (.split 20 (.split 22 (.split 5 (.split 11 (.split 3 (.split 9 (.split 23 (.split 4 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 6 7)))) (.split 6 (.tip (.cover 1 3 4 6 7)) (.split 1 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 2 5 7))))) (.split 4 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 4 5 9)))
private theorem q10Shape16T363OK : fastTreeOK (forms 16) 34340864 220454912 q10Shape16T363=true := by decide

private def q10Shape16T353 : Tree := .split 19 q10Shape16T354 q10Shape16T363
private theorem q10Shape16T353OK : fastTreeOK (forms 16) 33816576 220454912 q10Shape16T353=true := by
  change (fastTreeOK (forms 16) 33816576 (220454912 ||| 2^19) q10Shape16T354 &&
    fastTreeOK (forms 16) (33816576 ||| 2^19) 220454912 q10Shape16T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T354OK,q10Shape16T363OK⟩

private def q10Shape16T364 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T364OK : fastTreeOK (forms 16) 50593792 203677696 q10Shape16T364=true := by decide

private def q10Shape16T352 : Tree := .split 24 q10Shape16T353 q10Shape16T364
private theorem q10Shape16T352OK : fastTreeOK (forms 16) 33816576 203677696 q10Shape16T352=true := by
  change (fastTreeOK (forms 16) 33816576 (203677696 ||| 2^24) q10Shape16T353 &&
    fastTreeOK (forms 16) (33816576 ||| 2^24) 203677696 q10Shape16T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T353OK,q10Shape16T364OK⟩

private def q10Shape16T365 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T365OK : fastTreeOK (forms 16) 35913728 201580544 q10Shape16T365=true := by decide

private def q10Shape16T351 : Tree := .split 21 q10Shape16T352 q10Shape16T365
private theorem q10Shape16T351OK : fastTreeOK (forms 16) 33816576 201580544 q10Shape16T351=true := by
  change (fastTreeOK (forms 16) 33816576 (201580544 ||| 2^21) q10Shape16T352 &&
    fastTreeOK (forms 16) (33816576 ||| 2^21) 201580544 q10Shape16T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T352OK,q10Shape16T365OK⟩

private def q10Shape16T366 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T366OK : fastTreeOK (forms 16) 33947648 201449472 q10Shape16T366=true := by decide

private def q10Shape16T350 : Tree := .split 17 q10Shape16T351 q10Shape16T366
private theorem q10Shape16T350OK : fastTreeOK (forms 16) 33816576 201449472 q10Shape16T350=true := by
  change (fastTreeOK (forms 16) 33816576 (201449472 ||| 2^17) q10Shape16T351 &&
    fastTreeOK (forms 16) (33816576 ||| 2^17) 201449472 q10Shape16T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T351OK,q10Shape16T366OK⟩

private def q10Shape16T367 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape16T367OK : fastTreeOK (forms 16) 33882112 201383936 q10Shape16T367=true := by decide

private def q10Shape16T349 : Tree := .split 16 q10Shape16T350 q10Shape16T367
private theorem q10Shape16T349OK : fastTreeOK (forms 16) 33816576 201383936 q10Shape16T349=true := by
  change (fastTreeOK (forms 16) 33816576 (201383936 ||| 2^16) q10Shape16T350 &&
    fastTreeOK (forms 16) (33816576 ||| 2^16) 201383936 q10Shape16T367)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T350OK,q10Shape16T367OK⟩

private def q10Shape16T368 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape16T368OK : fastTreeOK (forms 16) 33849344 201351168 q10Shape16T368=true := by decide

private def q10Shape16T348 : Tree := .split 15 q10Shape16T349 q10Shape16T368
private theorem q10Shape16T348OK : fastTreeOK (forms 16) 33816576 201351168 q10Shape16T348=true := by
  change (fastTreeOK (forms 16) 33816576 (201351168 ||| 2^15) q10Shape16T349 &&
    fastTreeOK (forms 16) (33816576 ||| 2^15) 201351168 q10Shape16T368)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T349OK,q10Shape16T368OK⟩

private def q10Shape16T322 : Tree := .split 18 q10Shape16T323 q10Shape16T348
private theorem q10Shape16T322OK : fastTreeOK (forms 16) 33554432 201351168 q10Shape16T322=true := by
  change (fastTreeOK (forms 16) 33554432 (201351168 ||| 2^18) q10Shape16T323 &&
    fastTreeOK (forms 16) (33554432 ||| 2^18) 201351168 q10Shape16T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T323OK,q10Shape16T348OK⟩

private def q10Shape16T380 : Tree := (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 3 4 5)))) (.split 2 (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 2 4 7)))) (.split 10 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 2 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 4 7 9))))) (.split 12 (.split 11 (.tip (.small 1)) (.split 2 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 2 3 4))))
private theorem q10Shape16T380OK : fastTreeOK (forms 16) 33570816 234856464 q10Shape16T380=true := by decide

private def q10Shape16T381 : Tree := (.split 5 (.split 11 (.split 6 (.split 10 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 2 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 4 8 9))))) (.split 12 (.split 10 (.tip (.small 1)) (.split 2 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 2 3 4 8)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape16T381OK : fastTreeOK (forms 16) 33570832 234856448 q10Shape16T381=true := by decide

private def q10Shape16T379 : Tree := .split 4 q10Shape16T380 q10Shape16T381
private theorem q10Shape16T379OK : fastTreeOK (forms 16) 33570816 234856448 q10Shape16T379=true := by
  change (fastTreeOK (forms 16) 33570816 (234856448 ||| 2^4) q10Shape16T380 &&
    fastTreeOK (forms 16) (33570816 ||| 2^4) 234856448 q10Shape16T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T380OK,q10Shape16T381OK⟩

private def q10Shape16T382 : Tree := (.split 4 (.split 10 (.split 1 (.split 7 (.split 5 (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 2 4 5 8)))) (.split 6 (.tip (.cover 1 3 4 5 8)) (.split 2 (.tip (.cover 0 3 6 7 9)) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))
private theorem q10Shape16T382OK : fastTreeOK (forms 16) 41959424 226467840 q10Shape16T382=true := by decide

private def q10Shape16T378 : Tree := .split 23 q10Shape16T379 q10Shape16T382
private theorem q10Shape16T378OK : fastTreeOK (forms 16) 33570816 226467840 q10Shape16T378=true := by
  change (fastTreeOK (forms 16) 33570816 (226467840 ||| 2^23) q10Shape16T379 &&
    fastTreeOK (forms 16) (33570816 ||| 2^23) 226467840 q10Shape16T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T379OK,q10Shape16T382OK⟩

private def q10Shape16T383 : Tree := (.split 23 (.split 5 (.split 11 (.split 1 (.split 7 (.split 4 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 5 7)))) (.split 6 (.tip (.cover 1 3 4 5 7)) (.split 2 (.tip (.cover 0 3 6 8 9)) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape16T383OK : fastTreeOK (forms 16) 37765120 222273536 q10Shape16T383=true := by decide

private def q10Shape16T377 : Tree := .split 22 q10Shape16T378 q10Shape16T383
private theorem q10Shape16T377OK : fastTreeOK (forms 16) 33570816 222273536 q10Shape16T377=true := by
  change (fastTreeOK (forms 16) 33570816 (222273536 ||| 2^22) q10Shape16T378 &&
    fastTreeOK (forms 16) (33570816 ||| 2^22) 222273536 q10Shape16T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T378OK,q10Shape16T383OK⟩

private def q10Shape16T384 : Tree := (.split 23 (.split 4 (.split 10 (.split 3 (.split 9 (.split 22 (.split 5 (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 2 5 6 8)))) (.split 6 (.tip (.cover 1 3 5 6 8)) (.split 2 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 4 7))))) (.split 5 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape16T384OK : fastTreeOK (forms 16) 33636352 222208000 q10Shape16T384=true := by decide

private def q10Shape16T376 : Tree := .split 16 q10Shape16T377 q10Shape16T384
private theorem q10Shape16T376OK : fastTreeOK (forms 16) 33570816 222208000 q10Shape16T376=true := by
  change (fastTreeOK (forms 16) 33570816 (222208000 ||| 2^16) q10Shape16T377 &&
    fastTreeOK (forms 16) (33570816 ||| 2^16) 222208000 q10Shape16T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T377OK,q10Shape16T384OK⟩

private def q10Shape16T385 : Tree := (.split 16 (.split 22 (.split 5 (.split 11 (.split 3 (.split 9 (.split 23 (.split 4 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 5 6 7)))) (.split 6 (.tip (.cover 1 3 5 6 7)) (.split 2 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7))))) (.split 4 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 5 9)))
private theorem q10Shape16T385OK : fastTreeOK (forms 16) 33603584 222175232 q10Shape16T385=true := by decide

private def q10Shape16T375 : Tree := .split 15 q10Shape16T376 q10Shape16T385
private theorem q10Shape16T375OK : fastTreeOK (forms 16) 33570816 222175232 q10Shape16T375=true := by
  change (fastTreeOK (forms 16) 33570816 (222175232 ||| 2^15) q10Shape16T376 &&
    fastTreeOK (forms 16) (33570816 ||| 2^15) 222175232 q10Shape16T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T376OK,q10Shape16T385OK⟩

private def q10Shape16T386 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T386OK : fastTreeOK (forms 16) 50348032 205398016 q10Shape16T386=true := by decide

private def q10Shape16T374 : Tree := .split 24 q10Shape16T375 q10Shape16T386
private theorem q10Shape16T374OK : fastTreeOK (forms 16) 33570816 205398016 q10Shape16T374=true := by
  change (fastTreeOK (forms 16) 33570816 (205398016 ||| 2^24) q10Shape16T375 &&
    fastTreeOK (forms 16) (33570816 ||| 2^24) 205398016 q10Shape16T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T375OK,q10Shape16T386OK⟩

private def q10Shape16T387 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T387OK : fastTreeOK (forms 16) 35667968 203300864 q10Shape16T387=true := by decide

private def q10Shape16T373 : Tree := .split 21 q10Shape16T374 q10Shape16T387
private theorem q10Shape16T373OK : fastTreeOK (forms 16) 33570816 203300864 q10Shape16T373=true := by
  change (fastTreeOK (forms 16) 33570816 (203300864 ||| 2^21) q10Shape16T374 &&
    fastTreeOK (forms 16) (33570816 ||| 2^21) 203300864 q10Shape16T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T374OK,q10Shape16T387OK⟩

private def q10Shape16T388 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape16T388OK : fastTreeOK (forms 16) 34619392 202252288 q10Shape16T388=true := by decide

private def q10Shape16T372 : Tree := .split 20 q10Shape16T373 q10Shape16T388
private theorem q10Shape16T372OK : fastTreeOK (forms 16) 33570816 202252288 q10Shape16T372=true := by
  change (fastTreeOK (forms 16) 33570816 (202252288 ||| 2^20) q10Shape16T373 &&
    fastTreeOK (forms 16) (33570816 ||| 2^20) 202252288 q10Shape16T388)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T373OK,q10Shape16T388OK⟩

private def q10Shape16T389 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape16T389OK : fastTreeOK (forms 16) 34095104 201728000 q10Shape16T389=true := by decide

private def q10Shape16T371 : Tree := .split 19 q10Shape16T372 q10Shape16T389
private theorem q10Shape16T371OK : fastTreeOK (forms 16) 33570816 201728000 q10Shape16T371=true := by
  change (fastTreeOK (forms 16) 33570816 (201728000 ||| 2^19) q10Shape16T372 &&
    fastTreeOK (forms 16) (33570816 ||| 2^19) 201728000 q10Shape16T389)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T372OK,q10Shape16T389OK⟩

private def q10Shape16T390 : Tree := (.tip (.cover 0 1 4 5 7))
private theorem q10Shape16T390OK : fastTreeOK (forms 16) 33701888 201596928 q10Shape16T390=true := by decide

private def q10Shape16T370 : Tree := .split 17 q10Shape16T371 q10Shape16T390
private theorem q10Shape16T370OK : fastTreeOK (forms 16) 33570816 201596928 q10Shape16T370=true := by
  change (fastTreeOK (forms 16) 33570816 (201596928 ||| 2^17) q10Shape16T371 &&
    fastTreeOK (forms 16) (33570816 ||| 2^17) 201596928 q10Shape16T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T371OK,q10Shape16T390OK⟩

private def q10Shape16T391 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape16T391OK : fastTreeOK (forms 16) 33832960 201334784 q10Shape16T391=true := by decide

private def q10Shape16T369 : Tree := .split 18 q10Shape16T370 q10Shape16T391
private theorem q10Shape16T369OK : fastTreeOK (forms 16) 33570816 201334784 q10Shape16T369=true := by
  change (fastTreeOK (forms 16) 33570816 (201334784 ||| 2^18) q10Shape16T370 &&
    fastTreeOK (forms 16) (33570816 ||| 2^18) 201334784 q10Shape16T391)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T370OK,q10Shape16T391OK⟩

private def q10Shape16T321 : Tree := .split 14 q10Shape16T322 q10Shape16T369
private theorem q10Shape16T321OK : fastTreeOK (forms 16) 33554432 201334784 q10Shape16T321=true := by
  change (fastTreeOK (forms 16) 33554432 (201334784 ||| 2^14) q10Shape16T322 &&
    fastTreeOK (forms 16) (33554432 ||| 2^14) 201334784 q10Shape16T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T322OK,q10Shape16T369OK⟩

private def q10Shape16T404 : Tree := (.split 5 (.split 6 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 3 4 6)))) (.split 3 (.split 10 (.split 11 (.tip (.small 1)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 2 4 7)))) (.split 10 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 3 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 4 7 9))))) (.split 12 (.split 11 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 2 3 4))))
private theorem q10Shape16T404OK : fastTreeOK (forms 16) 33562624 234864656 q10Shape16T404=true := by decide

private def q10Shape16T405 : Tree := (.split 5 (.split 11 (.split 6 (.split 10 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 3 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 4 8 9))))) (.split 12 (.split 10 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 2 3 4 8)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape16T405OK : fastTreeOK (forms 16) 33562640 234864640 q10Shape16T405=true := by decide

private def q10Shape16T403 : Tree := .split 4 q10Shape16T404 q10Shape16T405
private theorem q10Shape16T403OK : fastTreeOK (forms 16) 33562624 234864640 q10Shape16T403=true := by
  change (fastTreeOK (forms 16) 33562624 (234864640 ||| 2^4) q10Shape16T404 &&
    fastTreeOK (forms 16) (33562624 ||| 2^4) 234864640 q10Shape16T405)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T404OK,q10Shape16T405OK⟩

private def q10Shape16T406 : Tree := (.split 4 (.split 10 (.split 1 (.split 7 (.split 5 (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 2 4 6 8)))) (.split 6 (.tip (.cover 1 3 4 6 8)) (.split 3 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))
private theorem q10Shape16T406OK : fastTreeOK (forms 16) 34611200 233816064 q10Shape16T406=true := by decide

private def q10Shape16T402 : Tree := .split 20 q10Shape16T403 q10Shape16T406
private theorem q10Shape16T402OK : fastTreeOK (forms 16) 33562624 233816064 q10Shape16T402=true := by
  change (fastTreeOK (forms 16) 33562624 (233816064 ||| 2^20) q10Shape16T403 &&
    fastTreeOK (forms 16) (33562624 ||| 2^20) 233816064 q10Shape16T406)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T403OK,q10Shape16T406OK⟩

private def q10Shape16T407 : Tree := (.split 20 (.split 5 (.split 11 (.split 1 (.split 7 (.split 4 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 4 6 7)))) (.split 6 (.tip (.cover 1 3 4 6 7)) (.split 3 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape16T407OK : fastTreeOK (forms 16) 34086912 233291776 q10Shape16T407=true := by decide

private def q10Shape16T401 : Tree := .split 19 q10Shape16T402 q10Shape16T407
private theorem q10Shape16T401OK : fastTreeOK (forms 16) 33562624 233291776 q10Shape16T401=true := by
  change (fastTreeOK (forms 16) 33562624 (233291776 ||| 2^19) q10Shape16T402 &&
    fastTreeOK (forms 16) (33562624 ||| 2^19) 233291776 q10Shape16T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T402OK,q10Shape16T407OK⟩

private def q10Shape16T408 : Tree := (.split 20 (.split 4 (.split 10 (.split 2 (.split 8 (.split 19 (.split 5 (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 2 5 6 8)))) (.split 6 (.tip (.cover 1 3 5 6 8)) (.split 3 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 4 7))))) (.split 5 (.split 11 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape16T408OK : fastTreeOK (forms 16) 33628160 233226240 q10Shape16T408=true := by decide

private def q10Shape16T400 : Tree := .split 16 q10Shape16T401 q10Shape16T408
private theorem q10Shape16T400OK : fastTreeOK (forms 16) 33562624 233226240 q10Shape16T400=true := by
  change (fastTreeOK (forms 16) 33562624 (233226240 ||| 2^16) q10Shape16T401 &&
    fastTreeOK (forms 16) (33562624 ||| 2^16) 233226240 q10Shape16T408)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T401OK,q10Shape16T408OK⟩

private def q10Shape16T409 : Tree := (.split 16 (.split 19 (.split 5 (.split 11 (.split 2 (.split 8 (.split 20 (.split 4 (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 5 6 7)))) (.split 6 (.tip (.cover 1 3 5 6 7)) (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 4 7))))) (.split 4 (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 2 3 5))) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 7))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 4 6 9)))
private theorem q10Shape16T409OK : fastTreeOK (forms 16) 33595392 233193472 q10Shape16T409=true := by decide

private def q10Shape16T399 : Tree := .split 15 q10Shape16T400 q10Shape16T409
private theorem q10Shape16T399OK : fastTreeOK (forms 16) 33562624 233193472 q10Shape16T399=true := by
  change (fastTreeOK (forms 16) 33562624 (233193472 ||| 2^15) q10Shape16T400 &&
    fastTreeOK (forms 16) (33562624 ||| 2^15) 233193472 q10Shape16T409)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T400OK,q10Shape16T409OK⟩

private def q10Shape16T410 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T410OK : fastTreeOK (forms 16) 50339840 216416256 q10Shape16T410=true := by decide

private def q10Shape16T398 : Tree := .split 24 q10Shape16T399 q10Shape16T410
private theorem q10Shape16T398OK : fastTreeOK (forms 16) 33562624 216416256 q10Shape16T398=true := by
  change (fastTreeOK (forms 16) 33562624 (216416256 ||| 2^24) q10Shape16T399 &&
    fastTreeOK (forms 16) (33562624 ||| 2^24) 216416256 q10Shape16T410)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T399OK,q10Shape16T410OK⟩

private def q10Shape16T411 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape16T411OK : fastTreeOK (forms 16) 41951232 208027648 q10Shape16T411=true := by decide

private def q10Shape16T397 : Tree := .split 23 q10Shape16T398 q10Shape16T411
private theorem q10Shape16T397OK : fastTreeOK (forms 16) 33562624 208027648 q10Shape16T397=true := by
  change (fastTreeOK (forms 16) 33562624 (208027648 ||| 2^23) q10Shape16T398 &&
    fastTreeOK (forms 16) (33562624 ||| 2^23) 208027648 q10Shape16T411)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T398OK,q10Shape16T411OK⟩

private def q10Shape16T412 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape16T412OK : fastTreeOK (forms 16) 37756928 203833344 q10Shape16T412=true := by decide

private def q10Shape16T396 : Tree := .split 22 q10Shape16T397 q10Shape16T412
private theorem q10Shape16T396OK : fastTreeOK (forms 16) 33562624 203833344 q10Shape16T396=true := by
  change (fastTreeOK (forms 16) 33562624 (203833344 ||| 2^22) q10Shape16T397 &&
    fastTreeOK (forms 16) (33562624 ||| 2^22) 203833344 q10Shape16T412)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T397OK,q10Shape16T412OK⟩

private def q10Shape16T413 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape16T413OK : fastTreeOK (forms 16) 35659776 201736192 q10Shape16T413=true := by decide

private def q10Shape16T395 : Tree := .split 21 q10Shape16T396 q10Shape16T413
private theorem q10Shape16T395OK : fastTreeOK (forms 16) 33562624 201736192 q10Shape16T395=true := by
  change (fastTreeOK (forms 16) 33562624 (201736192 ||| 2^21) q10Shape16T396 &&
    fastTreeOK (forms 16) (33562624 ||| 2^21) 201736192 q10Shape16T413)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T396OK,q10Shape16T413OK⟩

private def q10Shape16T414 : Tree := (.tip (.cover 0 1 4 6 7))
private theorem q10Shape16T414OK : fastTreeOK (forms 16) 33693696 201605120 q10Shape16T414=true := by decide

private def q10Shape16T394 : Tree := .split 17 q10Shape16T395 q10Shape16T414
private theorem q10Shape16T394OK : fastTreeOK (forms 16) 33562624 201605120 q10Shape16T394=true := by
  change (fastTreeOK (forms 16) 33562624 (201605120 ||| 2^17) q10Shape16T395 &&
    fastTreeOK (forms 16) (33562624 ||| 2^17) 201605120 q10Shape16T414)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T395OK,q10Shape16T414OK⟩

private def q10Shape16T415 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape16T415OK : fastTreeOK (forms 16) 33824768 201342976 q10Shape16T415=true := by decide

private def q10Shape16T393 : Tree := .split 18 q10Shape16T394 q10Shape16T415
private theorem q10Shape16T393OK : fastTreeOK (forms 16) 33562624 201342976 q10Shape16T393=true := by
  change (fastTreeOK (forms 16) 33562624 (201342976 ||| 2^18) q10Shape16T394 &&
    fastTreeOK (forms 16) (33562624 ||| 2^18) 201342976 q10Shape16T415)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T394OK,q10Shape16T415OK⟩

private def q10Shape16T416 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape16T416OK : fastTreeOK (forms 16) 33579008 201326592 q10Shape16T416=true := by decide

private def q10Shape16T392 : Tree := .split 14 q10Shape16T393 q10Shape16T416
private theorem q10Shape16T392OK : fastTreeOK (forms 16) 33562624 201326592 q10Shape16T392=true := by
  change (fastTreeOK (forms 16) 33562624 (201326592 ||| 2^14) q10Shape16T393 &&
    fastTreeOK (forms 16) (33562624 ||| 2^14) 201326592 q10Shape16T416)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T393OK,q10Shape16T416OK⟩

private def q10Shape16T320 : Tree := .split 13 q10Shape16T321 q10Shape16T392
private theorem q10Shape16T320OK : fastTreeOK (forms 16) 33554432 201326592 q10Shape16T320=true := by
  change (fastTreeOK (forms 16) 33554432 (201326592 ||| 2^13) q10Shape16T321 &&
    fastTreeOK (forms 16) (33554432 ||| 2^13) 201326592 q10Shape16T392)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T321OK,q10Shape16T392OK⟩

private def q10Shape16T417 : Tree := (.split 13 (.split 14 (.split 18 (.split 16 (.split 20 (.split 23 (.tip (.cover 0 2 3 7 9)) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape16T417OK : fastTreeOK (forms 16) 167772160 67108864 q10Shape16T417=true := by decide

private def q10Shape16T319 : Tree := .split 27 q10Shape16T320 q10Shape16T417
private theorem q10Shape16T319OK : fastTreeOK (forms 16) 33554432 67108864 q10Shape16T319=true := by
  change (fastTreeOK (forms 16) 33554432 (67108864 ||| 2^27) q10Shape16T320 &&
    fastTreeOK (forms 16) (33554432 ||| 2^27) 67108864 q10Shape16T417)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T320OK,q10Shape16T417OK⟩

private def q10Shape16T418 : Tree := (.split 13 (.split 14 (.split 18 (.split 15 (.split 19 (.split 22 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape16T418OK : fastTreeOK (forms 16) 100663296 0 q10Shape16T418=true := by decide

private def q10Shape16T318 : Tree := .split 26 q10Shape16T319 q10Shape16T418
private theorem q10Shape16T318OK : fastTreeOK (forms 16) 33554432 0 q10Shape16T318=true := by
  change (fastTreeOK (forms 16) 33554432 (0 ||| 2^26) q10Shape16T319 &&
    fastTreeOK (forms 16) (33554432 ||| 2^26) 0 q10Shape16T418)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T319OK,q10Shape16T418OK⟩

private def q10Shape16T0 : Tree := .split 25 q10Shape16T1 q10Shape16T318
private theorem q10Shape16T0OK : fastTreeOK (forms 16) 0 0 q10Shape16T0=true := by
  change (fastTreeOK (forms 16) 0 (0 ||| 2^25) q10Shape16T1 &&
    fastTreeOK (forms 16) (0 ||| 2^25) 0 q10Shape16T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape16T1OK,q10Shape16T318OK⟩


theorem q10Shape16_cover (b : Nat→Bool) (H : Ranked (adj (forms 16) b)) :
    ∃ u v w z t,Effective (adj (forms 16) b) (adj (forms 16) b) u v w z t :=
  checked_fastTree (forms 16) b H q10Shape16T0 q10Shape16T0OK

#print axioms q10Shape16_cover
end Graffiti384b.Q10
