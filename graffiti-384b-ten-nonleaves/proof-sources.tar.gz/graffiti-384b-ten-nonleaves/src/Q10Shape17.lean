import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape17T10 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T10OK : fastTreeOK (forms 17) 0 268173312 q10Shape17T10=true := by decide

private def q10Shape17T13 : Tree := (.split 2 (.tip (.cover 0 1 3 4 9)) (.split 8 (.split 9 (.split 13 (.split 14 (.split 6 (.tip (.cover 1 3 4 5 6)) (.split 12 (.split 17 (.split 10 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 15 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 2 6 7 8)))) (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 0 2 6 7 8)))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6)))) (.tip (.cover 1 3 4 5 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 1 3 4 5 9))) (.tip (.cover 0 1 3 4 9))))
private theorem q10Shape17T13OK : fastTreeOK (forms 17) 16777216 251396144 q10Shape17T13=true := by decide

private def q10Shape17T14 : Tree := (.split 2 (.split 11 (.split 16 (.split 10 (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 8 (.tip (.cover 0 1 4 8 9)) (.tip (.cover 0 3 7 8 9)))) (.split 8 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 7 9)))
private theorem q10Shape17T14OK : fastTreeOK (forms 17) 16777248 251396112 q10Shape17T14=true := by decide

private def q10Shape17T12 : Tree := .split 5 q10Shape17T13 q10Shape17T14
private theorem q10Shape17T12OK : fastTreeOK (forms 17) 16777216 251396112 q10Shape17T12=true := by
  change (fastTreeOK (forms 17) 16777216 (251396112 ||| 2^5) q10Shape17T13 &&
    fastTreeOK (forms 17) (16777216 ||| 2^5) 251396112 q10Shape17T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T13OK,q10Shape17T14OK⟩

private def q10Shape17T15 : Tree := (.split 5 (.split 2 (.split 10 (.split 15 (.split 11 (.split 16 (.tip (.cover 0 1 5 7 9)) (.split 8 (.tip (.cover 0 1 4 7 9)) (.tip (.cover 0 3 7 8 9)))) (.split 8 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 1 3 7 9)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape17T15OK : fastTreeOK (forms 17) 16777232 251396096 q10Shape17T15=true := by decide

private def q10Shape17T11 : Tree := .split 4 q10Shape17T12 q10Shape17T15
private theorem q10Shape17T11OK : fastTreeOK (forms 17) 16777216 251396096 q10Shape17T11=true := by
  change (fastTreeOK (forms 17) 16777216 (251396096 ||| 2^4) q10Shape17T12 &&
    fastTreeOK (forms 17) (16777216 ||| 2^4) 251396096 q10Shape17T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T12OK,q10Shape17T15OK⟩

private def q10Shape17T9 : Tree := .split 24 q10Shape17T10 q10Shape17T11
private theorem q10Shape17T9OK : fastTreeOK (forms 17) 0 251396096 q10Shape17T9=true := by
  change (fastTreeOK (forms 17) 0 (251396096 ||| 2^24) q10Shape17T10 &&
    fastTreeOK (forms 17) (0 ||| 2^24) 251396096 q10Shape17T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T10OK,q10Shape17T11OK⟩

private def q10Shape17T19 : Tree := (.split 3 (.tip (.cover 0 1 3 4 9)) (.split 8 (.split 9 (.split 13 (.split 14 (.split 6 (.tip (.cover 1 3 4 5 6)) (.split 12 (.split 17 (.split 10 (.split 11 (.tip (.cover 0 1 4 6 9)) (.split 15 (.tip (.cover 0 1 6 8 9)) (.tip (.cover 0 2 5 7 8)))) (.split 16 (.tip (.cover 0 1 3 6 9)) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 1 3 4 6 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 1 3 4 6 9))))
private theorem q10Shape17T19OK : fastTreeOK (forms 17) 2097152 266076208 q10Shape17T19=true := by decide

private def q10Shape17T20 : Tree := (.split 3 (.split 11 (.split 16 (.split 10 (.split 15 (.tip (.cover 0 1 6 8 9)) (.split 9 (.tip (.cover 0 1 4 8 9)) (.tip (.cover 0 3 7 8 9)))) (.split 9 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 7 9)))
private theorem q10Shape17T20OK : fastTreeOK (forms 17) 2097184 266076176 q10Shape17T20=true := by decide

private def q10Shape17T18 : Tree := .split 5 q10Shape17T19 q10Shape17T20
private theorem q10Shape17T18OK : fastTreeOK (forms 17) 2097152 266076176 q10Shape17T18=true := by
  change (fastTreeOK (forms 17) 2097152 (266076176 ||| 2^5) q10Shape17T19 &&
    fastTreeOK (forms 17) (2097152 ||| 2^5) 266076176 q10Shape17T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T19OK,q10Shape17T20OK⟩

private def q10Shape17T21 : Tree := (.split 5 (.split 3 (.split 10 (.split 15 (.split 11 (.split 16 (.tip (.cover 0 1 6 7 9)) (.split 9 (.tip (.cover 0 1 4 7 9)) (.tip (.cover 0 3 7 8 9)))) (.split 9 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 1 3 7 9)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape17T21OK : fastTreeOK (forms 17) 2097168 266076160 q10Shape17T21=true := by decide

private def q10Shape17T17 : Tree := .split 4 q10Shape17T18 q10Shape17T21
private theorem q10Shape17T17OK : fastTreeOK (forms 17) 2097152 266076160 q10Shape17T17=true := by
  change (fastTreeOK (forms 17) 2097152 (266076160 ||| 2^4) q10Shape17T18 &&
    fastTreeOK (forms 17) (2097152 ||| 2^4) 266076160 q10Shape17T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T18OK,q10Shape17T21OK⟩

private def q10Shape17T22 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape17T22OK : fastTreeOK (forms 17) 18874368 249298944 q10Shape17T22=true := by decide

private def q10Shape17T16 : Tree := .split 24 q10Shape17T17 q10Shape17T22
private theorem q10Shape17T16OK : fastTreeOK (forms 17) 2097152 249298944 q10Shape17T16=true := by
  change (fastTreeOK (forms 17) 2097152 (249298944 ||| 2^24) q10Shape17T17 &&
    fastTreeOK (forms 17) (2097152 ||| 2^24) 249298944 q10Shape17T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T17OK,q10Shape17T22OK⟩

private def q10Shape17T8 : Tree := .split 21 q10Shape17T9 q10Shape17T16
private theorem q10Shape17T8OK : fastTreeOK (forms 17) 0 249298944 q10Shape17T8=true := by
  change (fastTreeOK (forms 17) 0 (249298944 ||| 2^21) q10Shape17T9 &&
    fastTreeOK (forms 17) (0 ||| 2^21) 249298944 q10Shape17T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T9OK,q10Shape17T16OK⟩

private def q10Shape17T28 : Tree := (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.split 11 (.split 6 (.split 12 (.split 17 (.tip (.cover 0 2 3 7 8)) (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 4 8 9 (some 1) none none))))) (.split 2 (.split 3 (.tip (.cover 0 1 3 7 9)) (.split 8 (.tip (.cover 0 1 6 7 9)) (.tip (.cover 1 4 5 6 8)))) (.split 9 (.tip (.cover 0 1 2 7 9)) (.tip (.cover 1 4 5 6 8)))))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9))))
private theorem q10Shape17T28OK : fastTreeOK (forms 17) 134217728 133956656 q10Shape17T28=true := by decide

private def q10Shape17T29 : Tree := (.split 15 (.split 8 (.split 9 (.split 16 (.split 6 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 17 (.split 11 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 8)))) (.split 2 (.split 3 (.tip (.cover 0 1 4 7 9)) (.split 13 (.tip (.cover 0 1 6 7 9)) (.tip (.cover 1 3 5 6 8)))) (.split 14 (.tip (.cover 0 1 2 7 9)) (.tip (.cover 1 3 5 6 8))))) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape17T29OK : fastTreeOK (forms 17) 134218752 133955632 q10Shape17T29=true := by decide

private def q10Shape17T27 : Tree := .split 10 q10Shape17T28 q10Shape17T29
private theorem q10Shape17T27OK : fastTreeOK (forms 17) 134217728 133955632 q10Shape17T27=true := by
  change (fastTreeOK (forms 17) 134217728 (133955632 ||| 2^10) q10Shape17T28 &&
    fastTreeOK (forms 17) (134217728 ||| 2^10) 133955632 q10Shape17T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T28OK,q10Shape17T29OK⟩

private def q10Shape17T30 : Tree := (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.tip (.cover 0 2 3 7 9)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 15 (.split 8 (.split 9 (.tip (.cover 0 2 4 7 9)) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 8))))
private theorem q10Shape17T30OK : fastTreeOK (forms 17) 134217760 133955600 q10Shape17T30=true := by decide

private def q10Shape17T26 : Tree := .split 5 q10Shape17T27 q10Shape17T30
private theorem q10Shape17T26OK : fastTreeOK (forms 17) 134217728 133955600 q10Shape17T26=true := by
  change (fastTreeOK (forms 17) 134217728 (133955600 ||| 2^5) q10Shape17T27 &&
    fastTreeOK (forms 17) (134217728 ||| 2^5) 133955600 q10Shape17T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T27OK,q10Shape17T30OK⟩

private def q10Shape17T31 : Tree := (.split 10 (.split 15 (.split 2 (.split 3 (.split 11 (.split 16 (.split 6 (.tip (.cover 0 3 4 7 8)) (.split 12 (.split 17 (.split 5 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 8)))) (.split 8 (.split 9 (.tip (.cover 0 1 4 7 9)) (.split 13 (.tip (.cover 0 1 6 7 9)) (.tip (.cover 1 2 5 6 8)))) (.split 14 (.tip (.cover 0 1 3 7 9)) (.tip (.cover 1 2 5 6 8))))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 3 4 7 8)))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape17T31OK : fastTreeOK (forms 17) 134217744 133955584 q10Shape17T31=true := by decide

private def q10Shape17T25 : Tree := .split 4 q10Shape17T26 q10Shape17T31
private theorem q10Shape17T25OK : fastTreeOK (forms 17) 134217728 133955584 q10Shape17T25=true := by
  change (fastTreeOK (forms 17) 134217728 (133955584 ||| 2^4) q10Shape17T26 &&
    fastTreeOK (forms 17) (134217728 ||| 2^4) 133955584 q10Shape17T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T26OK,q10Shape17T31OK⟩

private def q10Shape17T32 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T32OK : fastTreeOK (forms 17) 150994944 117178368 q10Shape17T32=true := by decide

private def q10Shape17T24 : Tree := .split 24 q10Shape17T25 q10Shape17T32
private theorem q10Shape17T24OK : fastTreeOK (forms 17) 134217728 117178368 q10Shape17T24=true := by
  change (fastTreeOK (forms 17) 134217728 (117178368 ||| 2^24) q10Shape17T25 &&
    fastTreeOK (forms 17) (134217728 ||| 2^24) 117178368 q10Shape17T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T25OK,q10Shape17T32OK⟩

private def q10Shape17T33 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape17T33OK : fastTreeOK (forms 17) 136314880 115081216 q10Shape17T33=true := by decide

private def q10Shape17T23 : Tree := .split 21 q10Shape17T24 q10Shape17T33
private theorem q10Shape17T23OK : fastTreeOK (forms 17) 134217728 115081216 q10Shape17T23=true := by
  change (fastTreeOK (forms 17) 134217728 (115081216 ||| 2^21) q10Shape17T24 &&
    fastTreeOK (forms 17) (134217728 ||| 2^21) 115081216 q10Shape17T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T24OK,q10Shape17T33OK⟩

private def q10Shape17T7 : Tree := .split 27 q10Shape17T8 q10Shape17T23
private theorem q10Shape17T7OK : fastTreeOK (forms 17) 0 115081216 q10Shape17T7=true := by
  change (fastTreeOK (forms 17) 0 (115081216 ||| 2^27) q10Shape17T8 &&
    fastTreeOK (forms 17) (0 ||| 2^27) 115081216 q10Shape17T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T8OK,q10Shape17T23OK⟩

private def q10Shape17T41 : Tree := (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.split 6 (.split 12 (.split 17 (.tip (.cover 0 2 3 7 8)) (.split 15 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 4 7 9 (some 1) none none))))) (.split 2 (.split 3 (.tip (.cover 0 1 3 8 9)) (.split 8 (.tip (.cover 0 1 6 8 9)) (.tip (.cover 1 4 5 6 7)))) (.split 9 (.tip (.cover 0 1 2 8 9)) (.tip (.cover 1 4 5 6 7)))))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9))))
private theorem q10Shape17T41OK : fastTreeOK (forms 17) 67108864 201067568 q10Shape17T41=true := by decide

private def q10Shape17T42 : Tree := (.split 16 (.split 8 (.split 9 (.split 15 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T42OK : fastTreeOK (forms 17) 67110912 201065520 q10Shape17T42=true := by decide

private def q10Shape17T40 : Tree := .split 11 q10Shape17T41 q10Shape17T42
private theorem q10Shape17T40OK : fastTreeOK (forms 17) 67108864 201065520 q10Shape17T40=true := by
  change (fastTreeOK (forms 17) 67108864 (201065520 ||| 2^11) q10Shape17T41 &&
    fastTreeOK (forms 17) (67108864 ||| 2^11) 201065520 q10Shape17T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T41OK,q10Shape17T42OK⟩

private def q10Shape17T43 : Tree := (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 9 (.split 15 (.split 6 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 17 (.split 2 (.split 3 (.tip (.cover 0 1 4 8 9)) (.split 13 (.tip (.cover 0 1 6 8 9)) (.tip (.cover 1 3 5 6 7)))) (.split 14 (.tip (.cover 0 1 2 8 9)) (.tip (.cover 1 3 5 6 7)))) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7))))
private theorem q10Shape17T43OK : fastTreeOK (forms 17) 67109888 201064496 q10Shape17T43=true := by decide

private def q10Shape17T39 : Tree := .split 10 q10Shape17T40 q10Shape17T43
private theorem q10Shape17T39OK : fastTreeOK (forms 17) 67108864 201064496 q10Shape17T39=true := by
  change (fastTreeOK (forms 17) 67108864 (201064496 ||| 2^10) q10Shape17T40 &&
    fastTreeOK (forms 17) (67108864 ||| 2^10) 201064496 q10Shape17T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T40OK,q10Shape17T43OK⟩

private def q10Shape17T44 : Tree := (.split 11 (.split 16 (.split 2 (.split 3 (.split 10 (.split 15 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T44OK : fastTreeOK (forms 17) 67108896 201064464 q10Shape17T44=true := by decide

private def q10Shape17T38 : Tree := .split 5 q10Shape17T39 q10Shape17T44
private theorem q10Shape17T38OK : fastTreeOK (forms 17) 67108864 201064464 q10Shape17T38=true := by
  change (fastTreeOK (forms 17) 67108864 (201064464 ||| 2^5) q10Shape17T39 &&
    fastTreeOK (forms 17) (67108864 ||| 2^5) 201064464 q10Shape17T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T39OK,q10Shape17T44OK⟩

private def q10Shape17T46 : Tree := (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 9 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))) (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 9 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))))
private theorem q10Shape17T46OK : fastTreeOK (forms 17) 67108880 201064480 q10Shape17T46=true := by decide

private def q10Shape17T47 : Tree := (.split 11 (.split 16 (.split 2 (.split 3 (.split 10 (.split 15 (.split 6 (.tip (.cover 0 3 4 7 8)) (.split 12 (.split 17 (.split 8 (.split 9 (.tip (.cover 0 1 4 8 9)) (.split 13 (.tip (.cover 0 1 6 8 9)) (.tip (.cover 1 2 5 6 7)))) (.split 14 (.tip (.cover 0 1 3 8 9)) (.tip (.cover 1 2 5 6 7)))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 3 4 7 8)))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T47OK : fastTreeOK (forms 17) 67108912 201064448 q10Shape17T47=true := by decide

private def q10Shape17T45 : Tree := .split 5 q10Shape17T46 q10Shape17T47
private theorem q10Shape17T45OK : fastTreeOK (forms 17) 67108880 201064448 q10Shape17T45=true := by
  change (fastTreeOK (forms 17) 67108880 (201064448 ||| 2^5) q10Shape17T46 &&
    fastTreeOK (forms 17) (67108880 ||| 2^5) 201064448 q10Shape17T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T46OK,q10Shape17T47OK⟩

private def q10Shape17T37 : Tree := .split 4 q10Shape17T38 q10Shape17T45
private theorem q10Shape17T37OK : fastTreeOK (forms 17) 67108864 201064448 q10Shape17T37=true := by
  change (fastTreeOK (forms 17) 67108864 (201064448 ||| 2^4) q10Shape17T38 &&
    fastTreeOK (forms 17) (67108864 ||| 2^4) 201064448 q10Shape17T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T38OK,q10Shape17T45OK⟩

private def q10Shape17T48 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape17T48OK : fastTreeOK (forms 17) 83886080 184287232 q10Shape17T48=true := by decide

private def q10Shape17T36 : Tree := .split 24 q10Shape17T37 q10Shape17T48
private theorem q10Shape17T36OK : fastTreeOK (forms 17) 67108864 184287232 q10Shape17T36=true := by
  change (fastTreeOK (forms 17) 67108864 (184287232 ||| 2^24) q10Shape17T37 &&
    fastTreeOK (forms 17) (67108864 ||| 2^24) 184287232 q10Shape17T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T37OK,q10Shape17T48OK⟩

private def q10Shape17T49 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape17T49OK : fastTreeOK (forms 17) 69206016 182190080 q10Shape17T49=true := by decide

private def q10Shape17T35 : Tree := .split 21 q10Shape17T36 q10Shape17T49
private theorem q10Shape17T35OK : fastTreeOK (forms 17) 67108864 182190080 q10Shape17T35=true := by
  change (fastTreeOK (forms 17) 67108864 (182190080 ||| 2^21) q10Shape17T36 &&
    fastTreeOK (forms 17) (67108864 ||| 2^21) 182190080 q10Shape17T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T36OK,q10Shape17T49OK⟩

private def q10Shape17T50 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T50OK : fastTreeOK (forms 17) 201326592 47972352 q10Shape17T50=true := by decide

private def q10Shape17T34 : Tree := .split 27 q10Shape17T35 q10Shape17T50
private theorem q10Shape17T34OK : fastTreeOK (forms 17) 67108864 47972352 q10Shape17T34=true := by
  change (fastTreeOK (forms 17) 67108864 (47972352 ||| 2^27) q10Shape17T35 &&
    fastTreeOK (forms 17) (67108864 ||| 2^27) 47972352 q10Shape17T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T35OK,q10Shape17T50OK⟩

private def q10Shape17T6 : Tree := .split 26 q10Shape17T7 q10Shape17T34
private theorem q10Shape17T6OK : fastTreeOK (forms 17) 0 47972352 q10Shape17T6=true := by
  change (fastTreeOK (forms 17) 0 (47972352 ||| 2^26) q10Shape17T7 &&
    fastTreeOK (forms 17) (0 ||| 2^26) 47972352 q10Shape17T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T7OK,q10Shape17T34OK⟩

private def q10Shape17T58 : Tree := (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 17 (.tip (.cover 0 2 3 7 8)) (.split 11 (.split 16 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 2 7 8 9)))) (.split 3 (.split 9 (.split 14 (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 3 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 4 6)))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 3 6 7 9))) (.tip (.cover 0 2 7 8 9))))) (.tip (.cover 0 1 4 6 9))))
private theorem q10Shape17T58OK : fastTreeOK (forms 17) 8388608 259785776 q10Shape17T58=true := by decide

private def q10Shape17T60 : Tree := (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 11 (.split 16 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 0 2 7 8 9)))) (.split 3 (.split 9 (.split 14 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 2 3 4))))) (.tip (.cover 0 1 3 6 9)))
private theorem q10Shape17T60OK : fastTreeOK (forms 17) 8389632 259817520 q10Shape17T60=true := by decide

private def q10Shape17T61 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T61OK : fastTreeOK (forms 17) 8422400 259784752 q10Shape17T61=true := by decide

private def q10Shape17T59 : Tree := .split 15 q10Shape17T60 q10Shape17T61
private theorem q10Shape17T59OK : fastTreeOK (forms 17) 8389632 259784752 q10Shape17T59=true := by
  change (fastTreeOK (forms 17) 8389632 (259784752 ||| 2^15) q10Shape17T60 &&
    fastTreeOK (forms 17) (8389632 ||| 2^15) 259784752 q10Shape17T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T60OK,q10Shape17T61OK⟩

private def q10Shape17T57 : Tree := .split 10 q10Shape17T58 q10Shape17T59
private theorem q10Shape17T57OK : fastTreeOK (forms 17) 8388608 259784752 q10Shape17T57=true := by
  change (fastTreeOK (forms 17) 8388608 (259784752 ||| 2^10) q10Shape17T58 &&
    fastTreeOK (forms 17) (8388608 ||| 2^10) 259784752 q10Shape17T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T58OK,q10Shape17T59OK⟩

private def q10Shape17T62 : Tree := (.split 3 (.split 9 (.split 14 (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 11 (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 15 (.split 16 (.split 8 (.split 2 (.tip (.cover 0 4 7 8 9)) (.split 17 (.tip (.cover 0 1 2 3 6)) (.tip (.cover 0 2 6 7 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 2 3 4 5 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape17T62OK : fastTreeOK (forms 17) 8388640 259784720 q10Shape17T62=true := by decide

private def q10Shape17T56 : Tree := .split 5 q10Shape17T57 q10Shape17T62
private theorem q10Shape17T56OK : fastTreeOK (forms 17) 8388608 259784720 q10Shape17T56=true := by
  change (fastTreeOK (forms 17) 8388608 (259784720 ||| 2^5) q10Shape17T57 &&
    fastTreeOK (forms 17) (8388608 ||| 2^5) 259784720 q10Shape17T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T57OK,q10Shape17T62OK⟩

private def q10Shape17T67 : Tree := (.tip (.cover 0 3 4 7 8))
private theorem q10Shape17T67OK : fastTreeOK (forms 17) 8388624 259818564 q10Shape17T67=true := by decide

private def q10Shape17T69 : Tree := (.split 11 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.split 3 (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 3 4)))) (.split 16 (.split 3 (.split 8 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 5 7 8 9))))
private theorem q10Shape17T69OK : fastTreeOK (forms 17) 8388688 259818532 q10Shape17T69=true := by decide

private def q10Shape17T70 : Tree := (.split 3 (.split 9 (.split 14 (.split 11 (.split 16 (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 4 7 8 9))) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 0 3 7 8 9)))) (.split 16 (.split 8 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape17T70OK : fastTreeOK (forms 17) 8388720 259818500 q10Shape17T70=true := by decide

private def q10Shape17T68 : Tree := .split 5 q10Shape17T69 q10Shape17T70
private theorem q10Shape17T68OK : fastTreeOK (forms 17) 8388688 259818500 q10Shape17T68=true := by
  change (fastTreeOK (forms 17) 8388688 (259818500 ||| 2^5) q10Shape17T69 &&
    fastTreeOK (forms 17) (8388688 ||| 2^5) 259818500 q10Shape17T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T69OK,q10Shape17T70OK⟩

private def q10Shape17T66 : Tree := .split 6 q10Shape17T67 q10Shape17T68
private theorem q10Shape17T66OK : fastTreeOK (forms 17) 8388624 259818500 q10Shape17T66=true := by
  change (fastTreeOK (forms 17) 8388624 (259818500 ||| 2^6) q10Shape17T67 &&
    fastTreeOK (forms 17) (8388624 ||| 2^6) 259818500 q10Shape17T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T67OK,q10Shape17T68OK⟩

private def q10Shape17T71 : Tree := (.tip (.cover 0 1 2 6 9))
private theorem q10Shape17T71OK : fastTreeOK (forms 17) 8388628 259818496 q10Shape17T71=true := by decide

private def q10Shape17T65 : Tree := .split 2 q10Shape17T66 q10Shape17T71
private theorem q10Shape17T65OK : fastTreeOK (forms 17) 8388624 259818496 q10Shape17T65=true := by
  change (fastTreeOK (forms 17) 8388624 (259818496 ||| 2^2) q10Shape17T66 &&
    fastTreeOK (forms 17) (8388624 ||| 2^2) 259818496 q10Shape17T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T66OK,q10Shape17T71OK⟩

private def q10Shape17T72 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T72OK : fastTreeOK (forms 17) 8421392 259785728 q10Shape17T72=true := by decide

private def q10Shape17T64 : Tree := .split 15 q10Shape17T65 q10Shape17T72
private theorem q10Shape17T64OK : fastTreeOK (forms 17) 8388624 259785728 q10Shape17T64=true := by
  change (fastTreeOK (forms 17) 8388624 (259785728 ||| 2^15) q10Shape17T65 &&
    fastTreeOK (forms 17) (8388624 ||| 2^15) 259785728 q10Shape17T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T65OK,q10Shape17T72OK⟩

private def q10Shape17T73 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T73OK : fastTreeOK (forms 17) 8389648 259784704 q10Shape17T73=true := by decide

private def q10Shape17T63 : Tree := .split 10 q10Shape17T64 q10Shape17T73
private theorem q10Shape17T63OK : fastTreeOK (forms 17) 8388624 259784704 q10Shape17T63=true := by
  change (fastTreeOK (forms 17) 8388624 (259784704 ||| 2^10) q10Shape17T64 &&
    fastTreeOK (forms 17) (8388624 ||| 2^10) 259784704 q10Shape17T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T64OK,q10Shape17T73OK⟩

private def q10Shape17T55 : Tree := .split 4 q10Shape17T56 q10Shape17T63
private theorem q10Shape17T55OK : fastTreeOK (forms 17) 8388608 259784704 q10Shape17T55=true := by
  change (fastTreeOK (forms 17) 8388608 (259784704 ||| 2^4) q10Shape17T56 &&
    fastTreeOK (forms 17) (8388608 ||| 2^4) 259784704 q10Shape17T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T56OK,q10Shape17T63OK⟩

private def q10Shape17T76 : Tree := (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 16 (.split 13 (.split 17 (.split 11 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 2 3 6 7))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 5 9)))) (.split 11 (.split 8 (.split 12 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.tip (.cover 0 2 4 6 7))) (.tip (.cover 0 1 2 4 6))) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 5 9))))
private theorem q10Shape17T76OK : fastTreeOK (forms 17) 25165824 243007536 q10Shape17T76=true := by decide

private def q10Shape17T77 : Tree := (.split 2 (.split 11 (.split 16 (.split 6 (.tip (.cover 0 1 3 4 6)) (.split 12 (.split 17 (.split 10 (.split 8 (.tip (.cover 0 1 4 6 9)) (.tip (.cover 1 2 4 5 6))) (.split 8 (.tip (.cover 0 2 4 6 7)) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 3 4 6)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 7 9)))
private theorem q10Shape17T77OK : fastTreeOK (forms 17) 25165856 243007504 q10Shape17T77=true := by decide

private def q10Shape17T75 : Tree := .split 5 q10Shape17T76 q10Shape17T77
private theorem q10Shape17T75OK : fastTreeOK (forms 17) 25165824 243007504 q10Shape17T75=true := by
  change (fastTreeOK (forms 17) 25165824 (243007504 ||| 2^5) q10Shape17T76 &&
    fastTreeOK (forms 17) (25165824 ||| 2^5) 243007504 q10Shape17T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T76OK,q10Shape17T77OK⟩

private def q10Shape17T78 : Tree := (.split 5 (.split 2 (.split 6 (.split 10 (.split 11 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.tip (.cover 0 3 4 6 7))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 3 4 6 7))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape17T78OK : fastTreeOK (forms 17) 25165840 243007488 q10Shape17T78=true := by decide

private def q10Shape17T74 : Tree := .split 4 q10Shape17T75 q10Shape17T78
private theorem q10Shape17T74OK : fastTreeOK (forms 17) 25165824 243007488 q10Shape17T74=true := by
  change (fastTreeOK (forms 17) 25165824 (243007488 ||| 2^4) q10Shape17T75 &&
    fastTreeOK (forms 17) (25165824 ||| 2^4) 243007488 q10Shape17T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T75OK,q10Shape17T78OK⟩

private def q10Shape17T54 : Tree := .split 24 q10Shape17T55 q10Shape17T74
private theorem q10Shape17T54OK : fastTreeOK (forms 17) 8388608 243007488 q10Shape17T54=true := by
  change (fastTreeOK (forms 17) 8388608 (243007488 ||| 2^24) q10Shape17T55 &&
    fastTreeOK (forms 17) (8388608 ||| 2^24) 243007488 q10Shape17T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T55OK,q10Shape17T74OK⟩

private def q10Shape17T81 : Tree := (.split 5 (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 17 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 6 9)))) (.split 15 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 8)))) (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 11 (.split 8 (.split 12 (.tip (.cover 0 1 2 4 8)) (.tip (.cover 0 3 5 7 8))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 15 (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 8)))))
private theorem q10Shape17T81OK : fastTreeOK (forms 17) 142606336 125566992 q10Shape17T81=true := by decide

private def q10Shape17T82 : Tree := (.split 10 (.split 15 (.split 2 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape17T82OK : fastTreeOK (forms 17) 142606352 125566976 q10Shape17T82=true := by decide

private def q10Shape17T80 : Tree := .split 4 q10Shape17T81 q10Shape17T82
private theorem q10Shape17T80OK : fastTreeOK (forms 17) 142606336 125566976 q10Shape17T80=true := by
  change (fastTreeOK (forms 17) 142606336 (125566976 ||| 2^4) q10Shape17T81 &&
    fastTreeOK (forms 17) (142606336 ||| 2^4) 125566976 q10Shape17T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T81OK,q10Shape17T82OK⟩

private def q10Shape17T83 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T83OK : fastTreeOK (forms 17) 159383552 108789760 q10Shape17T83=true := by decide

private def q10Shape17T79 : Tree := .split 24 q10Shape17T80 q10Shape17T83
private theorem q10Shape17T79OK : fastTreeOK (forms 17) 142606336 108789760 q10Shape17T79=true := by
  change (fastTreeOK (forms 17) 142606336 (108789760 ||| 2^24) q10Shape17T80 &&
    fastTreeOK (forms 17) (142606336 ||| 2^24) 108789760 q10Shape17T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T80OK,q10Shape17T83OK⟩

private def q10Shape17T53 : Tree := .split 27 q10Shape17T54 q10Shape17T79
private theorem q10Shape17T53OK : fastTreeOK (forms 17) 8388608 108789760 q10Shape17T53=true := by
  change (fastTreeOK (forms 17) 8388608 (108789760 ||| 2^27) q10Shape17T54 &&
    fastTreeOK (forms 17) (8388608 ||| 2^27) 108789760 q10Shape17T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T54OK,q10Shape17T79OK⟩

private def q10Shape17T84 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape17T84OK : fastTreeOK (forms 17) 10485760 106692608 q10Shape17T84=true := by decide

private def q10Shape17T52 : Tree := .split 21 q10Shape17T53 q10Shape17T84
private theorem q10Shape17T52OK : fastTreeOK (forms 17) 8388608 106692608 q10Shape17T52=true := by
  change (fastTreeOK (forms 17) 8388608 (106692608 ||| 2^21) q10Shape17T53 &&
    fastTreeOK (forms 17) (8388608 ||| 2^21) 106692608 q10Shape17T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T53OK,q10Shape17T84OK⟩

private def q10Shape17T85 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T85OK : fastTreeOK (forms 17) 75497472 39583744 q10Shape17T85=true := by decide

private def q10Shape17T51 : Tree := .split 26 q10Shape17T52 q10Shape17T85
private theorem q10Shape17T51OK : fastTreeOK (forms 17) 8388608 39583744 q10Shape17T51=true := by
  change (fastTreeOK (forms 17) 8388608 (39583744 ||| 2^26) q10Shape17T52 &&
    fastTreeOK (forms 17) (8388608 ||| 2^26) 39583744 q10Shape17T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T52OK,q10Shape17T85OK⟩

private def q10Shape17T5 : Tree := .split 23 q10Shape17T6 q10Shape17T51
private theorem q10Shape17T5OK : fastTreeOK (forms 17) 0 39583744 q10Shape17T5=true := by
  change (fastTreeOK (forms 17) 0 (39583744 ||| 2^23) q10Shape17T6 &&
    fastTreeOK (forms 17) (0 ||| 2^23) 39583744 q10Shape17T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T6OK,q10Shape17T51OK⟩

private def q10Shape17T95 : Tree := (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 17 (.tip (.cover 0 2 3 7 8)) (.split 15 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 2 7 8 9)))) (.split 3 (.split 9 (.split 14 (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 3 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 4 6)))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))))) (.tip (.cover 0 1 4 6 9))))
private theorem q10Shape17T95OK : fastTreeOK (forms 17) 4194304 263982128 q10Shape17T95=true := by decide

private def q10Shape17T96 : Tree := (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 15 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 2 7 8 9))))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T96OK : fastTreeOK (forms 17) 4196352 263980080 q10Shape17T96=true := by decide

private def q10Shape17T94 : Tree := .split 11 q10Shape17T95 q10Shape17T96
private theorem q10Shape17T94OK : fastTreeOK (forms 17) 4194304 263980080 q10Shape17T94=true := by
  change (fastTreeOK (forms 17) 4194304 (263980080 ||| 2^11) q10Shape17T95 &&
    fastTreeOK (forms 17) (4194304 ||| 2^11) 263980080 q10Shape17T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T95OK,q10Shape17T96OK⟩

private def q10Shape17T97 : Tree := (.split 3 (.split 9 (.split 14 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 15 (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 2 7 8 9))))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 2 3 4 5 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape17T97OK : fastTreeOK (forms 17) 4195328 263979056 q10Shape17T97=true := by decide

private def q10Shape17T93 : Tree := .split 10 q10Shape17T94 q10Shape17T97
private theorem q10Shape17T93OK : fastTreeOK (forms 17) 4194304 263979056 q10Shape17T93=true := by
  change (fastTreeOK (forms 17) 4194304 (263979056 ||| 2^10) q10Shape17T94 &&
    fastTreeOK (forms 17) (4194304 ||| 2^10) 263979056 q10Shape17T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T94OK,q10Shape17T97OK⟩

private def q10Shape17T98 : Tree := (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 7 8)) (.split 10 (.split 15 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.split 3 (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 3 4)))) (.split 15 (.split 3 (.split 8 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 5 7 8 9))))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T98OK : fastTreeOK (forms 17) 4194336 263979024 q10Shape17T98=true := by decide

private def q10Shape17T92 : Tree := .split 5 q10Shape17T93 q10Shape17T98
private theorem q10Shape17T92OK : fastTreeOK (forms 17) 4194304 263979024 q10Shape17T92=true := by
  change (fastTreeOK (forms 17) 4194304 (263979024 ||| 2^5) q10Shape17T93 &&
    fastTreeOK (forms 17) (4194304 ||| 2^5) 263979024 q10Shape17T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T93OK,q10Shape17T98OK⟩

private def q10Shape17T103 : Tree := (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 15 (.split 16 (.split 8 (.split 2 (.tip (.cover 0 4 7 8 9)) (.split 17 (.tip (.cover 0 1 2 3 6)) (.tip (.cover 0 2 6 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 2 3 4 5 6))) (.tip (.cover 0 5 7 8 9)))) (.split 15 (.split 16 (.split 11 (.tip (.cover 0 1 5 6 9)) (.split 8 (.split 2 (.tip (.cover 0 4 7 8 9)) (.split 17 (.tip (.cover 0 1 2 3 6)) (.tip (.cover 0 2 6 8 9)))) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))))
private theorem q10Shape17T103OK : fastTreeOK (forms 17) 4194320 263995944 q10Shape17T103=true := by decide

private def q10Shape17T104 : Tree := (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 7 8)) (.split 10 (.split 15 (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 4 7 8 9))) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.split 8 (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 15 (.split 8 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 5 7 8 9))))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 2 3 4 5 6))) (.tip (.cover 2 3 4 5 6)))
private theorem q10Shape17T104OK : fastTreeOK (forms 17) 4194352 263995912 q10Shape17T104=true := by decide

private def q10Shape17T102 : Tree := .split 5 q10Shape17T103 q10Shape17T104
private theorem q10Shape17T102OK : fastTreeOK (forms 17) 4194320 263995912 q10Shape17T102=true := by
  change (fastTreeOK (forms 17) 4194320 (263995912 ||| 2^5) q10Shape17T103 &&
    fastTreeOK (forms 17) (4194320 ||| 2^5) 263995912 q10Shape17T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T103OK,q10Shape17T104OK⟩

private def q10Shape17T105 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T105OK : fastTreeOK (forms 17) 4210704 263979528 q10Shape17T105=true := by decide

private def q10Shape17T101 : Tree := .split 14 q10Shape17T102 q10Shape17T105
private theorem q10Shape17T101OK : fastTreeOK (forms 17) 4194320 263979528 q10Shape17T101=true := by
  change (fastTreeOK (forms 17) 4194320 (263979528 ||| 2^14) q10Shape17T102 &&
    fastTreeOK (forms 17) (4194320 ||| 2^14) 263979528 q10Shape17T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T102OK,q10Shape17T105OK⟩

private def q10Shape17T106 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T106OK : fastTreeOK (forms 17) 4194832 263979016 q10Shape17T106=true := by decide

private def q10Shape17T100 : Tree := .split 9 q10Shape17T101 q10Shape17T106
private theorem q10Shape17T100OK : fastTreeOK (forms 17) 4194320 263979016 q10Shape17T100=true := by
  change (fastTreeOK (forms 17) 4194320 (263979016 ||| 2^9) q10Shape17T101 &&
    fastTreeOK (forms 17) (4194320 ||| 2^9) 263979016 q10Shape17T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T101OK,q10Shape17T106OK⟩

private def q10Shape17T107 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T107OK : fastTreeOK (forms 17) 4194328 263979008 q10Shape17T107=true := by decide

private def q10Shape17T99 : Tree := .split 3 q10Shape17T100 q10Shape17T107
private theorem q10Shape17T99OK : fastTreeOK (forms 17) 4194320 263979008 q10Shape17T99=true := by
  change (fastTreeOK (forms 17) 4194320 (263979008 ||| 2^3) q10Shape17T100 &&
    fastTreeOK (forms 17) (4194320 ||| 2^3) 263979008 q10Shape17T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T100OK,q10Shape17T107OK⟩

private def q10Shape17T91 : Tree := .split 4 q10Shape17T92 q10Shape17T99
private theorem q10Shape17T91OK : fastTreeOK (forms 17) 4194304 263979008 q10Shape17T91=true := by
  change (fastTreeOK (forms 17) 4194304 (263979008 ||| 2^4) q10Shape17T92 &&
    fastTreeOK (forms 17) (4194304 ||| 2^4) 263979008 q10Shape17T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T92OK,q10Shape17T99OK⟩

private def q10Shape17T110 : Tree := (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 1 2 4 5 6))))) (.tip (.cover 0 1 4 5 9))) (.split 8 (.split 12 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.tip (.cover 0 1 2 4 6))) (.tip (.cover 0 2 4 6 8))) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 9)))) (.split 11 (.split 2 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 1 4 5 7 9))) (.tip (.cover 0 1 3 5 9))))
private theorem q10Shape17T110OK : fastTreeOK (forms 17) 20971520 247201840 q10Shape17T110=true := by decide

private def q10Shape17T111 : Tree := (.split 2 (.split 6 (.split 10 (.split 11 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 3 4 6 8))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 3 4 6 8))) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape17T111OK : fastTreeOK (forms 17) 20971552 247201808 q10Shape17T111=true := by decide

private def q10Shape17T109 : Tree := .split 5 q10Shape17T110 q10Shape17T111
private theorem q10Shape17T109OK : fastTreeOK (forms 17) 20971520 247201808 q10Shape17T109=true := by
  change (fastTreeOK (forms 17) 20971520 (247201808 ||| 2^5) q10Shape17T110 &&
    fastTreeOK (forms 17) (20971520 ||| 2^5) 247201808 q10Shape17T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T110OK,q10Shape17T111OK⟩

private def q10Shape17T112 : Tree := (.split 5 (.split 2 (.split 10 (.split 15 (.split 6 (.tip (.cover 0 1 3 4 6)) (.split 12 (.split 17 (.split 11 (.split 8 (.tip (.cover 0 1 4 6 9)) (.tip (.cover 1 2 4 5 6))) (.split 8 (.tip (.cover 0 2 4 6 8)) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 3 4 6)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape17T112OK : fastTreeOK (forms 17) 20971536 247201792 q10Shape17T112=true := by decide

private def q10Shape17T108 : Tree := .split 4 q10Shape17T109 q10Shape17T112
private theorem q10Shape17T108OK : fastTreeOK (forms 17) 20971520 247201792 q10Shape17T108=true := by
  change (fastTreeOK (forms 17) 20971520 (247201792 ||| 2^4) q10Shape17T109 &&
    fastTreeOK (forms 17) (20971520 ||| 2^4) 247201792 q10Shape17T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T109OK,q10Shape17T112OK⟩

private def q10Shape17T90 : Tree := .split 24 q10Shape17T91 q10Shape17T108
private theorem q10Shape17T90OK : fastTreeOK (forms 17) 4194304 247201792 q10Shape17T90=true := by
  change (fastTreeOK (forms 17) 4194304 (247201792 ||| 2^24) q10Shape17T91 &&
    fastTreeOK (forms 17) (4194304 ||| 2^24) 247201792 q10Shape17T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T91OK,q10Shape17T108OK⟩

private def q10Shape17T116 : Tree := (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 17 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))) (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 5 7 8))) (.tip (.cover 0 2 7 8 9)))) (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))))
private theorem q10Shape17T116OK : fastTreeOK (forms 17) 71303168 196870192 q10Shape17T116=true := by decide

private def q10Shape17T117 : Tree := (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T117OK : fastTreeOK (forms 17) 71303200 196870160 q10Shape17T117=true := by decide

private def q10Shape17T115 : Tree := .split 5 q10Shape17T116 q10Shape17T117
private theorem q10Shape17T115OK : fastTreeOK (forms 17) 71303168 196870160 q10Shape17T115=true := by
  change (fastTreeOK (forms 17) 71303168 (196870160 ||| 2^5) q10Shape17T116 &&
    fastTreeOK (forms 17) (71303168 ||| 2^5) 196870160 q10Shape17T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T116OK,q10Shape17T117OK⟩

private def q10Shape17T119 : Tree := (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 8 (.split 12 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 3 5 7 8))) (.tip (.cover 0 3 7 8 9)))) (.split 15 (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 5 7 8 9)))) (.split 15 (.split 16 (.split 11 (.tip (.cover 0 1 5 6 9)) (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))))
private theorem q10Shape17T119OK : fastTreeOK (forms 17) 71303184 196870176 q10Shape17T119=true := by decide

private def q10Shape17T120 : Tree := (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T120OK : fastTreeOK (forms 17) 71303216 196870144 q10Shape17T120=true := by decide

private def q10Shape17T118 : Tree := .split 5 q10Shape17T119 q10Shape17T120
private theorem q10Shape17T118OK : fastTreeOK (forms 17) 71303184 196870144 q10Shape17T118=true := by
  change (fastTreeOK (forms 17) 71303184 (196870144 ||| 2^5) q10Shape17T119 &&
    fastTreeOK (forms 17) (71303184 ||| 2^5) 196870144 q10Shape17T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T119OK,q10Shape17T120OK⟩

private def q10Shape17T114 : Tree := .split 4 q10Shape17T115 q10Shape17T118
private theorem q10Shape17T114OK : fastTreeOK (forms 17) 71303168 196870144 q10Shape17T114=true := by
  change (fastTreeOK (forms 17) 71303168 (196870144 ||| 2^4) q10Shape17T115 &&
    fastTreeOK (forms 17) (71303168 ||| 2^4) 196870144 q10Shape17T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T115OK,q10Shape17T118OK⟩

private def q10Shape17T121 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape17T121OK : fastTreeOK (forms 17) 88080384 180092928 q10Shape17T121=true := by decide

private def q10Shape17T113 : Tree := .split 24 q10Shape17T114 q10Shape17T121
private theorem q10Shape17T113OK : fastTreeOK (forms 17) 71303168 180092928 q10Shape17T113=true := by
  change (fastTreeOK (forms 17) 71303168 (180092928 ||| 2^24) q10Shape17T114 &&
    fastTreeOK (forms 17) (71303168 ||| 2^24) 180092928 q10Shape17T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T114OK,q10Shape17T121OK⟩

private def q10Shape17T89 : Tree := .split 26 q10Shape17T90 q10Shape17T113
private theorem q10Shape17T89OK : fastTreeOK (forms 17) 4194304 180092928 q10Shape17T89=true := by
  change (fastTreeOK (forms 17) 4194304 (180092928 ||| 2^26) q10Shape17T90 &&
    fastTreeOK (forms 17) (4194304 ||| 2^26) 180092928 q10Shape17T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T90OK,q10Shape17T113OK⟩

private def q10Shape17T122 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape17T122OK : fastTreeOK (forms 17) 6291456 177995776 q10Shape17T122=true := by decide

private def q10Shape17T88 : Tree := .split 21 q10Shape17T89 q10Shape17T122
private theorem q10Shape17T88OK : fastTreeOK (forms 17) 4194304 177995776 q10Shape17T88=true := by
  change (fastTreeOK (forms 17) 4194304 (177995776 ||| 2^21) q10Shape17T89 &&
    fastTreeOK (forms 17) (4194304 ||| 2^21) 177995776 q10Shape17T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T89OK,q10Shape17T122OK⟩

private def q10Shape17T123 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T123OK : fastTreeOK (forms 17) 138412032 43778048 q10Shape17T123=true := by decide

private def q10Shape17T87 : Tree := .split 27 q10Shape17T88 q10Shape17T123
private theorem q10Shape17T87OK : fastTreeOK (forms 17) 4194304 43778048 q10Shape17T87=true := by
  change (fastTreeOK (forms 17) 4194304 (43778048 ||| 2^27) q10Shape17T88 &&
    fastTreeOK (forms 17) (4194304 ||| 2^27) 43778048 q10Shape17T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T88OK,q10Shape17T123OK⟩

private def q10Shape17T124 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T124OK : fastTreeOK (forms 17) 12582912 35389440 q10Shape17T124=true := by decide

private def q10Shape17T86 : Tree := .split 23 q10Shape17T87 q10Shape17T124
private theorem q10Shape17T86OK : fastTreeOK (forms 17) 4194304 35389440 q10Shape17T86=true := by
  change (fastTreeOK (forms 17) 4194304 (35389440 ||| 2^23) q10Shape17T87 &&
    fastTreeOK (forms 17) (4194304 ||| 2^23) 35389440 q10Shape17T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T87OK,q10Shape17T124OK⟩

private def q10Shape17T4 : Tree := .split 22 q10Shape17T5 q10Shape17T86
private theorem q10Shape17T4OK : fastTreeOK (forms 17) 0 35389440 q10Shape17T4=true := by
  change (fastTreeOK (forms 17) 0 (35389440 ||| 2^22) q10Shape17T5 &&
    fastTreeOK (forms 17) (0 ||| 2^22) 35389440 q10Shape17T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T5OK,q10Shape17T86OK⟩

private def q10Shape17T134 : Tree := (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 14 (.split 17 (.tip (.cover 0 2 3 7 8)) (.split 11 (.split 16 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 2 7 8 9)))) (.split 2 (.split 8 (.split 13 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 2 3 4))))) (.tip (.cover 0 1 4 5 9))))
private theorem q10Shape17T134OK : fastTreeOK (forms 17) 1048576 267125808 q10Shape17T134=true := by decide

private def q10Shape17T137 : Tree := (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 11 (.split 16 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 2 3 4)))) (.split 2 (.split 8 (.split 13 (.split 16 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 3 4)))))
private theorem q10Shape17T137OK : fastTreeOK (forms 17) 1049600 267158064 q10Shape17T137=true := by decide

private def q10Shape17T138 : Tree := (.tip (.cover 0 1 3 5 9))
private theorem q10Shape17T138OK : fastTreeOK (forms 17) 1050112 267157552 q10Shape17T138=true := by decide

private def q10Shape17T136 : Tree := .split 9 q10Shape17T137 q10Shape17T138
private theorem q10Shape17T136OK : fastTreeOK (forms 17) 1049600 267157552 q10Shape17T136=true := by
  change (fastTreeOK (forms 17) 1049600 (267157552 ||| 2^9) q10Shape17T137 &&
    fastTreeOK (forms 17) (1049600 ||| 2^9) 267157552 q10Shape17T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T137OK,q10Shape17T138OK⟩

private def q10Shape17T139 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T139OK : fastTreeOK (forms 17) 1082368 267124784 q10Shape17T139=true := by decide

private def q10Shape17T135 : Tree := .split 15 q10Shape17T136 q10Shape17T139
private theorem q10Shape17T135OK : fastTreeOK (forms 17) 1049600 267124784 q10Shape17T135=true := by
  change (fastTreeOK (forms 17) 1049600 (267124784 ||| 2^15) q10Shape17T136 &&
    fastTreeOK (forms 17) (1049600 ||| 2^15) 267124784 q10Shape17T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T136OK,q10Shape17T139OK⟩

private def q10Shape17T133 : Tree := .split 10 q10Shape17T134 q10Shape17T135
private theorem q10Shape17T133OK : fastTreeOK (forms 17) 1048576 267124784 q10Shape17T133=true := by
  change (fastTreeOK (forms 17) 1048576 (267124784 ||| 2^10) q10Shape17T134 &&
    fastTreeOK (forms 17) (1048576 ||| 2^10) 267124784 q10Shape17T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T134OK,q10Shape17T135OK⟩

private def q10Shape17T140 : Tree := (.split 2 (.split 8 (.split 13 (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 11 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 15 (.split 16 (.split 9 (.split 3 (.tip (.cover 0 4 7 8 9)) (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 2 3 4 5 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape17T140OK : fastTreeOK (forms 17) 1048608 267124752 q10Shape17T140=true := by decide

private def q10Shape17T132 : Tree := .split 5 q10Shape17T133 q10Shape17T140
private theorem q10Shape17T132OK : fastTreeOK (forms 17) 1048576 267124752 q10Shape17T132=true := by
  change (fastTreeOK (forms 17) 1048576 (267124752 ||| 2^5) q10Shape17T133 &&
    fastTreeOK (forms 17) (1048576 ||| 2^5) 267124752 q10Shape17T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T133OK,q10Shape17T140OK⟩

private def q10Shape17T145 : Tree := (.tip (.cover 0 3 4 7 8))
private theorem q10Shape17T145OK : fastTreeOK (forms 17) 1048592 267158600 q10Shape17T145=true := by decide

private def q10Shape17T147 : Tree := (.split 11 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.split 2 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))) (.split 16 (.split 2 (.split 8 (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 6 7 8 9))))
private theorem q10Shape17T147OK : fastTreeOK (forms 17) 1048656 267158568 q10Shape17T147=true := by decide

private def q10Shape17T148 : Tree := (.split 2 (.split 8 (.split 13 (.split 11 (.split 16 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 7 8 9))) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 3 7 8 9)))) (.split 16 (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape17T148OK : fastTreeOK (forms 17) 1048688 267158536 q10Shape17T148=true := by decide

private def q10Shape17T146 : Tree := .split 5 q10Shape17T147 q10Shape17T148
private theorem q10Shape17T146OK : fastTreeOK (forms 17) 1048656 267158536 q10Shape17T146=true := by
  change (fastTreeOK (forms 17) 1048656 (267158536 ||| 2^5) q10Shape17T147 &&
    fastTreeOK (forms 17) (1048656 ||| 2^5) 267158536 q10Shape17T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T147OK,q10Shape17T148OK⟩

private def q10Shape17T144 : Tree := .split 6 q10Shape17T145 q10Shape17T146
private theorem q10Shape17T144OK : fastTreeOK (forms 17) 1048592 267158536 q10Shape17T144=true := by
  change (fastTreeOK (forms 17) 1048592 (267158536 ||| 2^6) q10Shape17T145 &&
    fastTreeOK (forms 17) (1048592 ||| 2^6) 267158536 q10Shape17T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T145OK,q10Shape17T146OK⟩

private def q10Shape17T149 : Tree := (.tip (.cover 0 1 2 5 9))
private theorem q10Shape17T149OK : fastTreeOK (forms 17) 1048600 267158528 q10Shape17T149=true := by decide

private def q10Shape17T143 : Tree := .split 3 q10Shape17T144 q10Shape17T149
private theorem q10Shape17T143OK : fastTreeOK (forms 17) 1048592 267158528 q10Shape17T143=true := by
  change (fastTreeOK (forms 17) 1048592 (267158528 ||| 2^3) q10Shape17T144 &&
    fastTreeOK (forms 17) (1048592 ||| 2^3) 267158528 q10Shape17T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T144OK,q10Shape17T149OK⟩

private def q10Shape17T150 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T150OK : fastTreeOK (forms 17) 1081360 267125760 q10Shape17T150=true := by decide

private def q10Shape17T142 : Tree := .split 15 q10Shape17T143 q10Shape17T150
private theorem q10Shape17T142OK : fastTreeOK (forms 17) 1048592 267125760 q10Shape17T142=true := by
  change (fastTreeOK (forms 17) 1048592 (267125760 ||| 2^15) q10Shape17T143 &&
    fastTreeOK (forms 17) (1048592 ||| 2^15) 267125760 q10Shape17T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T143OK,q10Shape17T150OK⟩

private def q10Shape17T151 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T151OK : fastTreeOK (forms 17) 1049616 267124736 q10Shape17T151=true := by decide

private def q10Shape17T141 : Tree := .split 10 q10Shape17T142 q10Shape17T151
private theorem q10Shape17T141OK : fastTreeOK (forms 17) 1048592 267124736 q10Shape17T141=true := by
  change (fastTreeOK (forms 17) 1048592 (267124736 ||| 2^10) q10Shape17T142 &&
    fastTreeOK (forms 17) (1048592 ||| 2^10) 267124736 q10Shape17T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T142OK,q10Shape17T151OK⟩

private def q10Shape17T131 : Tree := .split 4 q10Shape17T132 q10Shape17T141
private theorem q10Shape17T131OK : fastTreeOK (forms 17) 1048576 267124736 q10Shape17T131=true := by
  change (fastTreeOK (forms 17) 1048576 (267124736 ||| 2^4) q10Shape17T132 &&
    fastTreeOK (forms 17) (1048576 ||| 2^4) 267124736 q10Shape17T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T132OK,q10Shape17T141OK⟩

private def q10Shape17T154 : Tree := (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 16 (.split 14 (.split 17 (.split 11 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 11 (.split 9 (.split 12 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 1 2 4 5))) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))))
private theorem q10Shape17T154OK : fastTreeOK (forms 17) 3145728 265027632 q10Shape17T154=true := by decide

private def q10Shape17T155 : Tree := (.split 3 (.split 11 (.split 16 (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 12 (.split 17 (.split 10 (.split 9 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 1 2 4 5 6))) (.split 9 (.tip (.cover 0 2 4 5 7)) (.tip (.cover 0 1 3 5 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 7 9)))
private theorem q10Shape17T155OK : fastTreeOK (forms 17) 3145760 265027600 q10Shape17T155=true := by decide

private def q10Shape17T153 : Tree := .split 5 q10Shape17T154 q10Shape17T155
private theorem q10Shape17T153OK : fastTreeOK (forms 17) 3145728 265027600 q10Shape17T153=true := by
  change (fastTreeOK (forms 17) 3145728 (265027600 ||| 2^5) q10Shape17T154 &&
    fastTreeOK (forms 17) (3145728 ||| 2^5) 265027600 q10Shape17T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T154OK,q10Shape17T155OK⟩

private def q10Shape17T156 : Tree := (.split 5 (.split 3 (.split 6 (.split 10 (.split 11 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape17T156OK : fastTreeOK (forms 17) 3145744 265027584 q10Shape17T156=true := by decide

private def q10Shape17T152 : Tree := .split 4 q10Shape17T153 q10Shape17T156
private theorem q10Shape17T152OK : fastTreeOK (forms 17) 3145728 265027584 q10Shape17T152=true := by
  change (fastTreeOK (forms 17) 3145728 (265027584 ||| 2^4) q10Shape17T153 &&
    fastTreeOK (forms 17) (3145728 ||| 2^4) 265027584 q10Shape17T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T153OK,q10Shape17T156OK⟩

private def q10Shape17T130 : Tree := .split 21 q10Shape17T131 q10Shape17T152
private theorem q10Shape17T130OK : fastTreeOK (forms 17) 1048576 265027584 q10Shape17T130=true := by
  change (fastTreeOK (forms 17) 1048576 (265027584 ||| 2^21) q10Shape17T131 &&
    fastTreeOK (forms 17) (1048576 ||| 2^21) 265027584 q10Shape17T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T131OK,q10Shape17T152OK⟩

private def q10Shape17T160 : Tree := (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.split 17 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 15 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 8))))
private theorem q10Shape17T160OK : fastTreeOK (forms 17) 135266304 132907056 q10Shape17T160=true := by decide

private def q10Shape17T161 : Tree := (.split 10 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 11 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 8)) (.tip (.cover 0 3 6 7 8))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 15 (.split 16 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 8))))
private theorem q10Shape17T161OK : fastTreeOK (forms 17) 135266336 132907024 q10Shape17T161=true := by decide

private def q10Shape17T159 : Tree := .split 5 q10Shape17T160 q10Shape17T161
private theorem q10Shape17T159OK : fastTreeOK (forms 17) 135266304 132907024 q10Shape17T159=true := by
  change (fastTreeOK (forms 17) 135266304 (132907024 ||| 2^5) q10Shape17T160 &&
    fastTreeOK (forms 17) (135266304 ||| 2^5) 132907024 q10Shape17T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T160OK,q10Shape17T161OK⟩

private def q10Shape17T162 : Tree := (.split 10 (.split 15 (.split 2 (.split 3 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape17T162OK : fastTreeOK (forms 17) 135266320 132907008 q10Shape17T162=true := by decide

private def q10Shape17T158 : Tree := .split 4 q10Shape17T159 q10Shape17T162
private theorem q10Shape17T158OK : fastTreeOK (forms 17) 135266304 132907008 q10Shape17T158=true := by
  change (fastTreeOK (forms 17) 135266304 (132907008 ||| 2^4) q10Shape17T159 &&
    fastTreeOK (forms 17) (135266304 ||| 2^4) 132907008 q10Shape17T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T159OK,q10Shape17T162OK⟩

private def q10Shape17T163 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape17T163OK : fastTreeOK (forms 17) 137363456 130809856 q10Shape17T163=true := by decide

private def q10Shape17T157 : Tree := .split 21 q10Shape17T158 q10Shape17T163
private theorem q10Shape17T157OK : fastTreeOK (forms 17) 135266304 130809856 q10Shape17T157=true := by
  change (fastTreeOK (forms 17) 135266304 (130809856 ||| 2^21) q10Shape17T158 &&
    fastTreeOK (forms 17) (135266304 ||| 2^21) 130809856 q10Shape17T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T158OK,q10Shape17T163OK⟩

private def q10Shape17T129 : Tree := .split 27 q10Shape17T130 q10Shape17T157
private theorem q10Shape17T129OK : fastTreeOK (forms 17) 1048576 130809856 q10Shape17T129=true := by
  change (fastTreeOK (forms 17) 1048576 (130809856 ||| 2^27) q10Shape17T130 &&
    fastTreeOK (forms 17) (1048576 ||| 2^27) 130809856 q10Shape17T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T130OK,q10Shape17T157OK⟩

private def q10Shape17T164 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T164OK : fastTreeOK (forms 17) 17825792 114032640 q10Shape17T164=true := by decide

private def q10Shape17T128 : Tree := .split 24 q10Shape17T129 q10Shape17T164
private theorem q10Shape17T128OK : fastTreeOK (forms 17) 1048576 114032640 q10Shape17T128=true := by
  change (fastTreeOK (forms 17) 1048576 (114032640 ||| 2^24) q10Shape17T129 &&
    fastTreeOK (forms 17) (1048576 ||| 2^24) 114032640 q10Shape17T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T129OK,q10Shape17T164OK⟩

private def q10Shape17T165 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T165OK : fastTreeOK (forms 17) 68157440 46923776 q10Shape17T165=true := by decide

private def q10Shape17T127 : Tree := .split 26 q10Shape17T128 q10Shape17T165
private theorem q10Shape17T127OK : fastTreeOK (forms 17) 1048576 46923776 q10Shape17T127=true := by
  change (fastTreeOK (forms 17) 1048576 (46923776 ||| 2^26) q10Shape17T128 &&
    fastTreeOK (forms 17) (1048576 ||| 2^26) 46923776 q10Shape17T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T128OK,q10Shape17T165OK⟩

private def q10Shape17T166 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape17T166OK : fastTreeOK (forms 17) 9437184 38535168 q10Shape17T166=true := by decide

private def q10Shape17T126 : Tree := .split 23 q10Shape17T127 q10Shape17T166
private theorem q10Shape17T126OK : fastTreeOK (forms 17) 1048576 38535168 q10Shape17T126=true := by
  change (fastTreeOK (forms 17) 1048576 (38535168 ||| 2^23) q10Shape17T127 &&
    fastTreeOK (forms 17) (1048576 ||| 2^23) 38535168 q10Shape17T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T127OK,q10Shape17T166OK⟩

private def q10Shape17T167 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T167OK : fastTreeOK (forms 17) 5242880 34340864 q10Shape17T167=true := by decide

private def q10Shape17T125 : Tree := .split 22 q10Shape17T126 q10Shape17T167
private theorem q10Shape17T125OK : fastTreeOK (forms 17) 1048576 34340864 q10Shape17T125=true := by
  change (fastTreeOK (forms 17) 1048576 (34340864 ||| 2^22) q10Shape17T126 &&
    fastTreeOK (forms 17) (1048576 ||| 2^22) 34340864 q10Shape17T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T126OK,q10Shape17T167OK⟩

private def q10Shape17T3 : Tree := .split 20 q10Shape17T4 q10Shape17T125
private theorem q10Shape17T3OK : fastTreeOK (forms 17) 0 34340864 q10Shape17T3=true := by
  change (fastTreeOK (forms 17) 0 (34340864 ||| 2^20) q10Shape17T4 &&
    fastTreeOK (forms 17) (0 ||| 2^20) 34340864 q10Shape17T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T4OK,q10Shape17T125OK⟩

private def q10Shape17T179 : Tree := (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 14 (.split 17 (.tip (.cover 0 2 3 7 8)) (.split 15 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 7 8 9)) (.tip (.cover 0 2 7 8 9)))) (.split 2 (.split 8 (.split 13 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))))) (.tip (.cover 0 1 4 5 9))))
private theorem q10Shape17T179OK : fastTreeOK (forms 17) 524288 267652144 q10Shape17T179=true := by decide

private def q10Shape17T180 : Tree := (.split 16 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 15 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 2 3 4))))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T180OK : fastTreeOK (forms 17) 526336 267650096 q10Shape17T180=true := by decide

private def q10Shape17T178 : Tree := .split 11 q10Shape17T179 q10Shape17T180
private theorem q10Shape17T178OK : fastTreeOK (forms 17) 524288 267650096 q10Shape17T178=true := by
  change (fastTreeOK (forms 17) 524288 (267650096 ||| 2^11) q10Shape17T179 &&
    fastTreeOK (forms 17) (524288 ||| 2^11) 267650096 q10Shape17T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T179OK,q10Shape17T180OK⟩

private def q10Shape17T181 : Tree := (.split 2 (.split 8 (.split 13 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 16 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.split 15 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 7 8 9))) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 2 7 8 9))))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 2 3 4 5 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape17T181OK : fastTreeOK (forms 17) 525312 267649072 q10Shape17T181=true := by decide

private def q10Shape17T177 : Tree := .split 10 q10Shape17T178 q10Shape17T181
private theorem q10Shape17T177OK : fastTreeOK (forms 17) 524288 267649072 q10Shape17T177=true := by
  change (fastTreeOK (forms 17) 524288 (267649072 ||| 2^10) q10Shape17T178 &&
    fastTreeOK (forms 17) (524288 ||| 2^10) 267649072 q10Shape17T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T178OK,q10Shape17T181OK⟩

private def q10Shape17T182 : Tree := (.split 11 (.split 16 (.split 3 (.split 6 (.tip (.cover 0 3 4 7 8)) (.split 10 (.split 15 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.split 2 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))) (.split 15 (.split 2 (.split 8 (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 6 7 8 9))))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T182OK : fastTreeOK (forms 17) 524320 267649040 q10Shape17T182=true := by decide

private def q10Shape17T176 : Tree := .split 5 q10Shape17T177 q10Shape17T182
private theorem q10Shape17T176OK : fastTreeOK (forms 17) 524288 267649040 q10Shape17T176=true := by
  change (fastTreeOK (forms 17) 524288 (267649040 ||| 2^5) q10Shape17T177 &&
    fastTreeOK (forms 17) (524288 ||| 2^5) 267649040 q10Shape17T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T177OK,q10Shape17T182OK⟩

private def q10Shape17T187 : Tree := (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 15 (.split 16 (.split 9 (.split 3 (.tip (.cover 0 4 7 8 9)) (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 2 3 4 5 6))) (.tip (.cover 0 6 7 8 9)))) (.split 15 (.split 16 (.split 11 (.tip (.cover 0 1 5 6 9)) (.split 9 (.split 3 (.tip (.cover 0 4 7 8 9)) (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 0 1 3 5 9)))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))))
private theorem q10Shape17T187OK : fastTreeOK (forms 17) 524304 267657508 q10Shape17T187=true := by decide

private def q10Shape17T188 : Tree := (.split 11 (.split 16 (.split 3 (.split 6 (.tip (.cover 0 3 4 7 8)) (.split 10 (.split 15 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 7 8 9))) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.split 9 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 15 (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 5)))) (.tip (.cover 0 6 7 8 9))))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 2 3 4 5 6))) (.tip (.cover 2 3 4 5 6)))
private theorem q10Shape17T188OK : fastTreeOK (forms 17) 524336 267657476 q10Shape17T188=true := by decide

private def q10Shape17T186 : Tree := .split 5 q10Shape17T187 q10Shape17T188
private theorem q10Shape17T186OK : fastTreeOK (forms 17) 524304 267657476 q10Shape17T186=true := by
  change (fastTreeOK (forms 17) 524304 (267657476 ||| 2^5) q10Shape17T187 &&
    fastTreeOK (forms 17) (524304 ||| 2^5) 267657476 q10Shape17T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T187OK,q10Shape17T188OK⟩

private def q10Shape17T189 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T189OK : fastTreeOK (forms 17) 532496 267649284 q10Shape17T189=true := by decide

private def q10Shape17T185 : Tree := .split 13 q10Shape17T186 q10Shape17T189
private theorem q10Shape17T185OK : fastTreeOK (forms 17) 524304 267649284 q10Shape17T185=true := by
  change (fastTreeOK (forms 17) 524304 (267649284 ||| 2^13) q10Shape17T186 &&
    fastTreeOK (forms 17) (524304 ||| 2^13) 267649284 q10Shape17T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T186OK,q10Shape17T189OK⟩

private def q10Shape17T190 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T190OK : fastTreeOK (forms 17) 524560 267649028 q10Shape17T190=true := by decide

private def q10Shape17T184 : Tree := .split 8 q10Shape17T185 q10Shape17T190
private theorem q10Shape17T184OK : fastTreeOK (forms 17) 524304 267649028 q10Shape17T184=true := by
  change (fastTreeOK (forms 17) 524304 (267649028 ||| 2^8) q10Shape17T185 &&
    fastTreeOK (forms 17) (524304 ||| 2^8) 267649028 q10Shape17T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T185OK,q10Shape17T190OK⟩

private def q10Shape17T191 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape17T191OK : fastTreeOK (forms 17) 524308 267649024 q10Shape17T191=true := by decide

private def q10Shape17T183 : Tree := .split 2 q10Shape17T184 q10Shape17T191
private theorem q10Shape17T183OK : fastTreeOK (forms 17) 524304 267649024 q10Shape17T183=true := by
  change (fastTreeOK (forms 17) 524304 (267649024 ||| 2^2) q10Shape17T184 &&
    fastTreeOK (forms 17) (524304 ||| 2^2) 267649024 q10Shape17T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T184OK,q10Shape17T191OK⟩

private def q10Shape17T175 : Tree := .split 4 q10Shape17T176 q10Shape17T183
private theorem q10Shape17T175OK : fastTreeOK (forms 17) 524288 267649024 q10Shape17T175=true := by
  change (fastTreeOK (forms 17) 524288 (267649024 ||| 2^4) q10Shape17T176 &&
    fastTreeOK (forms 17) (524288 ||| 2^4) 267649024 q10Shape17T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T176OK,q10Shape17T183OK⟩

private def q10Shape17T194 : Tree := (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 6 (.tip (.cover 1 3 4 5 6)) (.tip (.cover 1 2 4 5 6))))) (.tip (.cover 0 1 4 6 9))) (.split 9 (.split 12 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.tip (.cover 0 1 2 4 5))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 9)))) (.split 11 (.split 3 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 1 4 6 7 9))) (.tip (.cover 0 1 3 6 9))))
private theorem q10Shape17T194OK : fastTreeOK (forms 17) 2621440 265551920 q10Shape17T194=true := by decide

private def q10Shape17T195 : Tree := (.split 3 (.split 6 (.split 10 (.split 11 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 6 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape17T195OK : fastTreeOK (forms 17) 2621472 265551888 q10Shape17T195=true := by decide

private def q10Shape17T193 : Tree := .split 5 q10Shape17T194 q10Shape17T195
private theorem q10Shape17T193OK : fastTreeOK (forms 17) 2621440 265551888 q10Shape17T193=true := by
  change (fastTreeOK (forms 17) 2621440 (265551888 ||| 2^5) q10Shape17T194 &&
    fastTreeOK (forms 17) (2621440 ||| 2^5) 265551888 q10Shape17T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T194OK,q10Shape17T195OK⟩

private def q10Shape17T196 : Tree := (.split 5 (.split 3 (.split 10 (.split 15 (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 12 (.split 17 (.split 11 (.split 9 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 1 2 4 5 6))) (.split 9 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 3 5 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5)))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape17T196OK : fastTreeOK (forms 17) 2621456 265551872 q10Shape17T196=true := by decide

private def q10Shape17T192 : Tree := .split 4 q10Shape17T193 q10Shape17T196
private theorem q10Shape17T192OK : fastTreeOK (forms 17) 2621440 265551872 q10Shape17T192=true := by
  change (fastTreeOK (forms 17) 2621440 (265551872 ||| 2^4) q10Shape17T193 &&
    fastTreeOK (forms 17) (2621440 ||| 2^4) 265551872 q10Shape17T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T193OK,q10Shape17T196OK⟩

private def q10Shape17T174 : Tree := .split 21 q10Shape17T175 q10Shape17T192
private theorem q10Shape17T174OK : fastTreeOK (forms 17) 524288 265551872 q10Shape17T174=true := by
  change (fastTreeOK (forms 17) 524288 (265551872 ||| 2^21) q10Shape17T175 &&
    fastTreeOK (forms 17) (524288 ||| 2^21) 265551872 q10Shape17T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T175OK,q10Shape17T192OK⟩

private def q10Shape17T201 : Tree := (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 13 (.split 14 (.split 17 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7))))
private theorem q10Shape17T201OK : fastTreeOK (forms 17) 67633152 200541232 q10Shape17T201=true := by decide

private def q10Shape17T202 : Tree := (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 3 (.split 6 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 6 7 8))) (.tip (.cover 0 2 7 8 9)))) (.split 16 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7))))
private theorem q10Shape17T202OK : fastTreeOK (forms 17) 67634176 200540208 q10Shape17T202=true := by decide

private def q10Shape17T200 : Tree := .split 10 q10Shape17T201 q10Shape17T202
private theorem q10Shape17T200OK : fastTreeOK (forms 17) 67633152 200540208 q10Shape17T200=true := by
  change (fastTreeOK (forms 17) 67633152 (200540208 ||| 2^10) q10Shape17T201 &&
    fastTreeOK (forms 17) (67633152 ||| 2^10) 200540208 q10Shape17T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T201OK,q10Shape17T202OK⟩

private def q10Shape17T203 : Tree := (.split 11 (.split 16 (.split 2 (.split 3 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T203OK : fastTreeOK (forms 17) 67633184 200540176 q10Shape17T203=true := by decide

private def q10Shape17T199 : Tree := .split 5 q10Shape17T200 q10Shape17T203
private theorem q10Shape17T199OK : fastTreeOK (forms 17) 67633152 200540176 q10Shape17T199=true := by
  change (fastTreeOK (forms 17) 67633152 (200540176 ||| 2^5) q10Shape17T200 &&
    fastTreeOK (forms 17) (67633152 ||| 2^5) 200540176 q10Shape17T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T200OK,q10Shape17T203OK⟩

private def q10Shape17T205 : Tree := (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 9 (.split 12 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 3 6 7 8))) (.tip (.cover 0 3 7 8 9)))) (.split 15 (.split 16 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 6 7 8 9)))) (.split 15 (.split 16 (.split 11 (.tip (.cover 0 1 5 6 9)) (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))))
private theorem q10Shape17T205OK : fastTreeOK (forms 17) 67633168 200540192 q10Shape17T205=true := by decide

private def q10Shape17T206 : Tree := (.split 11 (.split 16 (.split 2 (.split 3 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape17T206OK : fastTreeOK (forms 17) 67633200 200540160 q10Shape17T206=true := by decide

private def q10Shape17T204 : Tree := .split 5 q10Shape17T205 q10Shape17T206
private theorem q10Shape17T204OK : fastTreeOK (forms 17) 67633168 200540160 q10Shape17T204=true := by
  change (fastTreeOK (forms 17) 67633168 (200540160 ||| 2^5) q10Shape17T205 &&
    fastTreeOK (forms 17) (67633168 ||| 2^5) 200540160 q10Shape17T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T205OK,q10Shape17T206OK⟩

private def q10Shape17T198 : Tree := .split 4 q10Shape17T199 q10Shape17T204
private theorem q10Shape17T198OK : fastTreeOK (forms 17) 67633152 200540160 q10Shape17T198=true := by
  change (fastTreeOK (forms 17) 67633152 (200540160 ||| 2^4) q10Shape17T199 &&
    fastTreeOK (forms 17) (67633152 ||| 2^4) 200540160 q10Shape17T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T199OK,q10Shape17T204OK⟩

private def q10Shape17T207 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape17T207OK : fastTreeOK (forms 17) 69730304 198443008 q10Shape17T207=true := by decide

private def q10Shape17T197 : Tree := .split 21 q10Shape17T198 q10Shape17T207
private theorem q10Shape17T197OK : fastTreeOK (forms 17) 67633152 198443008 q10Shape17T197=true := by
  change (fastTreeOK (forms 17) 67633152 (198443008 ||| 2^21) q10Shape17T198 &&
    fastTreeOK (forms 17) (67633152 ||| 2^21) 198443008 q10Shape17T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T198OK,q10Shape17T207OK⟩

private def q10Shape17T173 : Tree := .split 26 q10Shape17T174 q10Shape17T197
private theorem q10Shape17T173OK : fastTreeOK (forms 17) 524288 198443008 q10Shape17T173=true := by
  change (fastTreeOK (forms 17) 524288 (198443008 ||| 2^26) q10Shape17T174 &&
    fastTreeOK (forms 17) (524288 ||| 2^26) 198443008 q10Shape17T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T174OK,q10Shape17T197OK⟩

private def q10Shape17T208 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape17T208OK : fastTreeOK (forms 17) 17301504 181665792 q10Shape17T208=true := by decide

private def q10Shape17T172 : Tree := .split 24 q10Shape17T173 q10Shape17T208
private theorem q10Shape17T172OK : fastTreeOK (forms 17) 524288 181665792 q10Shape17T172=true := by
  change (fastTreeOK (forms 17) 524288 (181665792 ||| 2^24) q10Shape17T173 &&
    fastTreeOK (forms 17) (524288 ||| 2^24) 181665792 q10Shape17T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T173OK,q10Shape17T208OK⟩

private def q10Shape17T209 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T209OK : fastTreeOK (forms 17) 134742016 47448064 q10Shape17T209=true := by decide

private def q10Shape17T171 : Tree := .split 27 q10Shape17T172 q10Shape17T209
private theorem q10Shape17T171OK : fastTreeOK (forms 17) 524288 47448064 q10Shape17T171=true := by
  change (fastTreeOK (forms 17) 524288 (47448064 ||| 2^27) q10Shape17T172 &&
    fastTreeOK (forms 17) (524288 ||| 2^27) 47448064 q10Shape17T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T172OK,q10Shape17T209OK⟩

private def q10Shape17T210 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T210OK : fastTreeOK (forms 17) 8912896 39059456 q10Shape17T210=true := by decide

private def q10Shape17T170 : Tree := .split 23 q10Shape17T171 q10Shape17T210
private theorem q10Shape17T170OK : fastTreeOK (forms 17) 524288 39059456 q10Shape17T170=true := by
  change (fastTreeOK (forms 17) 524288 (39059456 ||| 2^23) q10Shape17T171 &&
    fastTreeOK (forms 17) (524288 ||| 2^23) 39059456 q10Shape17T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T171OK,q10Shape17T210OK⟩

private def q10Shape17T211 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape17T211OK : fastTreeOK (forms 17) 4718592 34865152 q10Shape17T211=true := by decide

private def q10Shape17T169 : Tree := .split 22 q10Shape17T170 q10Shape17T211
private theorem q10Shape17T169OK : fastTreeOK (forms 17) 524288 34865152 q10Shape17T169=true := by
  change (fastTreeOK (forms 17) 524288 (34865152 ||| 2^22) q10Shape17T170 &&
    fastTreeOK (forms 17) (524288 ||| 2^22) 34865152 q10Shape17T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T170OK,q10Shape17T211OK⟩

private def q10Shape17T212 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T212OK : fastTreeOK (forms 17) 1572864 33816576 q10Shape17T212=true := by decide

private def q10Shape17T168 : Tree := .split 20 q10Shape17T169 q10Shape17T212
private theorem q10Shape17T168OK : fastTreeOK (forms 17) 524288 33816576 q10Shape17T168=true := by
  change (fastTreeOK (forms 17) 524288 (33816576 ||| 2^20) q10Shape17T169 &&
    fastTreeOK (forms 17) (524288 ||| 2^20) 33816576 q10Shape17T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T169OK,q10Shape17T212OK⟩

private def q10Shape17T2 : Tree := .split 19 q10Shape17T3 q10Shape17T168
private theorem q10Shape17T2OK : fastTreeOK (forms 17) 0 33816576 q10Shape17T2=true := by
  change (fastTreeOK (forms 17) 0 (33816576 ||| 2^19) q10Shape17T3 &&
    fastTreeOK (forms 17) (0 ||| 2^19) 33816576 q10Shape17T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T3OK,q10Shape17T168OK⟩

private def q10Shape17T228 : Tree := (.tip (.small 0))
private theorem q10Shape17T228OK : fastTreeOK (forms 17) 262144 267936525 q10Shape17T228=true := by decide

private def q10Shape17T230 : Tree := (.tip (.small 0))
private theorem q10Shape17T230OK : fastTreeOK (forms 17) 262145 267936526 q10Shape17T230=true := by decide

private def q10Shape17T232 : Tree := (.tip (.small 0))
private theorem q10Shape17T232OK : fastTreeOK (forms 17) 262147 267936652 q10Shape17T232=true := by decide

private def q10Shape17T234 : Tree := (.split 5 (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 10 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 15 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 5 7 8 9)))) (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 0 5 7 8 9))))) (.split 10 (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 5 7 8 9)))) (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 5 7 8 9)))))
private theorem q10Shape17T234OK : fastTreeOK (forms 17) 262275 267936540 q10Shape17T234=true := by decide

private def q10Shape17T235 : Tree := (.split 5 (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.drop 1 6 7 (some 0) (some 5) (some 5))) (.tip (.drop 6 7 8 (some 5) (some 5) (some 5)))) (.tip (.cover 0 1 4 5 9))) (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 5 7 8 9)))) (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape17T235OK : fastTreeOK (forms 17) 262291 267936524 q10Shape17T235=true := by decide

private def q10Shape17T233 : Tree := .split 4 q10Shape17T234 q10Shape17T235
private theorem q10Shape17T233OK : fastTreeOK (forms 17) 262275 267936524 q10Shape17T233=true := by
  change (fastTreeOK (forms 17) 262275 (267936524 ||| 2^4) q10Shape17T234 &&
    fastTreeOK (forms 17) (262275 ||| 2^4) 267936524 q10Shape17T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T234OK,q10Shape17T235OK⟩

private def q10Shape17T231 : Tree := .split 7 q10Shape17T232 q10Shape17T233
private theorem q10Shape17T231OK : fastTreeOK (forms 17) 262147 267936524 q10Shape17T231=true := by
  change (fastTreeOK (forms 17) 262147 (267936524 ||| 2^7) q10Shape17T232 &&
    fastTreeOK (forms 17) (262147 ||| 2^7) 267936524 q10Shape17T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T232OK,q10Shape17T233OK⟩

private def q10Shape17T229 : Tree := .split 1 q10Shape17T230 q10Shape17T231
private theorem q10Shape17T229OK : fastTreeOK (forms 17) 262145 267936524 q10Shape17T229=true := by
  change (fastTreeOK (forms 17) 262145 (267936524 ||| 2^1) q10Shape17T230 &&
    fastTreeOK (forms 17) (262145 ||| 2^1) 267936524 q10Shape17T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T230OK,q10Shape17T231OK⟩

private def q10Shape17T227 : Tree := .split 0 q10Shape17T228 q10Shape17T229
private theorem q10Shape17T227OK : fastTreeOK (forms 17) 262144 267936524 q10Shape17T227=true := by
  change (fastTreeOK (forms 17) 262144 (267936524 ||| 2^0) q10Shape17T228 &&
    fastTreeOK (forms 17) (262144 ||| 2^0) 267936524 q10Shape17T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T228OK,q10Shape17T229OK⟩

private def q10Shape17T236 : Tree := (.tip (.cover 1 2 3 4 5))
private theorem q10Shape17T236OK : fastTreeOK (forms 17) 278528 267920140 q10Shape17T236=true := by decide

private def q10Shape17T226 : Tree := .split 14 q10Shape17T227 q10Shape17T236
private theorem q10Shape17T226OK : fastTreeOK (forms 17) 262144 267920140 q10Shape17T226=true := by
  change (fastTreeOK (forms 17) 262144 (267920140 ||| 2^14) q10Shape17T227 &&
    fastTreeOK (forms 17) (262144 ||| 2^14) 267920140 q10Shape17T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T227OK,q10Shape17T236OK⟩

private def q10Shape17T237 : Tree := (.tip (.cover 1 2 3 4 5))
private theorem q10Shape17T237OK : fastTreeOK (forms 17) 262656 267919628 q10Shape17T237=true := by decide

private def q10Shape17T225 : Tree := .split 9 q10Shape17T226 q10Shape17T237
private theorem q10Shape17T225OK : fastTreeOK (forms 17) 262144 267919628 q10Shape17T225=true := by
  change (fastTreeOK (forms 17) 262144 (267919628 ||| 2^9) q10Shape17T226 &&
    fastTreeOK (forms 17) (262144 ||| 2^9) 267919628 q10Shape17T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T226OK,q10Shape17T237OK⟩

private def q10Shape17T238 : Tree := (.tip (.cover 1 2 3 4 5))
private theorem q10Shape17T238OK : fastTreeOK (forms 17) 262152 267919620 q10Shape17T238=true := by decide

private def q10Shape17T224 : Tree := .split 3 q10Shape17T225 q10Shape17T238
private theorem q10Shape17T224OK : fastTreeOK (forms 17) 262144 267919620 q10Shape17T224=true := by
  change (fastTreeOK (forms 17) 262144 (267919620 ||| 2^3) q10Shape17T225 &&
    fastTreeOK (forms 17) (262144 ||| 2^3) 267919620 q10Shape17T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T225OK,q10Shape17T238OK⟩

private def q10Shape17T239 : Tree := (.split 4 (.split 5 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 1 3 4 5 9))) (.split 6 (.split 11 (.split 16 (.split 10 (.split 12 (.tip (.cover 0 1 4 6 8)) (.tip (.cover 1 2 4 5 9))) (.split 12 (.tip (.cover 0 4 6 7 8)) (.tip (.cover 0 1 3 6 8)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 2 6 7)))) (.split 5 (.split 6 (.split 10 (.split 15 (.split 11 (.split 12 (.tip (.cover 0 1 4 6 7)) (.tip (.cover 1 2 4 5 9))) (.split 12 (.tip (.cover 0 4 6 7 8)) (.tip (.cover 0 1 3 6 7)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 5 9))))
private theorem q10Shape17T239OK : fastTreeOK (forms 17) 17039360 251142404 q10Shape17T239=true := by decide

private def q10Shape17T223 : Tree := .split 24 q10Shape17T224 q10Shape17T239
private theorem q10Shape17T223OK : fastTreeOK (forms 17) 262144 251142404 q10Shape17T223=true := by
  change (fastTreeOK (forms 17) 262144 (251142404 ||| 2^24) q10Shape17T224 &&
    fastTreeOK (forms 17) (262144 ||| 2^24) 251142404 q10Shape17T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T224OK,q10Shape17T239OK⟩

private def q10Shape17T240 : Tree := (.tip (.cover 1 2 3 4 6))
private theorem q10Shape17T240OK : fastTreeOK (forms 17) 270336 251134212 q10Shape17T240=true := by decide

private def q10Shape17T222 : Tree := .split 13 q10Shape17T223 q10Shape17T240
private theorem q10Shape17T222OK : fastTreeOK (forms 17) 262144 251134212 q10Shape17T222=true := by
  change (fastTreeOK (forms 17) 262144 (251134212 ||| 2^13) q10Shape17T223 &&
    fastTreeOK (forms 17) (262144 ||| 2^13) 251134212 q10Shape17T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T223OK,q10Shape17T240OK⟩

private def q10Shape17T241 : Tree := (.tip (.cover 1 2 3 4 6))
private theorem q10Shape17T241OK : fastTreeOK (forms 17) 262400 251133956 q10Shape17T241=true := by decide

private def q10Shape17T221 : Tree := .split 8 q10Shape17T222 q10Shape17T241
private theorem q10Shape17T221OK : fastTreeOK (forms 17) 262144 251133956 q10Shape17T221=true := by
  change (fastTreeOK (forms 17) 262144 (251133956 ||| 2^8) q10Shape17T222 &&
    fastTreeOK (forms 17) (262144 ||| 2^8) 251133956 q10Shape17T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T222OK,q10Shape17T241OK⟩

private def q10Shape17T242 : Tree := (.tip (.cover 1 2 3 4 6))
private theorem q10Shape17T242OK : fastTreeOK (forms 17) 262148 251133952 q10Shape17T242=true := by decide

private def q10Shape17T220 : Tree := .split 2 q10Shape17T221 q10Shape17T242
private theorem q10Shape17T220OK : fastTreeOK (forms 17) 262144 251133952 q10Shape17T220=true := by
  change (fastTreeOK (forms 17) 262144 (251133952 ||| 2^2) q10Shape17T221 &&
    fastTreeOK (forms 17) (262144 ||| 2^2) 251133952 q10Shape17T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T221OK,q10Shape17T242OK⟩

private def q10Shape17T246 : Tree := (.split 14 (.split 4 (.split 5 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 1 3 4 6 9))) (.split 6 (.split 11 (.split 16 (.split 10 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 1 2 4 6 9))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.tip (.cover 0 1 3 5 8)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 7)))) (.split 5 (.split 6 (.split 10 (.split 15 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 1 2 4 6 9))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.tip (.cover 0 1 3 5 7)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 1 2 5 9)))) (.tip (.cover 1 2 3 4 5)))
private theorem q10Shape17T246OK : fastTreeOK (forms 17) 2359296 265814536 q10Shape17T246=true := by decide

private def q10Shape17T247 : Tree := (.tip (.cover 1 2 3 4 5))
private theorem q10Shape17T247OK : fastTreeOK (forms 17) 2359808 265814024 q10Shape17T247=true := by decide

private def q10Shape17T245 : Tree := .split 9 q10Shape17T246 q10Shape17T247
private theorem q10Shape17T245OK : fastTreeOK (forms 17) 2359296 265814024 q10Shape17T245=true := by
  change (fastTreeOK (forms 17) 2359296 (265814024 ||| 2^9) q10Shape17T246 &&
    fastTreeOK (forms 17) (2359296 ||| 2^9) 265814024 q10Shape17T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T246OK,q10Shape17T247OK⟩

private def q10Shape17T248 : Tree := (.tip (.cover 1 2 3 4 5))
private theorem q10Shape17T248OK : fastTreeOK (forms 17) 2359304 265814016 q10Shape17T248=true := by decide

private def q10Shape17T244 : Tree := .split 3 q10Shape17T245 q10Shape17T248
private theorem q10Shape17T244OK : fastTreeOK (forms 17) 2359296 265814016 q10Shape17T244=true := by
  change (fastTreeOK (forms 17) 2359296 (265814016 ||| 2^3) q10Shape17T245 &&
    fastTreeOK (forms 17) (2359296 ||| 2^3) 265814016 q10Shape17T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T245OK,q10Shape17T248OK⟩

private def q10Shape17T249 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape17T249OK : fastTreeOK (forms 17) 19136512 249036800 q10Shape17T249=true := by decide

private def q10Shape17T243 : Tree := .split 24 q10Shape17T244 q10Shape17T249
private theorem q10Shape17T243OK : fastTreeOK (forms 17) 2359296 249036800 q10Shape17T243=true := by
  change (fastTreeOK (forms 17) 2359296 (249036800 ||| 2^24) q10Shape17T244 &&
    fastTreeOK (forms 17) (2359296 ||| 2^24) 249036800 q10Shape17T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T244OK,q10Shape17T249OK⟩

private def q10Shape17T219 : Tree := .split 21 q10Shape17T220 q10Shape17T243
private theorem q10Shape17T219OK : fastTreeOK (forms 17) 262144 249036800 q10Shape17T219=true := by
  change (fastTreeOK (forms 17) 262144 (249036800 ||| 2^21) q10Shape17T220 &&
    fastTreeOK (forms 17) (262144 ||| 2^21) 249036800 q10Shape17T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T220OK,q10Shape17T243OK⟩

private def q10Shape17T250 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T250OK : fastTreeOK (forms 17) 134479872 114819072 q10Shape17T250=true := by decide

private def q10Shape17T218 : Tree := .split 27 q10Shape17T219 q10Shape17T250
private theorem q10Shape17T218OK : fastTreeOK (forms 17) 262144 114819072 q10Shape17T218=true := by
  change (fastTreeOK (forms 17) 262144 (114819072 ||| 2^27) q10Shape17T219 &&
    fastTreeOK (forms 17) (262144 ||| 2^27) 114819072 q10Shape17T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T219OK,q10Shape17T250OK⟩

private def q10Shape17T251 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape17T251OK : fastTreeOK (forms 17) 67371008 47710208 q10Shape17T251=true := by decide

private def q10Shape17T217 : Tree := .split 26 q10Shape17T218 q10Shape17T251
private theorem q10Shape17T217OK : fastTreeOK (forms 17) 262144 47710208 q10Shape17T217=true := by
  change (fastTreeOK (forms 17) 262144 (47710208 ||| 2^26) q10Shape17T218 &&
    fastTreeOK (forms 17) (262144 ||| 2^26) 47710208 q10Shape17T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T218OK,q10Shape17T251OK⟩

private def q10Shape17T252 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape17T252OK : fastTreeOK (forms 17) 8650752 39321600 q10Shape17T252=true := by decide

private def q10Shape17T216 : Tree := .split 23 q10Shape17T217 q10Shape17T252
private theorem q10Shape17T216OK : fastTreeOK (forms 17) 262144 39321600 q10Shape17T216=true := by
  change (fastTreeOK (forms 17) 262144 (39321600 ||| 2^23) q10Shape17T217 &&
    fastTreeOK (forms 17) (262144 ||| 2^23) 39321600 q10Shape17T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T217OK,q10Shape17T252OK⟩

private def q10Shape17T253 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape17T253OK : fastTreeOK (forms 17) 4456448 35127296 q10Shape17T253=true := by decide

private def q10Shape17T215 : Tree := .split 22 q10Shape17T216 q10Shape17T253
private theorem q10Shape17T215OK : fastTreeOK (forms 17) 262144 35127296 q10Shape17T215=true := by
  change (fastTreeOK (forms 17) 262144 (35127296 ||| 2^22) q10Shape17T216 &&
    fastTreeOK (forms 17) (262144 ||| 2^22) 35127296 q10Shape17T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T216OK,q10Shape17T253OK⟩

private def q10Shape17T254 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T254OK : fastTreeOK (forms 17) 1310720 34078720 q10Shape17T254=true := by decide

private def q10Shape17T214 : Tree := .split 20 q10Shape17T215 q10Shape17T254
private theorem q10Shape17T214OK : fastTreeOK (forms 17) 262144 34078720 q10Shape17T214=true := by
  change (fastTreeOK (forms 17) 262144 (34078720 ||| 2^20) q10Shape17T215 &&
    fastTreeOK (forms 17) (262144 ||| 2^20) 34078720 q10Shape17T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T215OK,q10Shape17T254OK⟩

private def q10Shape17T255 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape17T255OK : fastTreeOK (forms 17) 786432 33554432 q10Shape17T255=true := by decide

private def q10Shape17T213 : Tree := .split 19 q10Shape17T214 q10Shape17T255
private theorem q10Shape17T213OK : fastTreeOK (forms 17) 262144 33554432 q10Shape17T213=true := by
  change (fastTreeOK (forms 17) 262144 (33554432 ||| 2^19) q10Shape17T214 &&
    fastTreeOK (forms 17) (262144 ||| 2^19) 33554432 q10Shape17T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T214OK,q10Shape17T255OK⟩

private def q10Shape17T1 : Tree := .split 18 q10Shape17T2 q10Shape17T213
private theorem q10Shape17T1OK : fastTreeOK (forms 17) 0 33554432 q10Shape17T1=true := by
  change (fastTreeOK (forms 17) 0 (33554432 ||| 2^18) q10Shape17T2 &&
    fastTreeOK (forms 17) (0 ||| 2^18) 33554432 q10Shape17T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T2OK,q10Shape17T213OK⟩

private def q10Shape17T272 : Tree := (.tip (.small 1))
private theorem q10Shape17T272OK : fastTreeOK (forms 17) 33554432 234720305 q10Shape17T272=true := by decide

private def q10Shape17T274 : Tree := (.tip (.small 1))
private theorem q10Shape17T274OK : fastTreeOK (forms 17) 33554433 234720306 q10Shape17T274=true := by decide

private def q10Shape17T276 : Tree := (.tip (.small 1))
private theorem q10Shape17T276OK : fastTreeOK (forms 17) 33554435 234720432 q10Shape17T276=true := by decide

private def q10Shape17T278 : Tree := (.split 3 (.split 6 (.tip (.cover 0 1 3 4 7)) (.split 8 (.split 9 (.tip (.cover 0 1 4 7 9)) (.split 13 (.tip (.cover 0 1 6 7 9)) (.tip (.cover 1 5 6 7 9)))) (.split 14 (.tip (.cover 0 1 3 7 9)) (.tip (.cover 1 5 6 7 9))))) (.split 8 (.split 13 (.tip (.cover 0 1 6 7 9)) (.split 12 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 1 5 6 7 9)))) (.split 17 (.tip (.cover 0 1 2 3 7)) (.tip (.cover 1 5 6 7 9)))))
private theorem q10Shape17T278OK : fastTreeOK (forms 17) 33554563 234720308 q10Shape17T278=true := by decide

private def q10Shape17T279 : Tree := (.split 3 (.split 8 (.split 9 (.split 13 (.split 14 (.tip (.drop 1 6 7 (some 0) none (some 5))) (.tip (.drop 6 7 8 (some 5) (some 5) (some 5)))) (.tip (.cover 0 1 4 7 9))) (.split 17 (.tip (.cover 0 1 2 3 7)) (.tip (.cover 1 5 6 7 9)))) (.split 14 (.tip (.cover 0 1 3 7 9)) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 0 1 2 7 9)))
private theorem q10Shape17T279OK : fastTreeOK (forms 17) 33554567 234720304 q10Shape17T279=true := by decide

private def q10Shape17T277 : Tree := .split 2 q10Shape17T278 q10Shape17T279
private theorem q10Shape17T277OK : fastTreeOK (forms 17) 33554563 234720304 q10Shape17T277=true := by
  change (fastTreeOK (forms 17) 33554563 (234720304 ||| 2^2) q10Shape17T278 &&
    fastTreeOK (forms 17) (33554563 ||| 2^2) 234720304 q10Shape17T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T278OK,q10Shape17T279OK⟩

private def q10Shape17T275 : Tree := .split 7 q10Shape17T276 q10Shape17T277
private theorem q10Shape17T275OK : fastTreeOK (forms 17) 33554435 234720304 q10Shape17T275=true := by
  change (fastTreeOK (forms 17) 33554435 (234720304 ||| 2^7) q10Shape17T276 &&
    fastTreeOK (forms 17) (33554435 ||| 2^7) 234720304 q10Shape17T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T276OK,q10Shape17T277OK⟩

private def q10Shape17T273 : Tree := .split 1 q10Shape17T274 q10Shape17T275
private theorem q10Shape17T273OK : fastTreeOK (forms 17) 33554433 234720304 q10Shape17T273=true := by
  change (fastTreeOK (forms 17) 33554433 (234720304 ||| 2^1) q10Shape17T274 &&
    fastTreeOK (forms 17) (33554433 ||| 2^1) 234720304 q10Shape17T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T274OK,q10Shape17T275OK⟩

private def q10Shape17T271 : Tree := .split 0 q10Shape17T272 q10Shape17T273
private theorem q10Shape17T271OK : fastTreeOK (forms 17) 33554432 234720304 q10Shape17T271=true := by
  change (fastTreeOK (forms 17) 33554432 (234720304 ||| 2^0) q10Shape17T272 &&
    fastTreeOK (forms 17) (33554432 ||| 2^0) 234720304 q10Shape17T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T272OK,q10Shape17T273OK⟩

private def q10Shape17T280 : Tree := (.tip (.cover 0 2 3 4 7))
private theorem q10Shape17T280OK : fastTreeOK (forms 17) 33619968 234654768 q10Shape17T280=true := by decide

private def q10Shape17T270 : Tree := .split 16 q10Shape17T271 q10Shape17T280
private theorem q10Shape17T270OK : fastTreeOK (forms 17) 33554432 234654768 q10Shape17T270=true := by
  change (fastTreeOK (forms 17) 33554432 (234654768 ||| 2^16) q10Shape17T271 &&
    fastTreeOK (forms 17) (33554432 ||| 2^16) 234654768 q10Shape17T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T271OK,q10Shape17T280OK⟩

private def q10Shape17T281 : Tree := (.tip (.cover 0 2 3 4 7))
private theorem q10Shape17T281OK : fastTreeOK (forms 17) 33556480 234652720 q10Shape17T281=true := by decide

private def q10Shape17T269 : Tree := .split 11 q10Shape17T270 q10Shape17T281
private theorem q10Shape17T269OK : fastTreeOK (forms 17) 33554432 234652720 q10Shape17T269=true := by
  change (fastTreeOK (forms 17) 33554432 (234652720 ||| 2^11) q10Shape17T270 &&
    fastTreeOK (forms 17) (33554432 ||| 2^11) 234652720 q10Shape17T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T270OK,q10Shape17T281OK⟩

private def q10Shape17T282 : Tree := (.tip (.cover 0 2 3 4 7))
private theorem q10Shape17T282OK : fastTreeOK (forms 17) 33554464 234652688 q10Shape17T282=true := by decide

private def q10Shape17T268 : Tree := .split 5 q10Shape17T269 q10Shape17T282
private theorem q10Shape17T268OK : fastTreeOK (forms 17) 33554432 234652688 q10Shape17T268=true := by
  change (fastTreeOK (forms 17) 33554432 (234652688 ||| 2^5) q10Shape17T269 &&
    fastTreeOK (forms 17) (33554432 ||| 2^5) 234652688 q10Shape17T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T269OK,q10Shape17T282OK⟩

private def q10Shape17T285 : Tree := (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 2 6 7 9)))))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 8)) (.tip (.cover 0 3 4 7 9))) (.split 8 (.split 12 (.tip (.cover 0 1 2 4 8)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 1 5 6 8 9)))) (.split 3 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 8)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 0 1 2 7 9)))))
private theorem q10Shape17T285OK : fastTreeOK (forms 17) 167772160 100437040 q10Shape17T285=true := by decide

private def q10Shape17T286 : Tree := (.split 16 (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 8)) (.tip (.cover 0 3 4 7 9))) (.split 13 (.split 17 (.tip (.cover 0 1 2 3 8)) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 1 5 6 8 9)))) (.split 3 (.split 13 (.split 14 (.split 17 (.tip (.cover 0 1 2 3 8)) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 0 1 2 7 9)))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 8)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 1 5 6 8 9))))
private theorem q10Shape17T286OK : fastTreeOK (forms 17) 167774208 100434992 q10Shape17T286=true := by decide

private def q10Shape17T284 : Tree := .split 11 q10Shape17T285 q10Shape17T286
private theorem q10Shape17T284OK : fastTreeOK (forms 17) 167772160 100434992 q10Shape17T284=true := by
  change (fastTreeOK (forms 17) 167772160 (100434992 ||| 2^11) q10Shape17T285 &&
    fastTreeOK (forms 17) (167772160 ||| 2^11) 100434992 q10Shape17T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T285OK,q10Shape17T286OK⟩

private def q10Shape17T289 : Tree := (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 8)) (.tip (.cover 0 3 4 7 9))) (.split 6 (.split 9 (.split 14 (.split 8 (.split 12 (.tip (.cover 0 1 4 6 8)) (.tip (.cover 0 2 4 7 9))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.tip (.cover 0 1 3 6 8)))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 2 5 8)))) (.split 3 (.split 6 (.split 8 (.split 13 (.split 9 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 2 4 7 9))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.tip (.cover 0 1 3 5 8)))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape17T289OK : fastTreeOK (forms 17) 167772192 100502544 q10Shape17T289=true := by decide

private def q10Shape17T290 : Tree := (.split 8 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 8)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 1 5 6 8 9)))
private theorem q10Shape17T290OK : fastTreeOK (forms 17) 167837728 100437008 q10Shape17T290=true := by decide

private def q10Shape17T288 : Tree := .split 16 q10Shape17T289 q10Shape17T290
private theorem q10Shape17T288OK : fastTreeOK (forms 17) 167772192 100437008 q10Shape17T288=true := by
  change (fastTreeOK (forms 17) 167772192 (100437008 ||| 2^16) q10Shape17T289 &&
    fastTreeOK (forms 17) (167772192 ||| 2^16) 100437008 q10Shape17T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T289OK,q10Shape17T290OK⟩

private def q10Shape17T291 : Tree := (.split 16 (.split 13 (.split 14 (.split 17 (.tip (.cover 0 1 2 3 8)) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 1 5 6 8 9))) (.tip (.cover 1 5 6 8 9)))
private theorem q10Shape17T291OK : fastTreeOK (forms 17) 167774240 100434960 q10Shape17T291=true := by decide

private def q10Shape17T287 : Tree := .split 11 q10Shape17T288 q10Shape17T291
private theorem q10Shape17T287OK : fastTreeOK (forms 17) 167772192 100434960 q10Shape17T287=true := by
  change (fastTreeOK (forms 17) 167772192 (100434960 ||| 2^11) q10Shape17T288 &&
    fastTreeOK (forms 17) (167772192 ||| 2^11) 100434960 q10Shape17T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T288OK,q10Shape17T291OK⟩

private def q10Shape17T283 : Tree := .split 5 q10Shape17T284 q10Shape17T287
private theorem q10Shape17T283OK : fastTreeOK (forms 17) 167772160 100434960 q10Shape17T283=true := by
  change (fastTreeOK (forms 17) 167772160 (100434960 ||| 2^5) q10Shape17T284 &&
    fastTreeOK (forms 17) (167772160 ||| 2^5) 100434960 q10Shape17T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T284OK,q10Shape17T287OK⟩

private def q10Shape17T267 : Tree := .split 27 q10Shape17T268 q10Shape17T283
private theorem q10Shape17T267OK : fastTreeOK (forms 17) 33554432 100434960 q10Shape17T267=true := by
  change (fastTreeOK (forms 17) 33554432 (100434960 ||| 2^27) q10Shape17T268 &&
    fastTreeOK (forms 17) (33554432 ||| 2^27) 100434960 q10Shape17T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T268OK,q10Shape17T283OK⟩

private def q10Shape17T292 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T292OK : fastTreeOK (forms 17) 33587200 100402192 q10Shape17T292=true := by decide

private def q10Shape17T266 : Tree := .split 15 q10Shape17T267 q10Shape17T292
private theorem q10Shape17T266OK : fastTreeOK (forms 17) 33554432 100402192 q10Shape17T266=true := by
  change (fastTreeOK (forms 17) 33554432 (100402192 ||| 2^15) q10Shape17T267 &&
    fastTreeOK (forms 17) (33554432 ||| 2^15) 100402192 q10Shape17T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T267OK,q10Shape17T292OK⟩

private def q10Shape17T293 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T293OK : fastTreeOK (forms 17) 33555456 100401168 q10Shape17T293=true := by decide

private def q10Shape17T265 : Tree := .split 10 q10Shape17T266 q10Shape17T293
private theorem q10Shape17T265OK : fastTreeOK (forms 17) 33554432 100401168 q10Shape17T265=true := by
  change (fastTreeOK (forms 17) 33554432 (100401168 ||| 2^10) q10Shape17T266 &&
    fastTreeOK (forms 17) (33554432 ||| 2^10) 100401168 q10Shape17T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T266OK,q10Shape17T293OK⟩

private def q10Shape17T294 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape17T294OK : fastTreeOK (forms 17) 33554448 100401152 q10Shape17T294=true := by decide

private def q10Shape17T264 : Tree := .split 4 q10Shape17T265 q10Shape17T294
private theorem q10Shape17T264OK : fastTreeOK (forms 17) 33554432 100401152 q10Shape17T264=true := by
  change (fastTreeOK (forms 17) 33554432 (100401152 ||| 2^4) q10Shape17T265 &&
    fastTreeOK (forms 17) (33554432 ||| 2^4) 100401152 q10Shape17T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T265OK,q10Shape17T294OK⟩

private def q10Shape17T301 : Tree := (.split 15 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 0 2 6 8 9)))))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 3 4 8 9))) (.split 8 (.split 12 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 1 5 6 7 9)))) (.split 3 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 0 1 2 7 9)))))
private theorem q10Shape17T301OK : fastTreeOK (forms 17) 100663296 167578672 q10Shape17T301=true := by decide

private def q10Shape17T302 : Tree := (.split 15 (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 3 4 8 9))) (.split 13 (.split 17 (.tip (.cover 0 1 2 3 7)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 1 5 6 7 9)))) (.split 3 (.split 13 (.split 14 (.split 17 (.tip (.cover 0 1 2 3 7)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 0 1 2 7 9)))) (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 1 5 6 7 9))))
private theorem q10Shape17T302OK : fastTreeOK (forms 17) 100664320 167577648 q10Shape17T302=true := by decide

private def q10Shape17T300 : Tree := .split 10 q10Shape17T301 q10Shape17T302
private theorem q10Shape17T300OK : fastTreeOK (forms 17) 100663296 167577648 q10Shape17T300=true := by
  change (fastTreeOK (forms 17) 100663296 (167577648 ||| 2^10) q10Shape17T301 &&
    fastTreeOK (forms 17) (100663296 ||| 2^10) 167577648 q10Shape17T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T301OK,q10Shape17T302OK⟩

private def q10Shape17T305 : Tree := (.split 2 (.split 3 (.split 6 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 3 4 8 9))) (.split 6 (.split 9 (.split 14 (.split 8 (.split 12 (.tip (.cover 0 1 4 6 7)) (.tip (.cover 0 2 4 8 9))) (.split 12 (.tip (.cover 1 4 5 6 7)) (.tip (.cover 0 1 3 6 7)))) (.tip (.cover 0 1 3 4 7))) (.tip (.cover 0 1 3 4 7))) (.tip (.cover 0 1 2 5 7)))) (.split 3 (.split 6 (.split 8 (.split 13 (.split 9 (.split 12 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 4 8 9))) (.split 12 (.tip (.cover 1 4 5 6 7)) (.tip (.cover 0 1 3 5 7)))) (.tip (.cover 0 1 3 4 7))) (.tip (.cover 0 1 3 4 7))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape17T305OK : fastTreeOK (forms 17) 100663312 167611424 q10Shape17T305=true := by decide

private def q10Shape17T306 : Tree := (.split 8 (.split 9 (.split 12 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 1 5 6 7 9)))
private theorem q10Shape17T306OK : fastTreeOK (forms 17) 100696080 167578656 q10Shape17T306=true := by decide

private def q10Shape17T304 : Tree := .split 15 q10Shape17T305 q10Shape17T306
private theorem q10Shape17T304OK : fastTreeOK (forms 17) 100663312 167578656 q10Shape17T304=true := by
  change (fastTreeOK (forms 17) 100663312 (167578656 ||| 2^15) q10Shape17T305 &&
    fastTreeOK (forms 17) (100663312 ||| 2^15) 167578656 q10Shape17T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T305OK,q10Shape17T306OK⟩

private def q10Shape17T307 : Tree := (.split 15 (.split 13 (.split 14 (.split 17 (.tip (.cover 0 1 2 3 7)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 1 5 6 7 9))) (.tip (.cover 1 5 6 7 9)))
private theorem q10Shape17T307OK : fastTreeOK (forms 17) 100664336 167577632 q10Shape17T307=true := by decide

private def q10Shape17T303 : Tree := .split 10 q10Shape17T304 q10Shape17T307
private theorem q10Shape17T303OK : fastTreeOK (forms 17) 100663312 167577632 q10Shape17T303=true := by
  change (fastTreeOK (forms 17) 100663312 (167577632 ||| 2^10) q10Shape17T304 &&
    fastTreeOK (forms 17) (100663312 ||| 2^10) 167577632 q10Shape17T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T304OK,q10Shape17T307OK⟩

private def q10Shape17T299 : Tree := .split 4 q10Shape17T300 q10Shape17T303
private theorem q10Shape17T299OK : fastTreeOK (forms 17) 100663296 167577632 q10Shape17T299=true := by
  change (fastTreeOK (forms 17) 100663296 (167577632 ||| 2^4) q10Shape17T300 &&
    fastTreeOK (forms 17) (100663296 ||| 2^4) 167577632 q10Shape17T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T300OK,q10Shape17T303OK⟩

private def q10Shape17T308 : Tree := (.tip (.cover 0 2 3 4 7))
private theorem q10Shape17T308OK : fastTreeOK (forms 17) 100728832 167512096 q10Shape17T308=true := by decide

private def q10Shape17T298 : Tree := .split 16 q10Shape17T299 q10Shape17T308
private theorem q10Shape17T298OK : fastTreeOK (forms 17) 100663296 167512096 q10Shape17T298=true := by
  change (fastTreeOK (forms 17) 100663296 (167512096 ||| 2^16) q10Shape17T299 &&
    fastTreeOK (forms 17) (100663296 ||| 2^16) 167512096 q10Shape17T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T299OK,q10Shape17T308OK⟩

private def q10Shape17T309 : Tree := (.tip (.cover 0 2 3 4 7))
private theorem q10Shape17T309OK : fastTreeOK (forms 17) 100665344 167510048 q10Shape17T309=true := by decide

private def q10Shape17T297 : Tree := .split 11 q10Shape17T298 q10Shape17T309
private theorem q10Shape17T297OK : fastTreeOK (forms 17) 100663296 167510048 q10Shape17T297=true := by
  change (fastTreeOK (forms 17) 100663296 (167510048 ||| 2^11) q10Shape17T298 &&
    fastTreeOK (forms 17) (100663296 ||| 2^11) 167510048 q10Shape17T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T298OK,q10Shape17T309OK⟩

private def q10Shape17T310 : Tree := (.tip (.cover 0 2 3 4 7))
private theorem q10Shape17T310OK : fastTreeOK (forms 17) 100663328 167510016 q10Shape17T310=true := by decide

private def q10Shape17T296 : Tree := .split 5 q10Shape17T297 q10Shape17T310
private theorem q10Shape17T296OK : fastTreeOK (forms 17) 100663296 167510016 q10Shape17T296=true := by
  change (fastTreeOK (forms 17) 100663296 (167510016 ||| 2^5) q10Shape17T297 &&
    fastTreeOK (forms 17) (100663296 ||| 2^5) 167510016 q10Shape17T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T297OK,q10Shape17T310OK⟩

private def q10Shape17T311 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape17T311OK : fastTreeOK (forms 17) 234881024 33292288 q10Shape17T311=true := by decide

private def q10Shape17T295 : Tree := .split 27 q10Shape17T296 q10Shape17T311
private theorem q10Shape17T295OK : fastTreeOK (forms 17) 100663296 33292288 q10Shape17T295=true := by
  change (fastTreeOK (forms 17) 100663296 (33292288 ||| 2^27) q10Shape17T296 &&
    fastTreeOK (forms 17) (100663296 ||| 2^27) 33292288 q10Shape17T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T296OK,q10Shape17T311OK⟩

private def q10Shape17T263 : Tree := .split 26 q10Shape17T264 q10Shape17T295
private theorem q10Shape17T263OK : fastTreeOK (forms 17) 33554432 33292288 q10Shape17T263=true := by
  change (fastTreeOK (forms 17) 33554432 (33292288 ||| 2^26) q10Shape17T264 &&
    fastTreeOK (forms 17) (33554432 ||| 2^26) 33292288 q10Shape17T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T264OK,q10Shape17T295OK⟩

private def q10Shape17T312 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T312OK : fastTreeOK (forms 17) 50331648 16515072 q10Shape17T312=true := by decide

private def q10Shape17T262 : Tree := .split 24 q10Shape17T263 q10Shape17T312
private theorem q10Shape17T262OK : fastTreeOK (forms 17) 33554432 16515072 q10Shape17T262=true := by
  change (fastTreeOK (forms 17) 33554432 (16515072 ||| 2^24) q10Shape17T263 &&
    fastTreeOK (forms 17) (33554432 ||| 2^24) 16515072 q10Shape17T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T263OK,q10Shape17T312OK⟩

private def q10Shape17T313 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape17T313OK : fastTreeOK (forms 17) 35651584 14417920 q10Shape17T313=true := by decide

private def q10Shape17T261 : Tree := .split 21 q10Shape17T262 q10Shape17T313
private theorem q10Shape17T261OK : fastTreeOK (forms 17) 33554432 14417920 q10Shape17T261=true := by
  change (fastTreeOK (forms 17) 33554432 (14417920 ||| 2^21) q10Shape17T262 &&
    fastTreeOK (forms 17) (33554432 ||| 2^21) 14417920 q10Shape17T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T262OK,q10Shape17T313OK⟩

private def q10Shape17T314 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape17T314OK : fastTreeOK (forms 17) 41943040 6029312 q10Shape17T314=true := by decide

private def q10Shape17T260 : Tree := .split 23 q10Shape17T261 q10Shape17T314
private theorem q10Shape17T260OK : fastTreeOK (forms 17) 33554432 6029312 q10Shape17T260=true := by
  change (fastTreeOK (forms 17) 33554432 (6029312 ||| 2^23) q10Shape17T261 &&
    fastTreeOK (forms 17) (33554432 ||| 2^23) 6029312 q10Shape17T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T261OK,q10Shape17T314OK⟩

private def q10Shape17T315 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T315OK : fastTreeOK (forms 17) 37748736 1835008 q10Shape17T315=true := by decide

private def q10Shape17T259 : Tree := .split 22 q10Shape17T260 q10Shape17T315
private theorem q10Shape17T259OK : fastTreeOK (forms 17) 33554432 1835008 q10Shape17T259=true := by
  change (fastTreeOK (forms 17) 33554432 (1835008 ||| 2^22) q10Shape17T260 &&
    fastTreeOK (forms 17) (33554432 ||| 2^22) 1835008 q10Shape17T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T260OK,q10Shape17T315OK⟩

private def q10Shape17T316 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape17T316OK : fastTreeOK (forms 17) 34603008 786432 q10Shape17T316=true := by decide

private def q10Shape17T258 : Tree := .split 20 q10Shape17T259 q10Shape17T316
private theorem q10Shape17T258OK : fastTreeOK (forms 17) 33554432 786432 q10Shape17T258=true := by
  change (fastTreeOK (forms 17) 33554432 (786432 ||| 2^20) q10Shape17T259 &&
    fastTreeOK (forms 17) (33554432 ||| 2^20) 786432 q10Shape17T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T259OK,q10Shape17T316OK⟩

private def q10Shape17T317 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape17T317OK : fastTreeOK (forms 17) 34078720 262144 q10Shape17T317=true := by decide

private def q10Shape17T257 : Tree := .split 19 q10Shape17T258 q10Shape17T317
private theorem q10Shape17T257OK : fastTreeOK (forms 17) 33554432 262144 q10Shape17T257=true := by
  change (fastTreeOK (forms 17) 33554432 (262144 ||| 2^19) q10Shape17T258 &&
    fastTreeOK (forms 17) (33554432 ||| 2^19) 262144 q10Shape17T317)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T258OK,q10Shape17T317OK⟩

private def q10Shape17T318 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape17T318OK : fastTreeOK (forms 17) 33816576 0 q10Shape17T318=true := by decide

private def q10Shape17T256 : Tree := .split 18 q10Shape17T257 q10Shape17T318
private theorem q10Shape17T256OK : fastTreeOK (forms 17) 33554432 0 q10Shape17T256=true := by
  change (fastTreeOK (forms 17) 33554432 (0 ||| 2^18) q10Shape17T257 &&
    fastTreeOK (forms 17) (33554432 ||| 2^18) 0 q10Shape17T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T257OK,q10Shape17T318OK⟩

private def q10Shape17T0 : Tree := .split 25 q10Shape17T1 q10Shape17T256
private theorem q10Shape17T0OK : fastTreeOK (forms 17) 0 0 q10Shape17T0=true := by
  change (fastTreeOK (forms 17) 0 (0 ||| 2^25) q10Shape17T1 &&
    fastTreeOK (forms 17) (0 ||| 2^25) 0 q10Shape17T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape17T1OK,q10Shape17T256OK⟩


theorem q10Shape17_cover (b : Nat→Bool) (H : Ranked (adj (forms 17) b)) :
    ∃ u v w z t,Effective (adj (forms 17) b) (adj (forms 17) b) u v w z t :=
  checked_fastTree (forms 17) b H q10Shape17T0 q10Shape17T0OK

#print axioms q10Shape17_cover
end Graffiti384b.Q10
