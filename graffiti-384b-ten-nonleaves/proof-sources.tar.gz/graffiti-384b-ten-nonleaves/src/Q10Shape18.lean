import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape18T10 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape18T10OK : fastTreeOK (forms 18) 0 264799248 q10Shape18T10=true := by decide

private def q10Shape18T13 : Tree := (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 18 (.split 5 (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 4 7 8 9)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))))) (.tip (.cover 0 1 5 8 9))))
private theorem q10Shape18T13OK : fastTreeOK (forms 18) 524288 264275480 q10Shape18T13=true := by decide

private def q10Shape18T17 : Tree := (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 11 (.tip (.cover 1 4 5 6 9)) (.split 12 (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 0 3 4 7 9))) (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 0 2 3 4 7))))))
private theorem q10Shape18T17OK : fastTreeOK (forms 18) 524800 264553528 q10Shape18T17=true := by decide

private def q10Shape18T18 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.split 16 (.split 17 (.tip (.cover 0 1 3 5 8)) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 3 7 8 9)))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.split 16 (.split 17 (.tip (.cover 0 1 3 5 8)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 1 3 4 5))))) (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.split 16 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 3 4 7)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 2 3 7)))))
private theorem q10Shape18T18OK : fastTreeOK (forms 18) 524832 264553496 q10Shape18T18=true := by decide

private def q10Shape18T16 : Tree := .split 5 q10Shape18T17 q10Shape18T18
private theorem q10Shape18T16OK : fastTreeOK (forms 18) 524800 264553496 q10Shape18T16=true := by
  change (fastTreeOK (forms 18) 524800 (264553496 ||| 2^5) q10Shape18T17 &&
    fastTreeOK (forms 18) (524800 ||| 2^5) 264553496 q10Shape18T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T17OK,q10Shape18T18OK⟩

private def q10Shape18T19 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape18T19OK : fastTreeOK (forms 18) 786944 264291352 q10Shape18T19=true := by decide

private def q10Shape18T15 : Tree := .split 18 q10Shape18T16 q10Shape18T19
private theorem q10Shape18T15OK : fastTreeOK (forms 18) 524800 264291352 q10Shape18T15=true := by
  change (fastTreeOK (forms 18) 524800 (264291352 ||| 2^18) q10Shape18T16 &&
    fastTreeOK (forms 18) (524800 ||| 2^18) 264291352 q10Shape18T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T16OK,q10Shape18T19OK⟩

private def q10Shape18T20 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T20OK : fastTreeOK (forms 18) 541184 264274968 q10Shape18T20=true := by decide

private def q10Shape18T14 : Tree := .split 14 q10Shape18T15 q10Shape18T20
private theorem q10Shape18T14OK : fastTreeOK (forms 18) 524800 264274968 q10Shape18T14=true := by
  change (fastTreeOK (forms 18) 524800 (264274968 ||| 2^14) q10Shape18T15 &&
    fastTreeOK (forms 18) (524800 ||| 2^14) 264274968 q10Shape18T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T15OK,q10Shape18T20OK⟩

private def q10Shape18T12 : Tree := .split 9 q10Shape18T13 q10Shape18T14
private theorem q10Shape18T12OK : fastTreeOK (forms 18) 524288 264274968 q10Shape18T12=true := by
  change (fastTreeOK (forms 18) 524288 (264274968 ||| 2^9) q10Shape18T13 &&
    fastTreeOK (forms 18) (524288 ||| 2^9) 264274968 q10Shape18T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T13OK,q10Shape18T14OK⟩

private def q10Shape18T25 : Tree := (.split 6 (.tip (.cover 1 3 4 5 6)) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 1 4 5 6 9))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 5 8)) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 7 8 9))) (.split 16 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 3 4 7))))))
private theorem q10Shape18T25OK : fastTreeOK (forms 18) 524296 264554032 q10Shape18T25=true := by decide

private def q10Shape18T26 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 0 1 2 5 9)) (.tip (.cover 0 2 4 7 9)))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 4 7 9))))) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 0 1 2 5 9)) (.tip (.cover 0 2 3 4 7)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 5 8)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 1 2 4 5))) (.tip (.cover 0 1 2 3 7)))))
private theorem q10Shape18T26OK : fastTreeOK (forms 18) 524328 264554000 q10Shape18T26=true := by decide

private def q10Shape18T24 : Tree := .split 5 q10Shape18T25 q10Shape18T26
private theorem q10Shape18T24OK : fastTreeOK (forms 18) 524296 264554000 q10Shape18T24=true := by
  change (fastTreeOK (forms 18) 524296 (264554000 ||| 2^5) q10Shape18T25 &&
    fastTreeOK (forms 18) (524296 ||| 2^5) 264554000 q10Shape18T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T25OK,q10Shape18T26OK⟩

private def q10Shape18T27 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape18T27OK : fastTreeOK (forms 18) 786440 264291856 q10Shape18T27=true := by decide

private def q10Shape18T23 : Tree := .split 18 q10Shape18T24 q10Shape18T27
private theorem q10Shape18T23OK : fastTreeOK (forms 18) 524296 264291856 q10Shape18T23=true := by
  change (fastTreeOK (forms 18) 524296 (264291856 ||| 2^18) q10Shape18T24 &&
    fastTreeOK (forms 18) (524296 ||| 2^18) 264291856 q10Shape18T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T24OK,q10Shape18T27OK⟩

private def q10Shape18T28 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T28OK : fastTreeOK (forms 18) 540680 264275472 q10Shape18T28=true := by decide

private def q10Shape18T22 : Tree := .split 14 q10Shape18T23 q10Shape18T28
private theorem q10Shape18T22OK : fastTreeOK (forms 18) 524296 264275472 q10Shape18T22=true := by
  change (fastTreeOK (forms 18) 524296 (264275472 ||| 2^14) q10Shape18T23 &&
    fastTreeOK (forms 18) (524296 ||| 2^14) 264275472 q10Shape18T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T23OK,q10Shape18T28OK⟩

private def q10Shape18T29 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T29OK : fastTreeOK (forms 18) 524808 264274960 q10Shape18T29=true := by decide

private def q10Shape18T21 : Tree := .split 9 q10Shape18T22 q10Shape18T29
private theorem q10Shape18T21OK : fastTreeOK (forms 18) 524296 264274960 q10Shape18T21=true := by
  change (fastTreeOK (forms 18) 524296 (264274960 ||| 2^9) q10Shape18T22 &&
    fastTreeOK (forms 18) (524296 ||| 2^9) 264274960 q10Shape18T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T22OK,q10Shape18T29OK⟩

private def q10Shape18T11 : Tree := .split 3 q10Shape18T12 q10Shape18T21
private theorem q10Shape18T11OK : fastTreeOK (forms 18) 524288 264274960 q10Shape18T11=true := by
  change (fastTreeOK (forms 18) 524288 (264274960 ||| 2^3) q10Shape18T12 &&
    fastTreeOK (forms 18) (524288 ||| 2^3) 264274960 q10Shape18T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T12OK,q10Shape18T21OK⟩

private def q10Shape18T9 : Tree := .split 19 q10Shape18T10 q10Shape18T11
private theorem q10Shape18T9OK : fastTreeOK (forms 18) 0 264274960 q10Shape18T9=true := by
  change (fastTreeOK (forms 18) 0 (264274960 ||| 2^19) q10Shape18T10 &&
    fastTreeOK (forms 18) (0 ||| 2^19) 264274960 q10Shape18T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T10OK,q10Shape18T11OK⟩

private def q10Shape18T33 : Tree := (.split 14 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 5 7 8 9)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape18T33OK : fastTreeOK (forms 18) 32768 264767000 q10Shape18T33=true := by decide

private def q10Shape18T37 : Tree := (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 11 (.tip (.cover 1 4 5 6 9)) (.split 12 (.split 16 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 3 4 9))) (.split 16 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 1 3 4 9))))))
private theorem q10Shape18T37OK : fastTreeOK (forms 18) 33280 265045048 q10Shape18T37=true := by decide

private def q10Shape18T38 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 1 3 4 8))) (.split 17 (.tip (.cover 0 3 5 7 8)) (.tip (.cover 0 1 3 4 8))))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 9))))) (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.split 16 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 5 6 7 8 9)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 3 7)))))
private theorem q10Shape18T38OK : fastTreeOK (forms 18) 33312 265045016 q10Shape18T38=true := by decide

private def q10Shape18T36 : Tree := .split 5 q10Shape18T37 q10Shape18T38
private theorem q10Shape18T36OK : fastTreeOK (forms 18) 33280 265045016 q10Shape18T36=true := by
  change (fastTreeOK (forms 18) 33280 (265045016 ||| 2^5) q10Shape18T37 &&
    fastTreeOK (forms 18) (33280 ||| 2^5) 265045016 q10Shape18T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T37OK,q10Shape18T38OK⟩

private def q10Shape18T39 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T39OK : fastTreeOK (forms 18) 295424 264782872 q10Shape18T39=true := by decide

private def q10Shape18T35 : Tree := .split 18 q10Shape18T36 q10Shape18T39
private theorem q10Shape18T35OK : fastTreeOK (forms 18) 33280 264782872 q10Shape18T35=true := by
  change (fastTreeOK (forms 18) 33280 (264782872 ||| 2^18) q10Shape18T36 &&
    fastTreeOK (forms 18) (33280 ||| 2^18) 264782872 q10Shape18T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T36OK,q10Shape18T39OK⟩

private def q10Shape18T40 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape18T40OK : fastTreeOK (forms 18) 49664 264766488 q10Shape18T40=true := by decide

private def q10Shape18T34 : Tree := .split 14 q10Shape18T35 q10Shape18T40
private theorem q10Shape18T34OK : fastTreeOK (forms 18) 33280 264766488 q10Shape18T34=true := by
  change (fastTreeOK (forms 18) 33280 (264766488 ||| 2^14) q10Shape18T35 &&
    fastTreeOK (forms 18) (33280 ||| 2^14) 264766488 q10Shape18T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T35OK,q10Shape18T40OK⟩

private def q10Shape18T32 : Tree := .split 9 q10Shape18T33 q10Shape18T34
private theorem q10Shape18T32OK : fastTreeOK (forms 18) 32768 264766488 q10Shape18T32=true := by
  change (fastTreeOK (forms 18) 32768 (264766488 ||| 2^9) q10Shape18T33 &&
    fastTreeOK (forms 18) (32768 ||| 2^9) 264766488 q10Shape18T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T33OK,q10Shape18T34OK⟩

private def q10Shape18T45 : Tree := (.split 6 (.tip (.cover 1 3 4 5 6)) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 1 4 5 6 9))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 1 2 4 8))) (.split 17 (.tip (.cover 0 2 5 7 8)) (.tip (.cover 0 1 2 4 8)))) (.split 16 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 5 6 7 8 9))))))
private theorem q10Shape18T45OK : fastTreeOK (forms 18) 32776 265045552 q10Shape18T45=true := by decide

private def q10Shape18T46 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 0 2 5 7 9)) (.tip (.cover 0 1 2 4 9)))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 0 1 2 4 9))))) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 1 2 4 9)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 1 2 4 8))) (.tip (.cover 0 1 2 4 9))) (.tip (.cover 0 1 2 3 7)))))
private theorem q10Shape18T46OK : fastTreeOK (forms 18) 32808 265045520 q10Shape18T46=true := by decide

private def q10Shape18T44 : Tree := .split 5 q10Shape18T45 q10Shape18T46
private theorem q10Shape18T44OK : fastTreeOK (forms 18) 32776 265045520 q10Shape18T44=true := by
  change (fastTreeOK (forms 18) 32776 (265045520 ||| 2^5) q10Shape18T45 &&
    fastTreeOK (forms 18) (32776 ||| 2^5) 265045520 q10Shape18T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T45OK,q10Shape18T46OK⟩

private def q10Shape18T47 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T47OK : fastTreeOK (forms 18) 294920 264783376 q10Shape18T47=true := by decide

private def q10Shape18T43 : Tree := .split 18 q10Shape18T44 q10Shape18T47
private theorem q10Shape18T43OK : fastTreeOK (forms 18) 32776 264783376 q10Shape18T43=true := by
  change (fastTreeOK (forms 18) 32776 (264783376 ||| 2^18) q10Shape18T44 &&
    fastTreeOK (forms 18) (32776 ||| 2^18) 264783376 q10Shape18T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T44OK,q10Shape18T47OK⟩

private def q10Shape18T48 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape18T48OK : fastTreeOK (forms 18) 49160 264766992 q10Shape18T48=true := by decide

private def q10Shape18T42 : Tree := .split 14 q10Shape18T43 q10Shape18T48
private theorem q10Shape18T42OK : fastTreeOK (forms 18) 32776 264766992 q10Shape18T42=true := by
  change (fastTreeOK (forms 18) 32776 (264766992 ||| 2^14) q10Shape18T43 &&
    fastTreeOK (forms 18) (32776 ||| 2^14) 264766992 q10Shape18T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T43OK,q10Shape18T48OK⟩

private def q10Shape18T49 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T49OK : fastTreeOK (forms 18) 33288 264766480 q10Shape18T49=true := by decide

private def q10Shape18T41 : Tree := .split 9 q10Shape18T42 q10Shape18T49
private theorem q10Shape18T41OK : fastTreeOK (forms 18) 32776 264766480 q10Shape18T41=true := by
  change (fastTreeOK (forms 18) 32776 (264766480 ||| 2^9) q10Shape18T42 &&
    fastTreeOK (forms 18) (32776 ||| 2^9) 264766480 q10Shape18T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T42OK,q10Shape18T49OK⟩

private def q10Shape18T31 : Tree := .split 3 q10Shape18T32 q10Shape18T41
private theorem q10Shape18T31OK : fastTreeOK (forms 18) 32768 264766480 q10Shape18T31=true := by
  change (fastTreeOK (forms 18) 32768 (264766480 ||| 2^3) q10Shape18T32 &&
    fastTreeOK (forms 18) (32768 ||| 2^3) 264766480 q10Shape18T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T32OK,q10Shape18T41OK⟩

private def q10Shape18T50 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape18T50OK : fastTreeOK (forms 18) 557056 264242192 q10Shape18T50=true := by decide

private def q10Shape18T30 : Tree := .split 19 q10Shape18T31 q10Shape18T50
private theorem q10Shape18T30OK : fastTreeOK (forms 18) 32768 264242192 q10Shape18T30=true := by
  change (fastTreeOK (forms 18) 32768 (264242192 ||| 2^19) q10Shape18T31 &&
    fastTreeOK (forms 18) (32768 ||| 2^19) 264242192 q10Shape18T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T31OK,q10Shape18T50OK⟩

private def q10Shape18T8 : Tree := .split 15 q10Shape18T9 q10Shape18T30
private theorem q10Shape18T8OK : fastTreeOK (forms 18) 0 264242192 q10Shape18T8=true := by
  change (fastTreeOK (forms 18) 0 (264242192 ||| 2^15) q10Shape18T9 &&
    fastTreeOK (forms 18) (0 ||| 2^15) 264242192 q10Shape18T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T9OK,q10Shape18T30OK⟩

private def q10Shape18T57 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape18T57OK : fastTreeOK (forms 18) 1024 265077272 q10Shape18T57=true := by decide

private def q10Shape18T59 : Tree := (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 11 (.tip (.cover 0 4 5 7 9)) (.split 12 (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 0 5 7 8 9))) (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 0 5 7 8 9))))))
private theorem q10Shape18T59OK : fastTreeOK (forms 18) 263168 264815160 q10Shape18T59=true := by decide

private def q10Shape18T60 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.split 16 (.split 17 (.tip (.cover 0 1 3 5 8)) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 16 (.split 17 (.tip (.cover 0 1 3 5 8)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 1 3 4 5))))) (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.split 16 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 1 2 3 6)))))
private theorem q10Shape18T60OK : fastTreeOK (forms 18) 263200 264815128 q10Shape18T60=true := by decide

private def q10Shape18T58 : Tree := .split 5 q10Shape18T59 q10Shape18T60
private theorem q10Shape18T58OK : fastTreeOK (forms 18) 263168 264815128 q10Shape18T58=true := by
  change (fastTreeOK (forms 18) 263168 (264815128 ||| 2^5) q10Shape18T59 &&
    fastTreeOK (forms 18) (263168 ||| 2^5) 264815128 q10Shape18T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T59OK,q10Shape18T60OK⟩

private def q10Shape18T56 : Tree := .split 18 q10Shape18T57 q10Shape18T58
private theorem q10Shape18T56OK : fastTreeOK (forms 18) 1024 264815128 q10Shape18T56=true := by
  change (fastTreeOK (forms 18) 1024 (264815128 ||| 2^18) q10Shape18T57 &&
    fastTreeOK (forms 18) (1024 ||| 2^18) 264815128 q10Shape18T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T57OK,q10Shape18T58OK⟩

private def q10Shape18T63 : Tree := (.split 6 (.tip (.cover 0 1 3 4 5)) (.split 11 (.tip (.cover 0 4 5 7 9)) (.split 12 (.split 16 (.tip (.cover 1 3 5 6 9)) (.tip (.cover 0 1 3 4 9))) (.split 16 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 3 4 9))))))
private theorem q10Shape18T63OK : fastTreeOK (forms 18) 17408 265060920 q10Shape18T63=true := by decide

private def q10Shape18T64 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 3 4 8))) (.split 17 (.tip (.cover 1 3 5 6 8)) (.tip (.cover 0 1 3 4 8))))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 9))))) (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.split 16 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 5 6 7 8 9)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 0 1 3 4 9))) (.tip (.cover 0 1 2 3 6)))))
private theorem q10Shape18T64OK : fastTreeOK (forms 18) 17440 265060888 q10Shape18T64=true := by decide

private def q10Shape18T62 : Tree := .split 5 q10Shape18T63 q10Shape18T64
private theorem q10Shape18T62OK : fastTreeOK (forms 18) 17408 265060888 q10Shape18T62=true := by
  change (fastTreeOK (forms 18) 17408 (265060888 ||| 2^5) q10Shape18T63 &&
    fastTreeOK (forms 18) (17408 ||| 2^5) 265060888 q10Shape18T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T63OK,q10Shape18T64OK⟩

private def q10Shape18T65 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T65OK : fastTreeOK (forms 18) 279552 264798744 q10Shape18T65=true := by decide

private def q10Shape18T61 : Tree := .split 18 q10Shape18T62 q10Shape18T65
private theorem q10Shape18T61OK : fastTreeOK (forms 18) 17408 264798744 q10Shape18T61=true := by
  change (fastTreeOK (forms 18) 17408 (264798744 ||| 2^18) q10Shape18T62 &&
    fastTreeOK (forms 18) (17408 ||| 2^18) 264798744 q10Shape18T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T62OK,q10Shape18T65OK⟩

private def q10Shape18T55 : Tree := .split 14 q10Shape18T56 q10Shape18T61
private theorem q10Shape18T55OK : fastTreeOK (forms 18) 1024 264798744 q10Shape18T55=true := by
  change (fastTreeOK (forms 18) 1024 (264798744 ||| 2^14) q10Shape18T56 &&
    fastTreeOK (forms 18) (1024 ||| 2^14) 264798744 q10Shape18T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T56OK,q10Shape18T61OK⟩

private def q10Shape18T66 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape18T66OK : fastTreeOK (forms 18) 1536 264798232 q10Shape18T66=true := by decide

private def q10Shape18T54 : Tree := .split 9 q10Shape18T55 q10Shape18T66
private theorem q10Shape18T54OK : fastTreeOK (forms 18) 1024 264798232 q10Shape18T54=true := by
  change (fastTreeOK (forms 18) 1024 (264798232 ||| 2^9) q10Shape18T55 &&
    fastTreeOK (forms 18) (1024 ||| 2^9) 264798232 q10Shape18T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T55OK,q10Shape18T66OK⟩

private def q10Shape18T67 : Tree := (.split 9 (.split 14 (.split 18 (.split 5 (.split 6 (.tip (.cover 1 3 4 5 6)) (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.tip (.cover 0 1 2 3 8))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 1 3 5 6 9))) (.split 17 (.tip (.cover 0 2 5 7 8)) (.tip (.cover 5 6 7 8 9)))) (.tip (.cover 0 1 2 3 8))))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 2 5 7 9))) (.split 17 (.tip (.cover 1 3 5 6 8)) (.tip (.cover 5 6 7 8 9))))) (.tip (.cover 0 1 2 3 9))) (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 9))))) (.tip (.cover 2 3 4 5 7))) (.tip (.cover 2 3 4 5 7))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape18T67OK : fastTreeOK (forms 18) 1032 264798224 q10Shape18T67=true := by decide

private def q10Shape18T53 : Tree := .split 3 q10Shape18T54 q10Shape18T67
private theorem q10Shape18T53OK : fastTreeOK (forms 18) 1024 264798224 q10Shape18T53=true := by
  change (fastTreeOK (forms 18) 1024 (264798224 ||| 2^3) q10Shape18T54 &&
    fastTreeOK (forms 18) (1024 ||| 2^3) 264798224 q10Shape18T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T54OK,q10Shape18T67OK⟩

private def q10Shape18T68 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape18T68OK : fastTreeOK (forms 18) 525312 264273936 q10Shape18T68=true := by decide

private def q10Shape18T52 : Tree := .split 19 q10Shape18T53 q10Shape18T68
private theorem q10Shape18T52OK : fastTreeOK (forms 18) 1024 264273936 q10Shape18T52=true := by
  change (fastTreeOK (forms 18) 1024 (264273936 ||| 2^19) q10Shape18T53 &&
    fastTreeOK (forms 18) (1024 ||| 2^19) 264273936 q10Shape18T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T53OK,q10Shape18T68OK⟩

private def q10Shape18T69 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape18T69OK : fastTreeOK (forms 18) 33792 264241168 q10Shape18T69=true := by decide

private def q10Shape18T51 : Tree := .split 15 q10Shape18T52 q10Shape18T69
private theorem q10Shape18T51OK : fastTreeOK (forms 18) 1024 264241168 q10Shape18T51=true := by
  change (fastTreeOK (forms 18) 1024 (264241168 ||| 2^15) q10Shape18T52 &&
    fastTreeOK (forms 18) (1024 ||| 2^15) 264241168 q10Shape18T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T52OK,q10Shape18T69OK⟩

private def q10Shape18T7 : Tree := .split 10 q10Shape18T8 q10Shape18T51
private theorem q10Shape18T7OK : fastTreeOK (forms 18) 0 264241168 q10Shape18T7=true := by
  change (fastTreeOK (forms 18) 0 (264241168 ||| 2^10) q10Shape18T8 &&
    fastTreeOK (forms 18) (0 ||| 2^10) 264241168 q10Shape18T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T8OK,q10Shape18T51OK⟩

private def q10Shape18T77 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape18T77OK : fastTreeOK (forms 18) 16 265078280 q10Shape18T77=true := by decide

private def q10Shape18T79 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 7 9))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 5 8)) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 5 7 8 9))) (.split 16 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 5 7 8 9))))))
private theorem q10Shape18T79OK : fastTreeOK (forms 18) 262160 264816168 q10Shape18T79=true := by decide

private def q10Shape18T80 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 0 1 2 5 9)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 3 4 5 7))))) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 0 1 2 5 9)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 5 8)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 1 2 4 5))) (.tip (.cover 0 1 2 3 6)))))
private theorem q10Shape18T80OK : fastTreeOK (forms 18) 262192 264816136 q10Shape18T80=true := by decide

private def q10Shape18T78 : Tree := .split 5 q10Shape18T79 q10Shape18T80
private theorem q10Shape18T78OK : fastTreeOK (forms 18) 262160 264816136 q10Shape18T78=true := by
  change (fastTreeOK (forms 18) 262160 (264816136 ||| 2^5) q10Shape18T79 &&
    fastTreeOK (forms 18) (262160 ||| 2^5) 264816136 q10Shape18T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T79OK,q10Shape18T80OK⟩

private def q10Shape18T76 : Tree := .split 18 q10Shape18T77 q10Shape18T78
private theorem q10Shape18T76OK : fastTreeOK (forms 18) 16 264816136 q10Shape18T76=true := by
  change (fastTreeOK (forms 18) 16 (264816136 ||| 2^18) q10Shape18T77 &&
    fastTreeOK (forms 18) (16 ||| 2^18) 264816136 q10Shape18T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T77OK,q10Shape18T78OK⟩

private def q10Shape18T83 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 7 9))) (.split 12 (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 2 4 8))) (.split 17 (.tip (.cover 1 2 5 6 8)) (.tip (.cover 0 1 2 4 8)))) (.split 16 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 5 6 7 8 9))))))
private theorem q10Shape18T83OK : fastTreeOK (forms 18) 16400 265061928 q10Shape18T83=true := by decide

private def q10Shape18T84 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 1 2 5 6 9)) (.tip (.cover 0 1 2 4 9)))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 0 1 2 4 9))))) (.split 11 (.split 12 (.tip (.cover 0 1 2 4 5)) (.split 16 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 2 4 9)))) (.split 12 (.split 16 (.split 17 (.tip (.cover 1 2 3 5 6)) (.tip (.cover 0 1 2 4 8))) (.tip (.cover 0 1 2 4 9))) (.tip (.cover 0 1 2 3 6)))))
private theorem q10Shape18T84OK : fastTreeOK (forms 18) 16432 265061896 q10Shape18T84=true := by decide

private def q10Shape18T82 : Tree := .split 5 q10Shape18T83 q10Shape18T84
private theorem q10Shape18T82OK : fastTreeOK (forms 18) 16400 265061896 q10Shape18T82=true := by
  change (fastTreeOK (forms 18) 16400 (265061896 ||| 2^5) q10Shape18T83 &&
    fastTreeOK (forms 18) (16400 ||| 2^5) 265061896 q10Shape18T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T83OK,q10Shape18T84OK⟩

private def q10Shape18T85 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape18T85OK : fastTreeOK (forms 18) 278544 264799752 q10Shape18T85=true := by decide

private def q10Shape18T81 : Tree := .split 18 q10Shape18T82 q10Shape18T85
private theorem q10Shape18T81OK : fastTreeOK (forms 18) 16400 264799752 q10Shape18T81=true := by
  change (fastTreeOK (forms 18) 16400 (264799752 ||| 2^18) q10Shape18T82 &&
    fastTreeOK (forms 18) (16400 ||| 2^18) 264799752 q10Shape18T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T82OK,q10Shape18T85OK⟩

private def q10Shape18T75 : Tree := .split 14 q10Shape18T76 q10Shape18T81
private theorem q10Shape18T75OK : fastTreeOK (forms 18) 16 264799752 q10Shape18T75=true := by
  change (fastTreeOK (forms 18) 16 (264799752 ||| 2^14) q10Shape18T76 &&
    fastTreeOK (forms 18) (16 ||| 2^14) 264799752 q10Shape18T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T76OK,q10Shape18T81OK⟩

private def q10Shape18T86 : Tree := (.split 14 (.split 18 (.split 5 (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 8))) (.split 12 (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 0 3 5 7 9))) (.split 17 (.tip (.cover 1 2 5 6 8)) (.tip (.cover 5 6 7 8 9)))) (.tip (.cover 0 1 2 3 8))))) (.split 6 (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.split 16 (.split 17 (.tip (.cover 0 1 2 3 5)) (.tip (.cover 1 2 5 6 9))) (.split 17 (.tip (.cover 0 3 5 7 8)) (.tip (.cover 5 6 7 8 9))))) (.tip (.cover 0 1 2 3 9))) (.split 11 (.split 12 (.tip (.cover 1 2 4 5 6)) (.tip (.cover 0 1 2 3 8))) (.tip (.cover 0 1 2 3 9))))) (.tip (.cover 2 3 4 5 7))) (.tip (.cover 2 3 4 5 7)))
private theorem q10Shape18T86OK : fastTreeOK (forms 18) 528 264799240 q10Shape18T86=true := by decide

private def q10Shape18T74 : Tree := .split 9 q10Shape18T75 q10Shape18T86
private theorem q10Shape18T74OK : fastTreeOK (forms 18) 16 264799240 q10Shape18T74=true := by
  change (fastTreeOK (forms 18) 16 (264799240 ||| 2^9) q10Shape18T75 &&
    fastTreeOK (forms 18) (16 ||| 2^9) 264799240 q10Shape18T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T75OK,q10Shape18T86OK⟩

private def q10Shape18T87 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape18T87OK : fastTreeOK (forms 18) 24 264799232 q10Shape18T87=true := by decide

private def q10Shape18T73 : Tree := .split 3 q10Shape18T74 q10Shape18T87
private theorem q10Shape18T73OK : fastTreeOK (forms 18) 16 264799232 q10Shape18T73=true := by
  change (fastTreeOK (forms 18) 16 (264799232 ||| 2^3) q10Shape18T74 &&
    fastTreeOK (forms 18) (16 ||| 2^3) 264799232 q10Shape18T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T74OK,q10Shape18T87OK⟩

private def q10Shape18T88 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape18T88OK : fastTreeOK (forms 18) 524304 264274944 q10Shape18T88=true := by decide

private def q10Shape18T72 : Tree := .split 19 q10Shape18T73 q10Shape18T88
private theorem q10Shape18T72OK : fastTreeOK (forms 18) 16 264274944 q10Shape18T72=true := by
  change (fastTreeOK (forms 18) 16 (264274944 ||| 2^19) q10Shape18T73 &&
    fastTreeOK (forms 18) (16 ||| 2^19) 264274944 q10Shape18T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T73OK,q10Shape18T88OK⟩

private def q10Shape18T89 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape18T89OK : fastTreeOK (forms 18) 32784 264242176 q10Shape18T89=true := by decide

private def q10Shape18T71 : Tree := .split 15 q10Shape18T72 q10Shape18T89
private theorem q10Shape18T71OK : fastTreeOK (forms 18) 16 264242176 q10Shape18T71=true := by
  change (fastTreeOK (forms 18) 16 (264242176 ||| 2^15) q10Shape18T72 &&
    fastTreeOK (forms 18) (16 ||| 2^15) 264242176 q10Shape18T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T72OK,q10Shape18T89OK⟩

private def q10Shape18T90 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape18T90OK : fastTreeOK (forms 18) 1040 264241152 q10Shape18T90=true := by decide

private def q10Shape18T70 : Tree := .split 10 q10Shape18T71 q10Shape18T90
private theorem q10Shape18T70OK : fastTreeOK (forms 18) 16 264241152 q10Shape18T70=true := by
  change (fastTreeOK (forms 18) 16 (264241152 ||| 2^10) q10Shape18T71 &&
    fastTreeOK (forms 18) (16 ||| 2^10) 264241152 q10Shape18T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T71OK,q10Shape18T90OK⟩

private def q10Shape18T6 : Tree := .split 4 q10Shape18T7 q10Shape18T70
private theorem q10Shape18T6OK : fastTreeOK (forms 18) 0 264241152 q10Shape18T6=true := by
  change (fastTreeOK (forms 18) 0 (264241152 ||| 2^4) q10Shape18T7 &&
    fastTreeOK (forms 18) (0 ||| 2^4) 264241152 q10Shape18T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T7OK,q10Shape18T70OK⟩

private def q10Shape18T95 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape18T95OK : fastTreeOK (forms 18) 134217728 130581520 q10Shape18T95=true := by decide

private def q10Shape18T99 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape18T99OK : fastTreeOK (forms 18) 134742016 130074136 q10Shape18T99=true := by decide

private def q10Shape18T100 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 12 (.tip (.cover 0 1 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))))) (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 2 4 7 8)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 4 7 8 9))) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 2 4 7 8))))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape18T100OK : fastTreeOK (forms 18) 134758400 130057752 q10Shape18T100=true := by decide

private def q10Shape18T98 : Tree := .split 14 q10Shape18T99 q10Shape18T100
private theorem q10Shape18T98OK : fastTreeOK (forms 18) 134742016 130057752 q10Shape18T98=true := by
  change (fastTreeOK (forms 18) 134742016 (130057752 ||| 2^14) q10Shape18T99 &&
    fastTreeOK (forms 18) (134742016 ||| 2^14) 130057752 q10Shape18T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T99OK,q10Shape18T100OK⟩

private def q10Shape18T102 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 17 (.tip (.cover 0 1 5 6 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.split 11 (.tip (.cover 1 4 5 6 9)) (.tip (.cover 0 1 3 7 9)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 1 4 5 6 8)) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape18T102OK : fastTreeOK (forms 18) 134742528 130073624 q10Shape18T102=true := by decide

private def q10Shape18T103 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 6 7 8))) (.tip (.cover 0 2 6 7 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape18T103OK : fastTreeOK (forms 18) 134758912 130057240 q10Shape18T103=true := by decide

private def q10Shape18T101 : Tree := .split 14 q10Shape18T102 q10Shape18T103
private theorem q10Shape18T101OK : fastTreeOK (forms 18) 134742528 130057240 q10Shape18T101=true := by
  change (fastTreeOK (forms 18) 134742528 (130057240 ||| 2^14) q10Shape18T102 &&
    fastTreeOK (forms 18) (134742528 ||| 2^14) 130057240 q10Shape18T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T102OK,q10Shape18T103OK⟩

private def q10Shape18T97 : Tree := .split 9 q10Shape18T98 q10Shape18T101
private theorem q10Shape18T97OK : fastTreeOK (forms 18) 134742016 130057240 q10Shape18T97=true := by
  change (fastTreeOK (forms 18) 134742016 (130057240 ||| 2^9) q10Shape18T98 &&
    fastTreeOK (forms 18) (134742016 ||| 2^9) 130057240 q10Shape18T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T98OK,q10Shape18T101OK⟩

private def q10Shape18T105 : Tree := (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 17 (.tip (.cover 0 1 5 6 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))))) (.tip (.cover 1 4 5 6 9))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 6 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9))))
private theorem q10Shape18T105OK : fastTreeOK (forms 18) 134742024 130057744 q10Shape18T105=true := by decide

private def q10Shape18T106 : Tree := (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 1 4 5 6 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape18T106OK : fastTreeOK (forms 18) 134742536 130057232 q10Shape18T106=true := by decide

private def q10Shape18T104 : Tree := .split 9 q10Shape18T105 q10Shape18T106
private theorem q10Shape18T104OK : fastTreeOK (forms 18) 134742024 130057232 q10Shape18T104=true := by
  change (fastTreeOK (forms 18) 134742024 (130057232 ||| 2^9) q10Shape18T105 &&
    fastTreeOK (forms 18) (134742024 ||| 2^9) 130057232 q10Shape18T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T105OK,q10Shape18T106OK⟩

private def q10Shape18T96 : Tree := .split 3 q10Shape18T97 q10Shape18T104
private theorem q10Shape18T96OK : fastTreeOK (forms 18) 134742016 130057232 q10Shape18T96=true := by
  change (fastTreeOK (forms 18) 134742016 (130057232 ||| 2^3) q10Shape18T97 &&
    fastTreeOK (forms 18) (134742016 ||| 2^3) 130057232 q10Shape18T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T97OK,q10Shape18T104OK⟩

private def q10Shape18T94 : Tree := .split 19 q10Shape18T95 q10Shape18T96
private theorem q10Shape18T94OK : fastTreeOK (forms 18) 134217728 130057232 q10Shape18T94=true := by
  change (fastTreeOK (forms 18) 134217728 (130057232 ||| 2^19) q10Shape18T95 &&
    fastTreeOK (forms 18) (134217728 ||| 2^19) 130057232 q10Shape18T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T95OK,q10Shape18T96OK⟩

private def q10Shape18T111 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 12 (.tip (.cover 0 1 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))))) (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 2 5 7 8)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 5 7 8 9))) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 2 5 7 8))))))
private theorem q10Shape18T111OK : fastTreeOK (forms 18) 134250496 130565656 q10Shape18T111=true := by decide

private def q10Shape18T112 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape18T112OK : fastTreeOK (forms 18) 134266880 130549272 q10Shape18T112=true := by decide

private def q10Shape18T110 : Tree := .split 14 q10Shape18T111 q10Shape18T112
private theorem q10Shape18T110OK : fastTreeOK (forms 18) 134250496 130549272 q10Shape18T110=true := by
  change (fastTreeOK (forms 18) 134250496 (130549272 ||| 2^14) q10Shape18T111 &&
    fastTreeOK (forms 18) (134250496 ||| 2^14) 130549272 q10Shape18T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T111OK,q10Shape18T112OK⟩

private def q10Shape18T115 : Tree := (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.split 11 (.tip (.cover 1 4 5 6 9)) (.tip (.cover 0 1 3 7 9)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 1 4 5 6 8)) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9)))))
private theorem q10Shape18T115OK : fastTreeOK (forms 18) 134251008 130827288 q10Shape18T115=true := by decide

private def q10Shape18T116 : Tree := (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 6 7 8))) (.tip (.cover 0 2 6 7 9)))
private theorem q10Shape18T116OK : fastTreeOK (forms 18) 134513152 130565144 q10Shape18T116=true := by decide

private def q10Shape18T114 : Tree := .split 18 q10Shape18T115 q10Shape18T116
private theorem q10Shape18T114OK : fastTreeOK (forms 18) 134251008 130565144 q10Shape18T114=true := by
  change (fastTreeOK (forms 18) 134251008 (130565144 ||| 2^18) q10Shape18T115 &&
    fastTreeOK (forms 18) (134251008 ||| 2^18) 130565144 q10Shape18T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T115OK,q10Shape18T116OK⟩

private def q10Shape18T117 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape18T117OK : fastTreeOK (forms 18) 134267392 130548760 q10Shape18T117=true := by decide

private def q10Shape18T113 : Tree := .split 14 q10Shape18T114 q10Shape18T117
private theorem q10Shape18T113OK : fastTreeOK (forms 18) 134251008 130548760 q10Shape18T113=true := by
  change (fastTreeOK (forms 18) 134251008 (130548760 ||| 2^14) q10Shape18T114 &&
    fastTreeOK (forms 18) (134251008 ||| 2^14) 130548760 q10Shape18T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T114OK,q10Shape18T117OK⟩

private def q10Shape18T109 : Tree := .split 9 q10Shape18T110 q10Shape18T113
private theorem q10Shape18T109OK : fastTreeOK (forms 18) 134250496 130548760 q10Shape18T109=true := by
  change (fastTreeOK (forms 18) 134250496 (130548760 ||| 2^9) q10Shape18T110 &&
    fastTreeOK (forms 18) (134250496 ||| 2^9) 130548760 q10Shape18T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T110OK,q10Shape18T113OK⟩

private def q10Shape18T119 : Tree := (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 1 4 5 6 9))) (.split 12 (.tip (.cover 1 4 5 6 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 6 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape18T119OK : fastTreeOK (forms 18) 134250504 130549264 q10Shape18T119=true := by decide

private def q10Shape18T120 : Tree := (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 1 4 5 6 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape18T120OK : fastTreeOK (forms 18) 134251016 130548752 q10Shape18T120=true := by decide

private def q10Shape18T118 : Tree := .split 9 q10Shape18T119 q10Shape18T120
private theorem q10Shape18T118OK : fastTreeOK (forms 18) 134250504 130548752 q10Shape18T118=true := by
  change (fastTreeOK (forms 18) 134250504 (130548752 ||| 2^9) q10Shape18T119 &&
    fastTreeOK (forms 18) (134250504 ||| 2^9) 130548752 q10Shape18T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T119OK,q10Shape18T120OK⟩

private def q10Shape18T108 : Tree := .split 3 q10Shape18T109 q10Shape18T118
private theorem q10Shape18T108OK : fastTreeOK (forms 18) 134250496 130548752 q10Shape18T108=true := by
  change (fastTreeOK (forms 18) 134250496 (130548752 ||| 2^3) q10Shape18T109 &&
    fastTreeOK (forms 18) (134250496 ||| 2^3) 130548752 q10Shape18T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T109OK,q10Shape18T118OK⟩

private def q10Shape18T121 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))) (.split 9 (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 2 3 4 5 8))))
private theorem q10Shape18T121OK : fastTreeOK (forms 18) 134774784 130024464 q10Shape18T121=true := by decide

private def q10Shape18T107 : Tree := .split 19 q10Shape18T108 q10Shape18T121
private theorem q10Shape18T107OK : fastTreeOK (forms 18) 134250496 130024464 q10Shape18T107=true := by
  change (fastTreeOK (forms 18) 134250496 (130024464 ||| 2^19) q10Shape18T108 &&
    fastTreeOK (forms 18) (134250496 ||| 2^19) 130024464 q10Shape18T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T108OK,q10Shape18T121OK⟩

private def q10Shape18T93 : Tree := .split 15 q10Shape18T94 q10Shape18T107
private theorem q10Shape18T93OK : fastTreeOK (forms 18) 134217728 130024464 q10Shape18T93=true := by
  change (fastTreeOK (forms 18) 134217728 (130024464 ||| 2^15) q10Shape18T94 &&
    fastTreeOK (forms 18) (134217728 ||| 2^15) 130024464 q10Shape18T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T94OK,q10Shape18T107OK⟩

private def q10Shape18T127 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.split 17 (.tip (.cover 0 1 5 7 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.split 11 (.tip (.cover 0 4 5 7 9)) (.tip (.cover 0 1 3 6 9)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 4 5 7 8)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 2 5 7 8))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))))))
private theorem q10Shape18T127OK : fastTreeOK (forms 18) 134218752 130597400 q10Shape18T127=true := by decide

private def q10Shape18T129 : Tree := (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.split 11 (.tip (.cover 0 4 5 7 9)) (.tip (.cover 0 1 3 6 9)))) (.split 6 (.split 11 (.split 12 (.tip (.cover 0 4 5 7 8)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9)))))
private theorem q10Shape18T129OK : fastTreeOK (forms 18) 134235136 130843160 q10Shape18T129=true := by decide

private def q10Shape18T130 : Tree := (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 6 7 8))) (.tip (.cover 0 2 6 7 9)))
private theorem q10Shape18T130OK : fastTreeOK (forms 18) 134497280 130581016 q10Shape18T130=true := by decide

private def q10Shape18T128 : Tree := .split 18 q10Shape18T129 q10Shape18T130
private theorem q10Shape18T128OK : fastTreeOK (forms 18) 134235136 130581016 q10Shape18T128=true := by
  change (fastTreeOK (forms 18) 134235136 (130581016 ||| 2^18) q10Shape18T129 &&
    fastTreeOK (forms 18) (134235136 ||| 2^18) 130581016 q10Shape18T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T129OK,q10Shape18T130OK⟩

private def q10Shape18T126 : Tree := .split 14 q10Shape18T127 q10Shape18T128
private theorem q10Shape18T126OK : fastTreeOK (forms 18) 134218752 130581016 q10Shape18T126=true := by
  change (fastTreeOK (forms 18) 134218752 (130581016 ||| 2^14) q10Shape18T127 &&
    fastTreeOK (forms 18) (134218752 ||| 2^14) 130581016 q10Shape18T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T127OK,q10Shape18T128OK⟩

private def q10Shape18T131 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape18T131OK : fastTreeOK (forms 18) 134219264 130580504 q10Shape18T131=true := by decide

private def q10Shape18T125 : Tree := .split 9 q10Shape18T126 q10Shape18T131
private theorem q10Shape18T125OK : fastTreeOK (forms 18) 134218752 130580504 q10Shape18T125=true := by
  change (fastTreeOK (forms 18) 134218752 (130580504 ||| 2^9) q10Shape18T126 &&
    fastTreeOK (forms 18) (134218752 ||| 2^9) 130580504 q10Shape18T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T126OK,q10Shape18T131OK⟩

private def q10Shape18T134 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 2 5 7 9))) (.split 17 (.tip (.cover 0 2 5 7 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 2 4 7 8))))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape18T134OK : fastTreeOK (forms 18) 134218760 130597392 q10Shape18T134=true := by decide

private def q10Shape18T135 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 5 6 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape18T135OK : fastTreeOK (forms 18) 134235144 130581008 q10Shape18T135=true := by decide

private def q10Shape18T133 : Tree := .split 14 q10Shape18T134 q10Shape18T135
private theorem q10Shape18T133OK : fastTreeOK (forms 18) 134218760 130581008 q10Shape18T133=true := by
  change (fastTreeOK (forms 18) 134218760 (130581008 ||| 2^14) q10Shape18T134 &&
    fastTreeOK (forms 18) (134218760 ||| 2^14) 130581008 q10Shape18T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T134OK,q10Shape18T135OK⟩

private def q10Shape18T136 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape18T136OK : fastTreeOK (forms 18) 134219272 130580496 q10Shape18T136=true := by decide

private def q10Shape18T132 : Tree := .split 9 q10Shape18T133 q10Shape18T136
private theorem q10Shape18T132OK : fastTreeOK (forms 18) 134218760 130580496 q10Shape18T132=true := by
  change (fastTreeOK (forms 18) 134218760 (130580496 ||| 2^9) q10Shape18T133 &&
    fastTreeOK (forms 18) (134218760 ||| 2^9) 130580496 q10Shape18T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T133OK,q10Shape18T136OK⟩

private def q10Shape18T124 : Tree := .split 3 q10Shape18T125 q10Shape18T132
private theorem q10Shape18T124OK : fastTreeOK (forms 18) 134218752 130580496 q10Shape18T124=true := by
  change (fastTreeOK (forms 18) 134218752 (130580496 ||| 2^3) q10Shape18T125 &&
    fastTreeOK (forms 18) (134218752 ||| 2^3) 130580496 q10Shape18T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T125OK,q10Shape18T132OK⟩

private def q10Shape18T137 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 3 8 9))) (.split 9 (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape18T137OK : fastTreeOK (forms 18) 134743040 130056208 q10Shape18T137=true := by decide

private def q10Shape18T123 : Tree := .split 19 q10Shape18T124 q10Shape18T137
private theorem q10Shape18T123OK : fastTreeOK (forms 18) 134218752 130056208 q10Shape18T123=true := by
  change (fastTreeOK (forms 18) 134218752 (130056208 ||| 2^19) q10Shape18T124 &&
    fastTreeOK (forms 18) (134218752 ||| 2^19) 130056208 q10Shape18T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T124OK,q10Shape18T137OK⟩

private def q10Shape18T138 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 5 7 8))) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.split 9 (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 2 5 7 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9)))) (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 2 7 8 9))))
private theorem q10Shape18T138OK : fastTreeOK (forms 18) 134251520 130023440 q10Shape18T138=true := by decide

private def q10Shape18T122 : Tree := .split 15 q10Shape18T123 q10Shape18T138
private theorem q10Shape18T122OK : fastTreeOK (forms 18) 134218752 130023440 q10Shape18T122=true := by
  change (fastTreeOK (forms 18) 134218752 (130023440 ||| 2^15) q10Shape18T123 &&
    fastTreeOK (forms 18) (134218752 ||| 2^15) 130023440 q10Shape18T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T123OK,q10Shape18T138OK⟩

private def q10Shape18T92 : Tree := .split 10 q10Shape18T93 q10Shape18T122
private theorem q10Shape18T92OK : fastTreeOK (forms 18) 134217728 130023440 q10Shape18T92=true := by
  change (fastTreeOK (forms 18) 134217728 (130023440 ||| 2^10) q10Shape18T93 &&
    fastTreeOK (forms 18) (134217728 ||| 2^10) 130023440 q10Shape18T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T93OK,q10Shape18T122OK⟩

private def q10Shape18T145 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.split 17 (.tip (.cover 0 1 5 7 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))))) (.tip (.cover 0 4 5 7 9))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 3 5 7 8))))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape18T145OK : fastTreeOK (forms 18) 134217744 130598408 q10Shape18T145=true := by decide

private def q10Shape18T146 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 4 5 7 9))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 3 6 7 8))) (.tip (.cover 0 3 6 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape18T146OK : fastTreeOK (forms 18) 134234128 130582024 q10Shape18T146=true := by decide

private def q10Shape18T144 : Tree := .split 14 q10Shape18T145 q10Shape18T146
private theorem q10Shape18T144OK : fastTreeOK (forms 18) 134217744 130582024 q10Shape18T144=true := by
  change (fastTreeOK (forms 18) 134217744 (130582024 ||| 2^14) q10Shape18T145 &&
    fastTreeOK (forms 18) (134217744 ||| 2^14) 130582024 q10Shape18T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T145OK,q10Shape18T146OK⟩

private def q10Shape18T148 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 3 5 7 9))) (.split 17 (.tip (.cover 0 3 5 7 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 7 8))))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape18T148OK : fastTreeOK (forms 18) 134218256 130597896 q10Shape18T148=true := by decide

private def q10Shape18T149 : Tree := (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 5 6 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape18T149OK : fastTreeOK (forms 18) 134234640 130581512 q10Shape18T149=true := by decide

private def q10Shape18T147 : Tree := .split 14 q10Shape18T148 q10Shape18T149
private theorem q10Shape18T147OK : fastTreeOK (forms 18) 134218256 130581512 q10Shape18T147=true := by
  change (fastTreeOK (forms 18) 134218256 (130581512 ||| 2^14) q10Shape18T148 &&
    fastTreeOK (forms 18) (134218256 ||| 2^14) 130581512 q10Shape18T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T148OK,q10Shape18T149OK⟩

private def q10Shape18T143 : Tree := .split 9 q10Shape18T144 q10Shape18T147
private theorem q10Shape18T143OK : fastTreeOK (forms 18) 134217744 130581512 q10Shape18T143=true := by
  change (fastTreeOK (forms 18) 134217744 (130581512 ||| 2^9) q10Shape18T144 &&
    fastTreeOK (forms 18) (134217744 ||| 2^9) 130581512 q10Shape18T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T144OK,q10Shape18T147OK⟩

private def q10Shape18T150 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape18T150OK : fastTreeOK (forms 18) 134217752 130581504 q10Shape18T150=true := by decide

private def q10Shape18T142 : Tree := .split 3 q10Shape18T143 q10Shape18T150
private theorem q10Shape18T142OK : fastTreeOK (forms 18) 134217744 130581504 q10Shape18T142=true := by
  change (fastTreeOK (forms 18) 134217744 (130581504 ||| 2^3) q10Shape18T143 &&
    fastTreeOK (forms 18) (134217744 ||| 2^3) 130581504 q10Shape18T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T143OK,q10Shape18T150OK⟩

private def q10Shape18T151 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9)))) (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 2 3 4 5 8)))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape18T151OK : fastTreeOK (forms 18) 134742032 130057216 q10Shape18T151=true := by decide

private def q10Shape18T141 : Tree := .split 19 q10Shape18T142 q10Shape18T151
private theorem q10Shape18T141OK : fastTreeOK (forms 18) 134217744 130057216 q10Shape18T141=true := by
  change (fastTreeOK (forms 18) 134217744 (130057216 ||| 2^19) q10Shape18T142 &&
    fastTreeOK (forms 18) (134217744 ||| 2^19) 130057216 q10Shape18T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T142OK,q10Shape18T151OK⟩

private def q10Shape18T152 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9)))) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 2 8 9))) (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape18T152OK : fastTreeOK (forms 18) 134250512 130024448 q10Shape18T152=true := by decide

private def q10Shape18T140 : Tree := .split 15 q10Shape18T141 q10Shape18T152
private theorem q10Shape18T140OK : fastTreeOK (forms 18) 134217744 130024448 q10Shape18T140=true := by
  change (fastTreeOK (forms 18) 134217744 (130024448 ||| 2^15) q10Shape18T141 &&
    fastTreeOK (forms 18) (134217744 ||| 2^15) 130024448 q10Shape18T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T141OK,q10Shape18T152OK⟩

private def q10Shape18T154 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 4 5 7 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9)))) (.split 18 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 4 5 7 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 2 3 4 5 8)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))) (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape18T154OK : fastTreeOK (forms 18) 134218768 130056192 q10Shape18T154=true := by decide

private def q10Shape18T155 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.tip (.cover 0 5 7 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape18T155OK : fastTreeOK (forms 18) 134251536 130023424 q10Shape18T155=true := by decide

private def q10Shape18T153 : Tree := .split 15 q10Shape18T154 q10Shape18T155
private theorem q10Shape18T153OK : fastTreeOK (forms 18) 134218768 130023424 q10Shape18T153=true := by
  change (fastTreeOK (forms 18) 134218768 (130023424 ||| 2^15) q10Shape18T154 &&
    fastTreeOK (forms 18) (134218768 ||| 2^15) 130023424 q10Shape18T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T154OK,q10Shape18T155OK⟩

private def q10Shape18T139 : Tree := .split 10 q10Shape18T140 q10Shape18T153
private theorem q10Shape18T139OK : fastTreeOK (forms 18) 134217744 130023424 q10Shape18T139=true := by
  change (fastTreeOK (forms 18) 134217744 (130023424 ||| 2^10) q10Shape18T140 &&
    fastTreeOK (forms 18) (134217744 ||| 2^10) 130023424 q10Shape18T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T140OK,q10Shape18T153OK⟩

private def q10Shape18T91 : Tree := .split 4 q10Shape18T92 q10Shape18T139
private theorem q10Shape18T91OK : fastTreeOK (forms 18) 134217728 130023424 q10Shape18T91=true := by
  change (fastTreeOK (forms 18) 134217728 (130023424 ||| 2^4) q10Shape18T92 &&
    fastTreeOK (forms 18) (134217728 ||| 2^4) 130023424 q10Shape18T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T92OK,q10Shape18T139OK⟩

private def q10Shape18T5 : Tree := .split 27 q10Shape18T6 q10Shape18T91
private theorem q10Shape18T5OK : fastTreeOK (forms 18) 0 130023424 q10Shape18T5=true := by
  change (fastTreeOK (forms 18) 0 (130023424 ||| 2^27) q10Shape18T6 &&
    fastTreeOK (forms 18) (0 ||| 2^27) 130023424 q10Shape18T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T6OK,q10Shape18T91OK⟩

private def q10Shape18T156 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape18T156OK : fastTreeOK (forms 18) 16777216 113246208 q10Shape18T156=true := by decide

private def q10Shape18T4 : Tree := .split 24 q10Shape18T5 q10Shape18T156
private theorem q10Shape18T4OK : fastTreeOK (forms 18) 0 113246208 q10Shape18T4=true := by
  change (fastTreeOK (forms 18) 0 (113246208 ||| 2^24) q10Shape18T5 &&
    fastTreeOK (forms 18) (0 ||| 2^24) 113246208 q10Shape18T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T5OK,q10Shape18T156OK⟩

private def q10Shape18T157 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape18T157OK : fastTreeOK (forms 18) 8388608 104857600 q10Shape18T157=true := by decide

private def q10Shape18T3 : Tree := .split 23 q10Shape18T4 q10Shape18T157
private theorem q10Shape18T3OK : fastTreeOK (forms 18) 0 104857600 q10Shape18T3=true := by
  change (fastTreeOK (forms 18) 0 (104857600 ||| 2^23) q10Shape18T4 &&
    fastTreeOK (forms 18) (0 ||| 2^23) 104857600 q10Shape18T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T4OK,q10Shape18T157OK⟩

private def q10Shape18T158 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape18T158OK : fastTreeOK (forms 18) 67108864 37748736 q10Shape18T158=true := by decide

private def q10Shape18T2 : Tree := .split 26 q10Shape18T3 q10Shape18T158
private theorem q10Shape18T2OK : fastTreeOK (forms 18) 0 37748736 q10Shape18T2=true := by
  change (fastTreeOK (forms 18) 0 (37748736 ||| 2^26) q10Shape18T3 &&
    fastTreeOK (forms 18) (0 ||| 2^26) 37748736 q10Shape18T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T3OK,q10Shape18T158OK⟩

private def q10Shape18T159 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape18T159OK : fastTreeOK (forms 18) 33554432 4194304 q10Shape18T159=true := by decide

private def q10Shape18T1 : Tree := .split 25 q10Shape18T2 q10Shape18T159
private theorem q10Shape18T1OK : fastTreeOK (forms 18) 0 4194304 q10Shape18T1=true := by
  change (fastTreeOK (forms 18) 0 (4194304 ||| 2^25) q10Shape18T2 &&
    fastTreeOK (forms 18) (0 ||| 2^25) 4194304 q10Shape18T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T2OK,q10Shape18T159OK⟩

private def q10Shape18T160 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape18T160OK : fastTreeOK (forms 18) 4194304 0 q10Shape18T160=true := by decide

private def q10Shape18T0 : Tree := .split 22 q10Shape18T1 q10Shape18T160
private theorem q10Shape18T0OK : fastTreeOK (forms 18) 0 0 q10Shape18T0=true := by
  change (fastTreeOK (forms 18) 0 (0 ||| 2^22) q10Shape18T1 &&
    fastTreeOK (forms 18) (0 ||| 2^22) 0 q10Shape18T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape18T1OK,q10Shape18T160OK⟩


theorem q10Shape18_cover (b : Nat→Bool) (H : Ranked (adj (forms 18) b)) :
    ∃ u v w z t,Effective (adj (forms 18) b) (adj (forms 18) b) u v w z t :=
  checked_fastTree (forms 18) b H q10Shape18T0 q10Shape18T0OK

#print axioms q10Shape18_cover
end Graffiti384b.Q10
