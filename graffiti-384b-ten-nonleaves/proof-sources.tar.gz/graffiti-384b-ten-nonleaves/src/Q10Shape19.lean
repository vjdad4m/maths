import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape19T6 : Tree := (.tip (.cover 0 2 3 8 9))
private theorem q10Shape19T6OK : fastTreeOK (forms 19) 0 5038080 q10Shape19T6=true := by decide

private def q10Shape19T7 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 6)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 5 6 8 9))))))) (.split 16 (.split 17 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 6 8))))
private theorem q10Shape19T7OK : fastTreeOK (forms 19) 4194304 843776 q10Shape19T7=true := by decide

private def q10Shape19T5 : Tree := .split 22 q10Shape19T6 q10Shape19T7
private theorem q10Shape19T5OK : fastTreeOK (forms 19) 0 843776 q10Shape19T5=true := by
  change (fastTreeOK (forms 19) 0 (843776 ||| 2^22) q10Shape19T6 &&
    fastTreeOK (forms 19) (0 ||| 2^22) 843776 q10Shape19T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T6OK,q10Shape19T7OK⟩

private def q10Shape19T9 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 6)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 5 6 8 9))))))) (.split 16 (.split 17 (.split 23 (.split 20 (.split 24 (.split 21 (.split 25 (.split 26 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 6 8))))
private theorem q10Shape19T9OK : fastTreeOK (forms 19) 524288 4513792 q10Shape19T9=true := by decide

private def q10Shape19T10 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape19T10OK : fastTreeOK (forms 19) 4718592 319488 q10Shape19T10=true := by decide

private def q10Shape19T8 : Tree := .split 22 q10Shape19T9 q10Shape19T10
private theorem q10Shape19T8OK : fastTreeOK (forms 19) 524288 319488 q10Shape19T8=true := by
  change (fastTreeOK (forms 19) 524288 (319488 ||| 2^22) q10Shape19T9 &&
    fastTreeOK (forms 19) (524288 ||| 2^22) 319488 q10Shape19T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T9OK,q10Shape19T10OK⟩

private def q10Shape19T4 : Tree := .split 19 q10Shape19T5 q10Shape19T8
private theorem q10Shape19T4OK : fastTreeOK (forms 19) 0 319488 q10Shape19T4=true := by
  change (fastTreeOK (forms 19) 0 (319488 ||| 2^19) q10Shape19T5 &&
    fastTreeOK (forms 19) (0 ||| 2^19) 319488 q10Shape19T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T5OK,q10Shape19T8OK⟩

private def q10Shape19T13 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))))))) (.split 16 (.split 17 (.split 25 (.split 20 (.split 23 (.split 26 (.split 21 (.split 24 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 7 8))))
private theorem q10Shape19T13OK : fastTreeOK (forms 19) 262144 4775936 q10Shape19T13=true := by decide

private def q10Shape19T14 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 6)))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape19T14OK : fastTreeOK (forms 19) 4456448 581632 q10Shape19T14=true := by decide

private def q10Shape19T12 : Tree := .split 22 q10Shape19T13 q10Shape19T14
private theorem q10Shape19T12OK : fastTreeOK (forms 19) 262144 581632 q10Shape19T12=true := by
  change (fastTreeOK (forms 19) 262144 (581632 ||| 2^22) q10Shape19T13 &&
    fastTreeOK (forms 19) (262144 ||| 2^22) 581632 q10Shape19T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T13OK,q10Shape19T14OK⟩

private def q10Shape19T15 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape19T15OK : fastTreeOK (forms 19) 786432 57344 q10Shape19T15=true := by decide

private def q10Shape19T11 : Tree := .split 19 q10Shape19T12 q10Shape19T15
private theorem q10Shape19T11OK : fastTreeOK (forms 19) 262144 57344 q10Shape19T11=true := by
  change (fastTreeOK (forms 19) 262144 (57344 ||| 2^19) q10Shape19T12 &&
    fastTreeOK (forms 19) (262144 ||| 2^19) 57344 q10Shape19T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T12OK,q10Shape19T15OK⟩

private def q10Shape19T3 : Tree := .split 18 q10Shape19T4 q10Shape19T11
private theorem q10Shape19T3OK : fastTreeOK (forms 19) 0 57344 q10Shape19T3=true := by
  change (fastTreeOK (forms 19) 0 (57344 ||| 2^18) q10Shape19T4 &&
    fastTreeOK (forms 19) (0 ||| 2^18) 57344 q10Shape19T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T4OK,q10Shape19T11OK⟩

private def q10Shape19T20 : Tree := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.cover 0 2 3 4 6)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 5 6 7 8 9)))))))
private theorem q10Shape19T20OK : fastTreeOK (forms 19) 32768 139223040 q10Shape19T20=true := by decide

private def q10Shape19T21 : Tree := (.split 20 (.split 21 (.split 23 (.split 16 (.split 24 (.split 17 (.split 25 (.split 26 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape19T21OK : fastTreeOK (forms 19) 134250496 5005312 q10Shape19T21=true := by decide

private def q10Shape19T19 : Tree := .split 27 q10Shape19T20 q10Shape19T21
private theorem q10Shape19T19OK : fastTreeOK (forms 19) 32768 5005312 q10Shape19T19=true := by
  change (fastTreeOK (forms 19) 32768 (5005312 ||| 2^27) q10Shape19T20 &&
    fastTreeOK (forms 19) (32768 ||| 2^27) 5005312 q10Shape19T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T20OK,q10Shape19T21OK⟩

private def q10Shape19T22 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 1 5 7 8)))
private theorem q10Shape19T22OK : fastTreeOK (forms 19) 4227072 811008 q10Shape19T22=true := by decide

private def q10Shape19T18 : Tree := .split 22 q10Shape19T19 q10Shape19T22
private theorem q10Shape19T18OK : fastTreeOK (forms 19) 32768 811008 q10Shape19T18=true := by
  change (fastTreeOK (forms 19) 32768 (811008 ||| 2^22) q10Shape19T19 &&
    fastTreeOK (forms 19) (32768 ||| 2^22) 811008 q10Shape19T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T19OK,q10Shape19T22OK⟩

private def q10Shape19T23 : Tree := (.split 22 (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 6 7)))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 7 8 9)))
private theorem q10Shape19T23OK : fastTreeOK (forms 19) 557056 286720 q10Shape19T23=true := by decide

private def q10Shape19T17 : Tree := .split 19 q10Shape19T18 q10Shape19T23
private theorem q10Shape19T17OK : fastTreeOK (forms 19) 32768 286720 q10Shape19T17=true := by
  change (fastTreeOK (forms 19) 32768 (286720 ||| 2^19) q10Shape19T18 &&
    fastTreeOK (forms 19) (32768 ||| 2^19) 286720 q10Shape19T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T18OK,q10Shape19T23OK⟩

private def q10Shape19T24 : Tree := (.split 27 (.split 16 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape19T24OK : fastTreeOK (forms 19) 294912 24576 q10Shape19T24=true := by decide

private def q10Shape19T16 : Tree := .split 18 q10Shape19T17 q10Shape19T24
private theorem q10Shape19T16OK : fastTreeOK (forms 19) 32768 24576 q10Shape19T16=true := by
  change (fastTreeOK (forms 19) 32768 (24576 ||| 2^18) q10Shape19T17 &&
    fastTreeOK (forms 19) (32768 ||| 2^18) 24576 q10Shape19T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T17OK,q10Shape19T24OK⟩

private def q10Shape19T2 : Tree := .split 15 q10Shape19T3 q10Shape19T16
private theorem q10Shape19T2OK : fastTreeOK (forms 19) 0 24576 q10Shape19T2=true := by
  change (fastTreeOK (forms 19) 0 (24576 ||| 2^15) q10Shape19T3 &&
    fastTreeOK (forms 19) (0 ||| 2^15) 24576 q10Shape19T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T3OK,q10Shape19T16OK⟩

private def q10Shape19T30 : Tree := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 5 6 7 8 9)))))))
private theorem q10Shape19T30OK : fastTreeOK (forms 19) 16384 139239424 q10Shape19T30=true := by decide

private def q10Shape19T31 : Tree := (.split 20 (.split 21 (.split 25 (.split 16 (.split 23 (.split 26 (.split 17 (.split 24 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape19T31OK : fastTreeOK (forms 19) 134234112 5021696 q10Shape19T31=true := by decide

private def q10Shape19T29 : Tree := .split 27 q10Shape19T30 q10Shape19T31
private theorem q10Shape19T29OK : fastTreeOK (forms 19) 16384 5021696 q10Shape19T29=true := by
  change (fastTreeOK (forms 19) 16384 (5021696 ||| 2^27) q10Shape19T30 &&
    fastTreeOK (forms 19) (16384 ||| 2^27) 5021696 q10Shape19T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T30OK,q10Shape19T31OK⟩

private def q10Shape19T32 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 5 6)))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape19T32OK : fastTreeOK (forms 19) 4210688 827392 q10Shape19T32=true := by decide

private def q10Shape19T28 : Tree := .split 22 q10Shape19T29 q10Shape19T32
private theorem q10Shape19T28OK : fastTreeOK (forms 19) 16384 827392 q10Shape19T28=true := by
  change (fastTreeOK (forms 19) 16384 (827392 ||| 2^22) q10Shape19T29 &&
    fastTreeOK (forms 19) (16384 ||| 2^22) 827392 q10Shape19T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T29OK,q10Shape19T32OK⟩

private def q10Shape19T33 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape19T33OK : fastTreeOK (forms 19) 540672 303104 q10Shape19T33=true := by decide

private def q10Shape19T27 : Tree := .split 19 q10Shape19T28 q10Shape19T33
private theorem q10Shape19T27OK : fastTreeOK (forms 19) 16384 303104 q10Shape19T27=true := by
  change (fastTreeOK (forms 19) 16384 (303104 ||| 2^19) q10Shape19T28 &&
    fastTreeOK (forms 19) (16384 ||| 2^19) 303104 q10Shape19T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T28OK,q10Shape19T33OK⟩

private def q10Shape19T34 : Tree := (.split 22 (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 6 7)))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape19T34OK : fastTreeOK (forms 19) 278528 40960 q10Shape19T34=true := by decide

private def q10Shape19T26 : Tree := .split 18 q10Shape19T27 q10Shape19T34
private theorem q10Shape19T26OK : fastTreeOK (forms 19) 16384 40960 q10Shape19T26=true := by
  change (fastTreeOK (forms 19) 16384 (40960 ||| 2^18) q10Shape19T27 &&
    fastTreeOK (forms 19) (16384 ||| 2^18) 40960 q10Shape19T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T27OK,q10Shape19T34OK⟩

private def q10Shape19T35 : Tree := (.split 27 (.split 16 (.split 17 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 5)))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 5 8)))
private theorem q10Shape19T35OK : fastTreeOK (forms 19) 49152 8192 q10Shape19T35=true := by decide

private def q10Shape19T25 : Tree := .split 15 q10Shape19T26 q10Shape19T35
private theorem q10Shape19T25OK : fastTreeOK (forms 19) 16384 8192 q10Shape19T25=true := by
  change (fastTreeOK (forms 19) 16384 (8192 ||| 2^15) q10Shape19T26 &&
    fastTreeOK (forms 19) (16384 ||| 2^15) 8192 q10Shape19T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T26OK,q10Shape19T35OK⟩

private def q10Shape19T1 : Tree := .split 14 q10Shape19T2 q10Shape19T25
private theorem q10Shape19T1OK : fastTreeOK (forms 19) 0 8192 q10Shape19T1=true := by
  change (fastTreeOK (forms 19) 0 (8192 ||| 2^14) q10Shape19T2 &&
    fastTreeOK (forms 19) (0 ||| 2^14) 8192 q10Shape19T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T2OK,q10Shape19T25OK⟩

private def q10Shape19T42 : Tree := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.split 17 (.split 20 (.split 21 (.split 23 (.split 24 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 4 6 7 8 9))) (.tip (.cover 4 6 7 8 9))) (.tip (.cover 5 6 7 8 9))) (.tip (.cover 5 6 7 8 9)))))))
private theorem q10Shape19T42OK : fastTreeOK (forms 19) 8192 139247616 q10Shape19T42=true := by decide

private def q10Shape19T43 : Tree := (.split 23 (.split 24 (.split 25 (.split 16 (.split 20 (.split 26 (.split 17 (.split 21 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 4 7 8)))
private theorem q10Shape19T43OK : fastTreeOK (forms 19) 134225920 5029888 q10Shape19T43=true := by decide

private def q10Shape19T41 : Tree := .split 27 q10Shape19T42 q10Shape19T43
private theorem q10Shape19T41OK : fastTreeOK (forms 19) 8192 5029888 q10Shape19T41=true := by
  change (fastTreeOK (forms 19) 8192 (5029888 ||| 2^27) q10Shape19T42 &&
    fastTreeOK (forms 19) (8192 ||| 2^27) 5029888 q10Shape19T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T42OK,q10Shape19T43OK⟩

private def q10Shape19T44 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 6)))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape19T44OK : fastTreeOK (forms 19) 4202496 835584 q10Shape19T44=true := by decide

private def q10Shape19T40 : Tree := .split 22 q10Shape19T41 q10Shape19T44
private theorem q10Shape19T40OK : fastTreeOK (forms 19) 8192 835584 q10Shape19T40=true := by
  change (fastTreeOK (forms 19) 8192 (835584 ||| 2^22) q10Shape19T41 &&
    fastTreeOK (forms 19) (8192 ||| 2^22) 835584 q10Shape19T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T41OK,q10Shape19T44OK⟩

private def q10Shape19T45 : Tree := (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 5 6)))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape19T45OK : fastTreeOK (forms 19) 532480 311296 q10Shape19T45=true := by decide

private def q10Shape19T39 : Tree := .split 19 q10Shape19T40 q10Shape19T45
private theorem q10Shape19T39OK : fastTreeOK (forms 19) 8192 311296 q10Shape19T39=true := by
  change (fastTreeOK (forms 19) 8192 (311296 ||| 2^19) q10Shape19T40 &&
    fastTreeOK (forms 19) (8192 ||| 2^19) 311296 q10Shape19T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T40OK,q10Shape19T45OK⟩

private def q10Shape19T46 : Tree := (.split 19 (.split 27 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape19T46OK : fastTreeOK (forms 19) 270336 49152 q10Shape19T46=true := by decide

private def q10Shape19T38 : Tree := .split 18 q10Shape19T39 q10Shape19T46
private theorem q10Shape19T38OK : fastTreeOK (forms 19) 8192 49152 q10Shape19T38=true := by
  change (fastTreeOK (forms 19) 8192 (49152 ||| 2^18) q10Shape19T39 &&
    fastTreeOK (forms 19) (8192 ||| 2^18) 49152 q10Shape19T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T39OK,q10Shape19T46OK⟩

private def q10Shape19T47 : Tree := (.split 27 (.split 16 (.split 17 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 6)))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 6 8)))
private theorem q10Shape19T47OK : fastTreeOK (forms 19) 40960 16384 q10Shape19T47=true := by decide

private def q10Shape19T37 : Tree := .split 15 q10Shape19T38 q10Shape19T47
private theorem q10Shape19T37OK : fastTreeOK (forms 19) 8192 16384 q10Shape19T37=true := by
  change (fastTreeOK (forms 19) 8192 (16384 ||| 2^15) q10Shape19T38 &&
    fastTreeOK (forms 19) (8192 ||| 2^15) 16384 q10Shape19T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T38OK,q10Shape19T47OK⟩

private def q10Shape19T48 : Tree := (.split 15 (.split 27 (.split 16 (.split 17 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover 0 1 2 4 7)))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape19T48OK : fastTreeOK (forms 19) 24576 0 q10Shape19T48=true := by decide

private def q10Shape19T36 : Tree := .split 14 q10Shape19T37 q10Shape19T48
private theorem q10Shape19T36OK : fastTreeOK (forms 19) 8192 0 q10Shape19T36=true := by
  change (fastTreeOK (forms 19) 8192 (0 ||| 2^14) q10Shape19T37 &&
    fastTreeOK (forms 19) (8192 ||| 2^14) 0 q10Shape19T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T37OK,q10Shape19T48OK⟩

private def q10Shape19T0 : Tree := .split 13 q10Shape19T1 q10Shape19T36
private theorem q10Shape19T0OK : fastTreeOK (forms 19) 0 0 q10Shape19T0=true := by
  change (fastTreeOK (forms 19) 0 (0 ||| 2^13) q10Shape19T1 &&
    fastTreeOK (forms 19) (0 ||| 2^13) 0 q10Shape19T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape19T1OK,q10Shape19T36OK⟩


theorem q10Shape19_cover (b : Nat→Bool) (H : Ranked (adj (forms 19) b)) :
    ∃ u v w z t,Effective (adj (forms 19) b) (adj (forms 19) b) u v w z t :=
  checked_fastTree (forms 19) b H q10Shape19T0 q10Shape19T0OK

#print axioms q10Shape19_cover
end Graffiti384b.Q10
