import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape2T5 : Tree := (.tip (.small 1))
private theorem q10Shape2T5OK : fastTreeOK (forms 2) 0 4752400 q10Shape2T5=true := by decide

private def q10Shape2T7 : Tree := (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 4 7 8 9)))))) (.tip (.cover 0 1 5 8 9)))) (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9)))))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 2 6 7 8 9))))) (.tip (.cover 0 1 5 8 9)))))
private theorem q10Shape2T7OK : fastTreeOK (forms 2) 524288 4228120 q10Shape2T7=true := by decide

private def q10Shape2T8 : Tree := (.split 9 (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9)))) (.split 14 (.split 18 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 1 5 6 8 9))))
private theorem q10Shape2T8OK : fastTreeOK (forms 2) 524296 4228112 q10Shape2T8=true := by decide

private def q10Shape2T6 : Tree := .split 3 q10Shape2T7 q10Shape2T8
private theorem q10Shape2T6OK : fastTreeOK (forms 2) 524288 4228112 q10Shape2T6=true := by
  change (fastTreeOK (forms 2) 524288 (4228112 ||| 2^3) q10Shape2T7 &&
    fastTreeOK (forms 2) (524288 ||| 2^3) 4228112 q10Shape2T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T7OK,q10Shape2T8OK⟩

private def q10Shape2T4 : Tree := .split 19 q10Shape2T5 q10Shape2T6
private theorem q10Shape2T4OK : fastTreeOK (forms 2) 0 4228112 q10Shape2T4=true := by
  change (fastTreeOK (forms 2) 0 (4228112 ||| 2^19) q10Shape2T5 &&
    fastTreeOK (forms 2) (0 ||| 2^19) 4228112 q10Shape2T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T5OK,q10Shape2T6OK⟩

private def q10Shape2T11 : Tree := (.split 9 (.split 14 (.split 18 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 1 4 6 8 9))))))) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 4 6 8 9))))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape2T11OK : fastTreeOK (forms 2) 32768 4719640 q10Shape2T11=true := by decide

private def q10Shape2T12 : Tree := (.split 9 (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8 9)))))) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8 9))))) (.tip (.cover 1 4 6 8 9))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape2T12OK : fastTreeOK (forms 2) 32776 4719632 q10Shape2T12=true := by decide

private def q10Shape2T10 : Tree := .split 3 q10Shape2T11 q10Shape2T12
private theorem q10Shape2T10OK : fastTreeOK (forms 2) 32768 4719632 q10Shape2T10=true := by
  change (fastTreeOK (forms 2) 32768 (4719632 ||| 2^3) q10Shape2T11 &&
    fastTreeOK (forms 2) (32768 ||| 2^3) 4719632 q10Shape2T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T11OK,q10Shape2T12OK⟩

private def q10Shape2T13 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))) (.split 9 (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 0 (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 2 3 7 8 9)))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))))
private theorem q10Shape2T13OK : fastTreeOK (forms 2) 557056 4195344 q10Shape2T13=true := by decide

private def q10Shape2T9 : Tree := .split 19 q10Shape2T10 q10Shape2T13
private theorem q10Shape2T9OK : fastTreeOK (forms 2) 32768 4195344 q10Shape2T9=true := by
  change (fastTreeOK (forms 2) 32768 (4195344 ||| 2^19) q10Shape2T10 &&
    fastTreeOK (forms 2) (32768 ||| 2^19) 4195344 q10Shape2T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T10OK,q10Shape2T13OK⟩

private def q10Shape2T3 : Tree := .split 15 q10Shape2T4 q10Shape2T9
private theorem q10Shape2T3OK : fastTreeOK (forms 2) 0 4195344 q10Shape2T3=true := by
  change (fastTreeOK (forms 2) 0 (4195344 ||| 2^15) q10Shape2T4 &&
    fastTreeOK (forms 2) (0 ||| 2^15) 4195344 q10Shape2T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T4OK,q10Shape2T9OK⟩

private def q10Shape2T17 : Tree := (.split 9 (.split 14 (.split 18 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 6 8 9))))))) (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 1 3 6 8 9))))))) (.split 0 (.tip (.small 1)) (.tip (.cover 1 3 6 8 9))))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape2T17OK : fastTreeOK (forms 2) 1024 4751384 q10Shape2T17=true := by decide

private def q10Shape2T18 : Tree := (.split 9 (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8 9)))))) (.split 18 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8 9))))) (.tip (.cover 1 3 6 8 9)))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape2T18OK : fastTreeOK (forms 2) 1032 4751376 q10Shape2T18=true := by decide

private def q10Shape2T16 : Tree := .split 3 q10Shape2T17 q10Shape2T18
private theorem q10Shape2T16OK : fastTreeOK (forms 2) 1024 4751376 q10Shape2T16=true := by
  change (fastTreeOK (forms 2) 1024 (4751376 ||| 2^3) q10Shape2T17 &&
    fastTreeOK (forms 2) (1024 ||| 2^3) 4751376 q10Shape2T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T17OK,q10Shape2T18OK⟩

private def q10Shape2T19 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 3 8 9))) (.split 9 (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9))) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape2T19OK : fastTreeOK (forms 2) 525312 4227088 q10Shape2T19=true := by decide

private def q10Shape2T15 : Tree := .split 19 q10Shape2T16 q10Shape2T19
private theorem q10Shape2T15OK : fastTreeOK (forms 2) 1024 4227088 q10Shape2T15=true := by
  change (fastTreeOK (forms 2) 1024 (4227088 ||| 2^19) q10Shape2T16 &&
    fastTreeOK (forms 2) (1024 ||| 2^19) 4227088 q10Shape2T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T16OK,q10Shape2T19OK⟩

private def q10Shape2T21 : Tree := (.split 3 (.split 9 (.split 14 (.split 18 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 2 6 7 8 9)))))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.split 9 (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9))))) (.split 0 (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9)))) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 2 5 7 8 9))))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape2T21OK : fastTreeOK (forms 2) 33792 4718608 q10Shape2T21=true := by decide

private def q10Shape2T22 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 2 7 8 9)))
private theorem q10Shape2T22OK : fastTreeOK (forms 2) 558080 4194320 q10Shape2T22=true := by decide

private def q10Shape2T20 : Tree := .split 19 q10Shape2T21 q10Shape2T22
private theorem q10Shape2T20OK : fastTreeOK (forms 2) 33792 4194320 q10Shape2T20=true := by
  change (fastTreeOK (forms 2) 33792 (4194320 ||| 2^19) q10Shape2T21 &&
    fastTreeOK (forms 2) (33792 ||| 2^19) 4194320 q10Shape2T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T21OK,q10Shape2T22OK⟩

private def q10Shape2T14 : Tree := .split 15 q10Shape2T15 q10Shape2T20
private theorem q10Shape2T14OK : fastTreeOK (forms 2) 1024 4194320 q10Shape2T14=true := by
  change (fastTreeOK (forms 2) 1024 (4194320 ||| 2^15) q10Shape2T15 &&
    fastTreeOK (forms 2) (1024 ||| 2^15) 4194320 q10Shape2T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T15OK,q10Shape2T20OK⟩

private def q10Shape2T2 : Tree := .split 10 q10Shape2T3 q10Shape2T14
private theorem q10Shape2T2OK : fastTreeOK (forms 2) 0 4194320 q10Shape2T2=true := by
  change (fastTreeOK (forms 2) 0 (4194320 ||| 2^10) q10Shape2T3 &&
    fastTreeOK (forms 2) (0 ||| 2^10) 4194320 q10Shape2T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T3OK,q10Shape2T14OK⟩

private def q10Shape2T28 : Tree := (.split 14 (.split 18 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.split 0 (.tip (.small 1)) (.tip (.cover 1 2 6 8 9)))))
private theorem q10Shape2T28OK : fastTreeOK (forms 2) 16 4752904 q10Shape2T28=true := by decide

private def q10Shape2T29 : Tree := (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 6 8 9))))) (.split 18 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 1 2 6 8 9))))) (.tip (.cover 1 2 6 8 9))))
private theorem q10Shape2T29OK : fastTreeOK (forms 2) 528 4752392 q10Shape2T29=true := by decide

private def q10Shape2T27 : Tree := .split 9 q10Shape2T28 q10Shape2T29
private theorem q10Shape2T27OK : fastTreeOK (forms 2) 16 4752392 q10Shape2T27=true := by
  change (fastTreeOK (forms 2) 16 (4752392 ||| 2^9) q10Shape2T28 &&
    fastTreeOK (forms 2) (16 ||| 2^9) 4752392 q10Shape2T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T28OK,q10Shape2T29OK⟩

private def q10Shape2T30 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape2T30OK : fastTreeOK (forms 2) 24 4752384 q10Shape2T30=true := by decide

private def q10Shape2T26 : Tree := .split 3 q10Shape2T27 q10Shape2T30
private theorem q10Shape2T26OK : fastTreeOK (forms 2) 16 4752384 q10Shape2T26=true := by
  change (fastTreeOK (forms 2) 16 (4752384 ||| 2^3) q10Shape2T27 &&
    fastTreeOK (forms 2) (16 ||| 2^3) 4752384 q10Shape2T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T27OK,q10Shape2T30OK⟩

private def q10Shape2T31 : Tree := (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.tip (.cover 0 1 5 8 9)))) (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 0 (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9)))) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))) (.tip (.cover 2 5 6 8 9)))) (.tip (.cover 0 1 5 8 9))))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape2T31OK : fastTreeOK (forms 2) 524304 4228096 q10Shape2T31=true := by decide

private def q10Shape2T25 : Tree := .split 19 q10Shape2T26 q10Shape2T31
private theorem q10Shape2T25OK : fastTreeOK (forms 2) 16 4228096 q10Shape2T25=true := by
  change (fastTreeOK (forms 2) 16 (4228096 ||| 2^19) q10Shape2T26 &&
    fastTreeOK (forms 2) (16 ||| 2^19) 4228096 q10Shape2T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T26OK,q10Shape2T31OK⟩

private def q10Shape2T32 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.split 18 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.tip (.cover 0 1 4 8 9))) (.split 14 (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 1 2 6 8 9))))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 2 8 9))) (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape2T32OK : fastTreeOK (forms 2) 32784 4195328 q10Shape2T32=true := by decide

private def q10Shape2T24 : Tree := .split 15 q10Shape2T25 q10Shape2T32
private theorem q10Shape2T24OK : fastTreeOK (forms 2) 16 4195328 q10Shape2T24=true := by
  change (fastTreeOK (forms 2) 16 (4195328 ||| 2^15) q10Shape2T25 &&
    fastTreeOK (forms 2) (16 ||| 2^15) 4195328 q10Shape2T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T25OK,q10Shape2T32OK⟩

private def q10Shape2T34 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.split 18 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.split 18 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8 9))))) (.split 0 (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 2 3 6 8 9)))) (.tip (.cover 1 2 6 8 9))))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))) (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape2T34OK : fastTreeOK (forms 2) 1040 4227072 q10Shape2T34=true := by decide

private def q10Shape2T35 : Tree := (.split 19 (.split 3 (.split 9 (.split 14 (.tip (.cover 0 5 7 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))) (.split 3 (.split 9 (.split 14 (.tip (.cover 0 1 5 8 9)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape2T35OK : fastTreeOK (forms 2) 33808 4194304 q10Shape2T35=true := by decide

private def q10Shape2T33 : Tree := .split 15 q10Shape2T34 q10Shape2T35
private theorem q10Shape2T33OK : fastTreeOK (forms 2) 1040 4194304 q10Shape2T33=true := by
  change (fastTreeOK (forms 2) 1040 (4194304 ||| 2^15) q10Shape2T34 &&
    fastTreeOK (forms 2) (1040 ||| 2^15) 4194304 q10Shape2T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T34OK,q10Shape2T35OK⟩

private def q10Shape2T23 : Tree := .split 10 q10Shape2T24 q10Shape2T33
private theorem q10Shape2T23OK : fastTreeOK (forms 2) 16 4194304 q10Shape2T23=true := by
  change (fastTreeOK (forms 2) 16 (4194304 ||| 2^10) q10Shape2T24 &&
    fastTreeOK (forms 2) (16 ||| 2^10) 4194304 q10Shape2T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T24OK,q10Shape2T33OK⟩

private def q10Shape2T1 : Tree := .split 4 q10Shape2T2 q10Shape2T23
private theorem q10Shape2T1OK : fastTreeOK (forms 2) 0 4194304 q10Shape2T1=true := by
  change (fastTreeOK (forms 2) 0 (4194304 ||| 2^4) q10Shape2T2 &&
    fastTreeOK (forms 2) (0 ||| 2^4) 4194304 q10Shape2T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T2OK,q10Shape2T23OK⟩

private def q10Shape2T36 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape2T36OK : fastTreeOK (forms 2) 4194304 0 q10Shape2T36=true := by decide

private def q10Shape2T0 : Tree := .split 22 q10Shape2T1 q10Shape2T36
private theorem q10Shape2T0OK : fastTreeOK (forms 2) 0 0 q10Shape2T0=true := by
  change (fastTreeOK (forms 2) 0 (0 ||| 2^22) q10Shape2T1 &&
    fastTreeOK (forms 2) (0 ||| 2^22) 0 q10Shape2T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape2T1OK,q10Shape2T36OK⟩


theorem q10Shape2_cover (b : Nat→Bool) (H : Ranked (adj (forms 2) b)) :
    ∃ u v w z t,Effective (adj (forms 2) b) (adj (forms 2) b) u v w z t :=
  checked_fastTree (forms 2) b H q10Shape2T0 q10Shape2T0OK

#print axioms q10Shape2_cover
end Graffiti384b.Q10
