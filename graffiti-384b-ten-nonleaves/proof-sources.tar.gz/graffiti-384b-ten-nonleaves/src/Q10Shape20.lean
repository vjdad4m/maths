import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape20T8 : Tree := (.split 26 (.tip (.cover 0 2 3 4 8)) (.split 27 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 14 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 9 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))) (.split 11 (.split 16 (.split 2 (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 5 6 9))))
private theorem q10Shape20T8OK : fastTreeOK (forms 20) 0 66846720 q10Shape20T8=true := by decide

private def q10Shape20T9 : Tree := (.split 26 (.split 27 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 15 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 7 9)))) (.split 16 (.split 8 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 3 4 6)))) (.split 11 (.split 16 (.split 2 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape20T9OK : fastTreeOK (forms 20) 16777216 50069504 q10Shape20T9=true := by decide

private def q10Shape20T7 : Tree := .split 24 q10Shape20T8 q10Shape20T9
private theorem q10Shape20T7OK : fastTreeOK (forms 20) 0 50069504 q10Shape20T7=true := by
  change (fastTreeOK (forms 20) 0 (50069504 ||| 2^24) q10Shape20T8 &&
    fastTreeOK (forms 20) (0 ||| 2^24) 50069504 q10Shape20T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T8OK,q10Shape20T9OK⟩

private def q10Shape20T10 : Tree := (.split 24 (.split 26 (.split 27 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 14 (.split 15 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9)))) (.split 16 (.split 9 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 3 4 5)))) (.split 11 (.split 16 (.split 3 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 8 9))) (.tip (.cover 0 1 7 8 9)))
private theorem q10Shape20T10OK : fastTreeOK (forms 20) 2097152 47972352 q10Shape20T10=true := by decide

private def q10Shape20T6 : Tree := .split 21 q10Shape20T7 q10Shape20T10
private theorem q10Shape20T6OK : fastTreeOK (forms 20) 0 47972352 q10Shape20T6=true := by
  change (fastTreeOK (forms 20) 0 (47972352 ||| 2^21) q10Shape20T7 &&
    fastTreeOK (forms 20) (0 ||| 2^21) 47972352 q10Shape20T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T7OK,q10Shape20T10OK⟩

private def q10Shape20T11 : Tree := (.split 21 (.split 24 (.split 26 (.tip (.cover 0 2 3 4 8)) (.split 27 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 1 5 6 9)))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 6 7 9)))
private theorem q10Shape20T11OK : fastTreeOK (forms 20) 33554432 14417920 q10Shape20T11=true := by decide

private def q10Shape20T5 : Tree := .split 25 q10Shape20T6 q10Shape20T11
private theorem q10Shape20T5OK : fastTreeOK (forms 20) 0 14417920 q10Shape20T5=true := by
  change (fastTreeOK (forms 20) 0 (14417920 ||| 2^25) q10Shape20T6 &&
    fastTreeOK (forms 20) (0 ||| 2^25) 14417920 q10Shape20T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T6OK,q10Shape20T11OK⟩

private def q10Shape20T12 : Tree := (.split 25 (.split 21 (.split 26 (.split 24 (.tip (.cover 0 2 3 4 8)) (.split 27 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape20T12OK : fastTreeOK (forms 20) 8388608 6029312 q10Shape20T12=true := by decide

private def q10Shape20T4 : Tree := .split 23 q10Shape20T5 q10Shape20T12
private theorem q10Shape20T4OK : fastTreeOK (forms 20) 0 6029312 q10Shape20T4=true := by
  change (fastTreeOK (forms 20) 0 (6029312 ||| 2^23) q10Shape20T5 &&
    fastTreeOK (forms 20) (0 ||| 2^23) 6029312 q10Shape20T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T5OK,q10Shape20T12OK⟩

private def q10Shape20T13 : Tree := (.split 23 (.split 25 (.split 24 (.split 26 (.split 21 (.tip (.cover 0 2 3 4 8)) (.split 27 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 1 6 7 9)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 6 8 9))) (.tip (.cover 0 1 7 8 9)))
private theorem q10Shape20T13OK : fastTreeOK (forms 20) 1048576 4980736 q10Shape20T13=true := by decide

private def q10Shape20T3 : Tree := .split 20 q10Shape20T4 q10Shape20T13
private theorem q10Shape20T3OK : fastTreeOK (forms 20) 0 4980736 q10Shape20T3=true := by
  change (fastTreeOK (forms 20) 0 (4980736 ||| 2^20) q10Shape20T4 &&
    fastTreeOK (forms 20) (0 ||| 2^20) 4980736 q10Shape20T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T4OK,q10Shape20T13OK⟩

private def q10Shape20T22 : Tree := (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 3 6 8 9))) (.split 12 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 2 6 8 9)))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 6 8)) (.split 2 (.split 6 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 4 6 8 9))) (.split 17 (.tip (.cover 0 1 2 3 6)) (.tip (.cover 0 2 6 8 9))))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 6))))
private theorem q10Shape20T22OK : fastTreeOK (forms 20) 4194304 263979040 q10Shape20T22=true := by decide

private def q10Shape20T23 : Tree := (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 6 8)) (.split 3 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 8 (.tip (.cover 0 4 6 8 9)) (.tip (.cover 0 3 6 8 9)))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 5 7 9)))))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6)))
private theorem q10Shape20T23OK : fastTreeOK (forms 20) 4194336 263979008 q10Shape20T23=true := by decide

private def q10Shape20T21 : Tree := .split 5 q10Shape20T22 q10Shape20T23
private theorem q10Shape20T21OK : fastTreeOK (forms 20) 4194304 263979008 q10Shape20T21=true := by
  change (fastTreeOK (forms 20) 4194304 (263979008 ||| 2^5) q10Shape20T22 &&
    fastTreeOK (forms 20) (4194304 ||| 2^5) 263979008 q10Shape20T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T22OK,q10Shape20T23OK⟩

private def q10Shape20T24 : Tree := (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 3 (.split 17 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))) (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))))
private theorem q10Shape20T24OK : fastTreeOK (forms 20) 71303168 196870144 q10Shape20T24=true := by decide

private def q10Shape20T20 : Tree := .split 26 q10Shape20T21 q10Shape20T24
private theorem q10Shape20T20OK : fastTreeOK (forms 20) 4194304 196870144 q10Shape20T20=true := by
  change (fastTreeOK (forms 20) 4194304 (196870144 ||| 2^26) q10Shape20T21 &&
    fastTreeOK (forms 20) (4194304 ||| 2^26) 196870144 q10Shape20T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T21OK,q10Shape20T24OK⟩

private def q10Shape20T25 : Tree := (.split 26 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 4 (.split 17 (.tip (.cover 0 2 3 6 8)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 12 (.tip (.cover 0 2 4 6 8)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 6)))) (.split 11 (.split 16 (.split 2 (.split 6 (.tip (.cover 0 3 4 6 8)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape20T25OK : fastTreeOK (forms 20) 20971520 180092928 q10Shape20T25=true := by decide

private def q10Shape20T19 : Tree := .split 24 q10Shape20T20 q10Shape20T25
private theorem q10Shape20T19OK : fastTreeOK (forms 20) 4194304 180092928 q10Shape20T19=true := by
  change (fastTreeOK (forms 20) 4194304 (180092928 ||| 2^24) q10Shape20T20 &&
    fastTreeOK (forms 20) (4194304 ||| 2^24) 180092928 q10Shape20T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T20OK,q10Shape20T25OK⟩

private def q10Shape20T26 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape20T26OK : fastTreeOK (forms 20) 138412032 45875200 q10Shape20T26=true := by decide

private def q10Shape20T18 : Tree := .split 27 q10Shape20T19 q10Shape20T26
private theorem q10Shape20T18OK : fastTreeOK (forms 20) 4194304 45875200 q10Shape20T18=true := by
  change (fastTreeOK (forms 20) 4194304 (45875200 ||| 2^27) q10Shape20T19 &&
    fastTreeOK (forms 20) (4194304 ||| 2^27) 45875200 q10Shape20T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T19OK,q10Shape20T26OK⟩

private def q10Shape20T27 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape20T27OK : fastTreeOK (forms 20) 6291456 43778048 q10Shape20T27=true := by decide

private def q10Shape20T17 : Tree := .split 21 q10Shape20T18 q10Shape20T27
private theorem q10Shape20T17OK : fastTreeOK (forms 20) 4194304 43778048 q10Shape20T17=true := by
  change (fastTreeOK (forms 20) 4194304 (43778048 ||| 2^21) q10Shape20T18 &&
    fastTreeOK (forms 20) (4194304 ||| 2^21) 43778048 q10Shape20T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T18OK,q10Shape20T27OK⟩

private def q10Shape20T28 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape20T28OK : fastTreeOK (forms 20) 37748736 10223616 q10Shape20T28=true := by decide

private def q10Shape20T16 : Tree := .split 25 q10Shape20T17 q10Shape20T28
private theorem q10Shape20T16OK : fastTreeOK (forms 20) 4194304 10223616 q10Shape20T16=true := by
  change (fastTreeOK (forms 20) 4194304 (10223616 ||| 2^25) q10Shape20T17 &&
    fastTreeOK (forms 20) (4194304 ||| 2^25) 10223616 q10Shape20T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T17OK,q10Shape20T28OK⟩

private def q10Shape20T29 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape20T29OK : fastTreeOK (forms 20) 12582912 1835008 q10Shape20T29=true := by decide

private def q10Shape20T15 : Tree := .split 23 q10Shape20T16 q10Shape20T29
private theorem q10Shape20T15OK : fastTreeOK (forms 20) 4194304 1835008 q10Shape20T15=true := by
  change (fastTreeOK (forms 20) 4194304 (1835008 ||| 2^23) q10Shape20T16 &&
    fastTreeOK (forms 20) (4194304 ||| 2^23) 1835008 q10Shape20T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T16OK,q10Shape20T29OK⟩

private def q10Shape20T30 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape20T30OK : fastTreeOK (forms 20) 5242880 786432 q10Shape20T30=true := by decide

private def q10Shape20T14 : Tree := .split 20 q10Shape20T15 q10Shape20T30
private theorem q10Shape20T14OK : fastTreeOK (forms 20) 4194304 786432 q10Shape20T14=true := by
  change (fastTreeOK (forms 20) 4194304 (786432 ||| 2^20) q10Shape20T15 &&
    fastTreeOK (forms 20) (4194304 ||| 2^20) 786432 q10Shape20T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T15OK,q10Shape20T30OK⟩

private def q10Shape20T2 : Tree := .split 22 q10Shape20T3 q10Shape20T14
private theorem q10Shape20T2OK : fastTreeOK (forms 20) 0 786432 q10Shape20T2=true := by
  change (fastTreeOK (forms 20) 0 (786432 ||| 2^22) q10Shape20T3 &&
    fastTreeOK (forms 20) (0 ||| 2^22) 786432 q10Shape20T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T3OK,q10Shape20T14OK⟩

private def q10Shape20T41 : Tree := (.split 16 (.tip (.small 1)) (.split 14 (.split 2 (.split 17 (.tip (.cover 0 2 3 5 8)) (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 2 5 8 9))))) (.split 3 (.tip (.cover 0 3 5 8 9)) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 2 5 8 9))))) (.tip (.cover 0 1 4 5 9))))
private theorem q10Shape20T41OK : fastTreeOK (forms 20) 524288 267651104 q10Shape20T41=true := by decide

private def q10Shape20T42 : Tree := (.split 16 (.split 9 (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 2 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 3 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 2 5 8 9))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 3 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 2 5 8 9))))))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape20T42OK : fastTreeOK (forms 20) 526336 267649056 q10Shape20T42=true := by decide

private def q10Shape20T40 : Tree := .split 11 q10Shape20T41 q10Shape20T42
private theorem q10Shape20T40OK : fastTreeOK (forms 20) 524288 267649056 q10Shape20T40=true := by
  change (fastTreeOK (forms 20) 524288 (267649056 ||| 2^11) q10Shape20T41 &&
    fastTreeOK (forms 20) (524288 ||| 2^11) 267649056 q10Shape20T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T41OK,q10Shape20T42OK⟩

private def q10Shape20T43 : Tree := (.split 11 (.split 16 (.split 3 (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 2 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 9 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 3 5 8 9)))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9)))))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape20T43OK : fastTreeOK (forms 20) 524320 267649024 q10Shape20T43=true := by decide

private def q10Shape20T39 : Tree := .split 5 q10Shape20T40 q10Shape20T43
private theorem q10Shape20T39OK : fastTreeOK (forms 20) 524288 267649024 q10Shape20T39=true := by
  change (fastTreeOK (forms 20) 524288 (267649024 ||| 2^5) q10Shape20T40 &&
    fastTreeOK (forms 20) (524288 ||| 2^5) 267649024 q10Shape20T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T40OK,q10Shape20T43OK⟩

private def q10Shape20T44 : Tree := (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 14 (.split 17 (.tip (.cover 0 2 3 7 8)) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 6 9)))) (.split 16 (.split 8 (.split 9 (.split 12 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 4 7)))) (.split 11 (.split 16 (.split 2 (.split 3 (.split 6 (.tip (.cover 0 3 4 7 8)) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))))
private theorem q10Shape20T44OK : fastTreeOK (forms 20) 67633152 200540160 q10Shape20T44=true := by decide

private def q10Shape20T38 : Tree := .split 26 q10Shape20T39 q10Shape20T44
private theorem q10Shape20T38OK : fastTreeOK (forms 20) 524288 200540160 q10Shape20T38=true := by
  change (fastTreeOK (forms 20) 524288 (200540160 ||| 2^26) q10Shape20T39 &&
    fastTreeOK (forms 20) (524288 ||| 2^26) 200540160 q10Shape20T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T39OK,q10Shape20T44OK⟩

private def q10Shape20T45 : Tree := (.split 26 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 14 (.split 4 (.split 17 (.tip (.cover 0 2 3 5 8)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 4 5 9)))) (.split 16 (.split 9 (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 2 3 4 5)))) (.split 11 (.split 16 (.split 3 (.split 6 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape20T45OK : fastTreeOK (forms 20) 2621440 198443008 q10Shape20T45=true := by decide

private def q10Shape20T37 : Tree := .split 21 q10Shape20T38 q10Shape20T45
private theorem q10Shape20T37OK : fastTreeOK (forms 20) 524288 198443008 q10Shape20T37=true := by
  change (fastTreeOK (forms 20) 524288 (198443008 ||| 2^21) q10Shape20T38 &&
    fastTreeOK (forms 20) (524288 ||| 2^21) 198443008 q10Shape20T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T38OK,q10Shape20T45OK⟩

private def q10Shape20T46 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape20T46OK : fastTreeOK (forms 20) 134742016 64225280 q10Shape20T46=true := by decide

private def q10Shape20T36 : Tree := .split 27 q10Shape20T37 q10Shape20T46
private theorem q10Shape20T36OK : fastTreeOK (forms 20) 524288 64225280 q10Shape20T36=true := by
  change (fastTreeOK (forms 20) 524288 (64225280 ||| 2^27) q10Shape20T37 &&
    fastTreeOK (forms 20) (524288 ||| 2^27) 64225280 q10Shape20T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T37OK,q10Shape20T46OK⟩

private def q10Shape20T47 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape20T47OK : fastTreeOK (forms 20) 17301504 47448064 q10Shape20T47=true := by decide

private def q10Shape20T35 : Tree := .split 24 q10Shape20T36 q10Shape20T47
private theorem q10Shape20T35OK : fastTreeOK (forms 20) 524288 47448064 q10Shape20T35=true := by
  change (fastTreeOK (forms 20) 524288 (47448064 ||| 2^24) q10Shape20T36 &&
    fastTreeOK (forms 20) (524288 ||| 2^24) 47448064 q10Shape20T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T36OK,q10Shape20T47OK⟩

private def q10Shape20T48 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape20T48OK : fastTreeOK (forms 20) 34078720 13893632 q10Shape20T48=true := by decide

private def q10Shape20T34 : Tree := .split 25 q10Shape20T35 q10Shape20T48
private theorem q10Shape20T34OK : fastTreeOK (forms 20) 524288 13893632 q10Shape20T34=true := by
  change (fastTreeOK (forms 20) 524288 (13893632 ||| 2^25) q10Shape20T35 &&
    fastTreeOK (forms 20) (524288 ||| 2^25) 13893632 q10Shape20T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T35OK,q10Shape20T48OK⟩

private def q10Shape20T49 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape20T49OK : fastTreeOK (forms 20) 8912896 5505024 q10Shape20T49=true := by decide

private def q10Shape20T33 : Tree := .split 23 q10Shape20T34 q10Shape20T49
private theorem q10Shape20T33OK : fastTreeOK (forms 20) 524288 5505024 q10Shape20T33=true := by
  change (fastTreeOK (forms 20) 524288 (5505024 ||| 2^23) q10Shape20T34 &&
    fastTreeOK (forms 20) (524288 ||| 2^23) 5505024 q10Shape20T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T34OK,q10Shape20T49OK⟩

private def q10Shape20T50 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape20T50OK : fastTreeOK (forms 20) 1572864 4456448 q10Shape20T50=true := by decide

private def q10Shape20T32 : Tree := .split 20 q10Shape20T33 q10Shape20T50
private theorem q10Shape20T32OK : fastTreeOK (forms 20) 524288 4456448 q10Shape20T32=true := by
  change (fastTreeOK (forms 20) 524288 (4456448 ||| 2^20) q10Shape20T33 &&
    fastTreeOK (forms 20) (524288 ||| 2^20) 4456448 q10Shape20T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T33OK,q10Shape20T50OK⟩

private def q10Shape20T51 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape20T51OK : fastTreeOK (forms 20) 4718592 262144 q10Shape20T51=true := by decide

private def q10Shape20T31 : Tree := .split 22 q10Shape20T32 q10Shape20T51
private theorem q10Shape20T31OK : fastTreeOK (forms 20) 524288 262144 q10Shape20T31=true := by
  change (fastTreeOK (forms 20) 524288 (262144 ||| 2^22) q10Shape20T32 &&
    fastTreeOK (forms 20) (524288 ||| 2^22) 262144 q10Shape20T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T32OK,q10Shape20T51OK⟩

private def q10Shape20T1 : Tree := .split 19 q10Shape20T2 q10Shape20T31
private theorem q10Shape20T1OK : fastTreeOK (forms 20) 0 262144 q10Shape20T1=true := by
  change (fastTreeOK (forms 20) 0 (262144 ||| 2^19) q10Shape20T2 &&
    fastTreeOK (forms 20) (0 ||| 2^19) 262144 q10Shape20T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T2OK,q10Shape20T31OK⟩

private def q10Shape20T63 : Tree := (.split 16 (.tip (.small 1)) (.split 15 (.split 2 (.split 17 (.tip (.cover 0 2 3 5 8)) (.split 0 (.tip (.small 1)) (.split 4 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 2 5 8 9))))) (.split 3 (.split 0 (.tip (.small 1)) (.split 4 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 0 2 3 4 8)))) (.tip (.cover 0 1 4 5 9))))
private theorem q10Shape20T63OK : fastTreeOK (forms 20) 262144 267913248 q10Shape20T63=true := by decide

private def q10Shape20T64 : Tree := (.split 16 (.split 10 (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 2 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 4 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 2 5 8 9))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 4 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 2 5 8 9))))))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape20T64OK : fastTreeOK (forms 20) 264192 267911200 q10Shape20T64=true := by decide

private def q10Shape20T62 : Tree := .split 11 q10Shape20T63 q10Shape20T64
private theorem q10Shape20T62OK : fastTreeOK (forms 20) 262144 267911200 q10Shape20T62=true := by
  change (fastTreeOK (forms 20) 262144 (267911200 ||| 2^11) q10Shape20T63 &&
    fastTreeOK (forms 20) (262144 ||| 2^11) 267911200 q10Shape20T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T63OK,q10Shape20T64OK⟩

private def q10Shape20T65 : Tree := (.split 11 (.split 16 (.split 4 (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 2 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 3 5 8 9)))))) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9)))))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape20T65OK : fastTreeOK (forms 20) 262176 267911168 q10Shape20T65=true := by decide

private def q10Shape20T61 : Tree := .split 5 q10Shape20T62 q10Shape20T65
private theorem q10Shape20T61OK : fastTreeOK (forms 20) 262144 267911168 q10Shape20T61=true := by
  change (fastTreeOK (forms 20) 262144 (267911168 ||| 2^5) q10Shape20T62 &&
    fastTreeOK (forms 20) (262144 ||| 2^5) 267911168 q10Shape20T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T62OK,q10Shape20T65OK⟩

private def q10Shape20T66 : Tree := (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 13 (.split 15 (.split 17 (.tip (.cover 0 2 3 6 8)) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 7 9)))) (.split 16 (.split 8 (.split 10 (.split 12 (.tip (.cover 0 2 4 6 8)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 3 4 6)))) (.split 11 (.split 16 (.split 2 (.split 4 (.split 6 (.tip (.cover 0 3 4 6 8)) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6))))
private theorem q10Shape20T66OK : fastTreeOK (forms 20) 17039360 251133952 q10Shape20T66=true := by decide

private def q10Shape20T60 : Tree := .split 24 q10Shape20T61 q10Shape20T66
private theorem q10Shape20T60OK : fastTreeOK (forms 20) 262144 251133952 q10Shape20T60=true := by
  change (fastTreeOK (forms 20) 262144 (251133952 ||| 2^24) q10Shape20T61 &&
    fastTreeOK (forms 20) (262144 ||| 2^24) 251133952 q10Shape20T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T61OK,q10Shape20T66OK⟩

private def q10Shape20T67 : Tree := (.split 24 (.split 5 (.split 11 (.split 16 (.tip (.small 1)) (.split 14 (.split 15 (.split 17 (.tip (.cover 0 2 3 5 8)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 4 7 9)))) (.split 16 (.split 9 (.split 10 (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 3 4 5)))) (.split 11 (.split 16 (.split 3 (.split 4 (.split 6 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 7 8 9)))
private theorem q10Shape20T67OK : fastTreeOK (forms 20) 2359296 249036800 q10Shape20T67=true := by decide

private def q10Shape20T59 : Tree := .split 21 q10Shape20T60 q10Shape20T67
private theorem q10Shape20T59OK : fastTreeOK (forms 20) 262144 249036800 q10Shape20T59=true := by
  change (fastTreeOK (forms 20) 262144 (249036800 ||| 2^21) q10Shape20T60 &&
    fastTreeOK (forms 20) (262144 ||| 2^21) 249036800 q10Shape20T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T60OK,q10Shape20T67OK⟩

private def q10Shape20T68 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape20T68OK : fastTreeOK (forms 20) 134479872 114819072 q10Shape20T68=true := by decide

private def q10Shape20T58 : Tree := .split 27 q10Shape20T59 q10Shape20T68
private theorem q10Shape20T58OK : fastTreeOK (forms 20) 262144 114819072 q10Shape20T58=true := by
  change (fastTreeOK (forms 20) 262144 (114819072 ||| 2^27) q10Shape20T59 &&
    fastTreeOK (forms 20) (262144 ||| 2^27) 114819072 q10Shape20T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T59OK,q10Shape20T68OK⟩

private def q10Shape20T69 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape20T69OK : fastTreeOK (forms 20) 67371008 47710208 q10Shape20T69=true := by decide

private def q10Shape20T57 : Tree := .split 26 q10Shape20T58 q10Shape20T69
private theorem q10Shape20T57OK : fastTreeOK (forms 20) 262144 47710208 q10Shape20T57=true := by
  change (fastTreeOK (forms 20) 262144 (47710208 ||| 2^26) q10Shape20T58 &&
    fastTreeOK (forms 20) (262144 ||| 2^26) 47710208 q10Shape20T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T58OK,q10Shape20T69OK⟩

private def q10Shape20T70 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape20T70OK : fastTreeOK (forms 20) 33816576 14155776 q10Shape20T70=true := by decide

private def q10Shape20T56 : Tree := .split 25 q10Shape20T57 q10Shape20T70
private theorem q10Shape20T56OK : fastTreeOK (forms 20) 262144 14155776 q10Shape20T56=true := by
  change (fastTreeOK (forms 20) 262144 (14155776 ||| 2^25) q10Shape20T57 &&
    fastTreeOK (forms 20) (262144 ||| 2^25) 14155776 q10Shape20T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T57OK,q10Shape20T70OK⟩

private def q10Shape20T71 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape20T71OK : fastTreeOK (forms 20) 8650752 5767168 q10Shape20T71=true := by decide

private def q10Shape20T55 : Tree := .split 23 q10Shape20T56 q10Shape20T71
private theorem q10Shape20T55OK : fastTreeOK (forms 20) 262144 5767168 q10Shape20T55=true := by
  change (fastTreeOK (forms 20) 262144 (5767168 ||| 2^23) q10Shape20T56 &&
    fastTreeOK (forms 20) (262144 ||| 2^23) 5767168 q10Shape20T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T56OK,q10Shape20T71OK⟩

private def q10Shape20T72 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape20T72OK : fastTreeOK (forms 20) 1310720 4718592 q10Shape20T72=true := by decide

private def q10Shape20T54 : Tree := .split 20 q10Shape20T55 q10Shape20T72
private theorem q10Shape20T54OK : fastTreeOK (forms 20) 262144 4718592 q10Shape20T54=true := by
  change (fastTreeOK (forms 20) 262144 (4718592 ||| 2^20) q10Shape20T55 &&
    fastTreeOK (forms 20) (262144 ||| 2^20) 4718592 q10Shape20T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T55OK,q10Shape20T72OK⟩

private def q10Shape20T73 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape20T73OK : fastTreeOK (forms 20) 4456448 524288 q10Shape20T73=true := by decide

private def q10Shape20T53 : Tree := .split 22 q10Shape20T54 q10Shape20T73
private theorem q10Shape20T53OK : fastTreeOK (forms 20) 262144 524288 q10Shape20T53=true := by
  change (fastTreeOK (forms 20) 262144 (524288 ||| 2^22) q10Shape20T54 &&
    fastTreeOK (forms 20) (262144 ||| 2^22) 524288 q10Shape20T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T54OK,q10Shape20T73OK⟩

private def q10Shape20T74 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape20T74OK : fastTreeOK (forms 20) 786432 0 q10Shape20T74=true := by decide

private def q10Shape20T52 : Tree := .split 19 q10Shape20T53 q10Shape20T74
private theorem q10Shape20T52OK : fastTreeOK (forms 20) 262144 0 q10Shape20T52=true := by
  change (fastTreeOK (forms 20) 262144 (0 ||| 2^19) q10Shape20T53 &&
    fastTreeOK (forms 20) (262144 ||| 2^19) 0 q10Shape20T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T53OK,q10Shape20T74OK⟩

private def q10Shape20T0 : Tree := .split 18 q10Shape20T1 q10Shape20T52
private theorem q10Shape20T0OK : fastTreeOK (forms 20) 0 0 q10Shape20T0=true := by
  change (fastTreeOK (forms 20) 0 (0 ||| 2^18) q10Shape20T1 &&
    fastTreeOK (forms 20) (0 ||| 2^18) 0 q10Shape20T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape20T1OK,q10Shape20T52OK⟩


theorem q10Shape20_cover (b : Nat→Bool) (H : Ranked (adj (forms 20) b)) :
    ∃ u v w z t,Effective (adj (forms 20) b) (adj (forms 20) b) u v w z t :=
  checked_fastTree (forms 20) b H q10Shape20T0 q10Shape20T0OK

#print axioms q10Shape20_cover
end Graffiti384b.Q10
