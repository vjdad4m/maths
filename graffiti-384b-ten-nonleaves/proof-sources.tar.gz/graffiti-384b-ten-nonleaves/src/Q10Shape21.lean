import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape21T6 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape21T6OK : fastTreeOK (forms 21) 0 264241152 q10Shape21T6=true := by decide

private def q10Shape21T12 : Tree := (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 12 (.tip (.cover 0 1 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))))) (.tip (.cover 0 3 4 5 9))) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 2 4 5 9))) (.tip (.cover 0 2 4 5 8))))) (.tip (.cover 0 1 5 8 9)))))
private theorem q10Shape21T12OK : fastTreeOK (forms 21) 134217728 130041368 q10Shape21T12=true := by decide

private def q10Shape21T13 : Tree := (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 12 (.tip (.cover 0 1 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))))) (.tip (.cover 0 3 4 5 9))) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 2 4 5 9))) (.tip (.cover 0 2 4 5 8)))))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape21T13OK : fastTreeOK (forms 21) 134234112 130024984 q10Shape21T13=true := by decide

private def q10Shape21T11 : Tree := .split 14 q10Shape21T12 q10Shape21T13
private theorem q10Shape21T11OK : fastTreeOK (forms 21) 134217728 130024984 q10Shape21T11=true := by
  change (fastTreeOK (forms 21) 134217728 (130024984 ||| 2^14) q10Shape21T12 &&
    fastTreeOK (forms 21) (134217728 ||| 2^14) 130024984 q10Shape21T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T12OK,q10Shape21T13OK⟩

private def q10Shape21T16 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.split 17 (.tip (.cover 0 1 5 7 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 3 4 5 9))) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))))) (.tip (.cover 0 1 5 8 9))))
private theorem q10Shape21T16OK : fastTreeOK (forms 21) 134218752 130073112 q10Shape21T16=true := by decide

private def q10Shape21T17 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 5 7 8))) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 1 5 8 9))))
private theorem q10Shape21T17OK : fastTreeOK (forms 21) 134251520 130040344 q10Shape21T17=true := by decide

private def q10Shape21T15 : Tree := .split 15 q10Shape21T16 q10Shape21T17
private theorem q10Shape21T15OK : fastTreeOK (forms 21) 134218752 130040344 q10Shape21T15=true := by
  change (fastTreeOK (forms 21) 134218752 (130040344 ||| 2^15) q10Shape21T16 &&
    fastTreeOK (forms 21) (134218752 ||| 2^15) 130040344 q10Shape21T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T16OK,q10Shape21T17OK⟩

private def q10Shape21T20 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 3 4 5 9))) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))))) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 4 7 9))))
private theorem q10Shape21T20OK : fastTreeOK (forms 21) 134235136 130318872 q10Shape21T20=true := by decide

private def q10Shape21T21 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T21OK : fastTreeOK (forms 21) 134497280 130056728 q10Shape21T21=true := by decide

private def q10Shape21T19 : Tree := .split 18 q10Shape21T20 q10Shape21T21
private theorem q10Shape21T19OK : fastTreeOK (forms 21) 134235136 130056728 q10Shape21T19=true := by
  change (fastTreeOK (forms 21) 134235136 (130056728 ||| 2^18) q10Shape21T20 &&
    fastTreeOK (forms 21) (134235136 ||| 2^18) 130056728 q10Shape21T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T20OK,q10Shape21T21OK⟩

private def q10Shape21T22 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape21T22OK : fastTreeOK (forms 21) 134267904 130023960 q10Shape21T22=true := by decide

private def q10Shape21T18 : Tree := .split 15 q10Shape21T19 q10Shape21T22
private theorem q10Shape21T18OK : fastTreeOK (forms 21) 134235136 130023960 q10Shape21T18=true := by
  change (fastTreeOK (forms 21) 134235136 (130023960 ||| 2^15) q10Shape21T19 &&
    fastTreeOK (forms 21) (134235136 ||| 2^15) 130023960 q10Shape21T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T19OK,q10Shape21T22OK⟩

private def q10Shape21T14 : Tree := .split 14 q10Shape21T15 q10Shape21T18
private theorem q10Shape21T14OK : fastTreeOK (forms 21) 134218752 130023960 q10Shape21T14=true := by
  change (fastTreeOK (forms 21) 134218752 (130023960 ||| 2^14) q10Shape21T15 &&
    fastTreeOK (forms 21) (134218752 ||| 2^14) 130023960 q10Shape21T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T15OK,q10Shape21T18OK⟩

private def q10Shape21T10 : Tree := .split 10 q10Shape21T11 q10Shape21T14
private theorem q10Shape21T10OK : fastTreeOK (forms 21) 134217728 130023960 q10Shape21T10=true := by
  change (fastTreeOK (forms 21) 134217728 (130023960 ||| 2^10) q10Shape21T11 &&
    fastTreeOK (forms 21) (134217728 ||| 2^10) 130023960 q10Shape21T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T11OK,q10Shape21T14OK⟩

private def q10Shape21T26 : Tree := (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 17 (.tip (.cover 0 1 5 6 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 3 4 5 9))) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9)))))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T26OK : fastTreeOK (forms 21) 134218240 130073624 q10Shape21T26=true := by decide

private def q10Shape21T29 : Tree := (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 3 4 5 9))) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9)))))
private theorem q10Shape21T29OK : fastTreeOK (forms 21) 134251008 130827288 q10Shape21T29=true := by decide

private def q10Shape21T30 : Tree := (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9)))
private theorem q10Shape21T30OK : fastTreeOK (forms 21) 134775296 130303000 q10Shape21T30=true := by decide

private def q10Shape21T28 : Tree := .split 19 q10Shape21T29 q10Shape21T30
private theorem q10Shape21T28OK : fastTreeOK (forms 21) 134251008 130303000 q10Shape21T28=true := by
  change (fastTreeOK (forms 21) 134251008 (130303000 ||| 2^19) q10Shape21T29 &&
    fastTreeOK (forms 21) (134251008 ||| 2^19) 130303000 q10Shape21T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T29OK,q10Shape21T30OK⟩

private def q10Shape21T31 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 4 6 8))) (.tip (.cover 0 2 4 6 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T31OK : fastTreeOK (forms 21) 134513152 130040856 q10Shape21T31=true := by decide

private def q10Shape21T27 : Tree := .split 18 q10Shape21T28 q10Shape21T31
private theorem q10Shape21T27OK : fastTreeOK (forms 21) 134251008 130040856 q10Shape21T27=true := by
  change (fastTreeOK (forms 21) 134251008 (130040856 ||| 2^18) q10Shape21T28 &&
    fastTreeOK (forms 21) (134251008 ||| 2^18) 130040856 q10Shape21T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T28OK,q10Shape21T31OK⟩

private def q10Shape21T25 : Tree := .split 15 q10Shape21T26 q10Shape21T27
private theorem q10Shape21T25OK : fastTreeOK (forms 21) 134218240 130040856 q10Shape21T25=true := by
  change (fastTreeOK (forms 21) 134218240 (130040856 ||| 2^15) q10Shape21T26 &&
    fastTreeOK (forms 21) (134218240 ||| 2^15) 130040856 q10Shape21T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T26OK,q10Shape21T27OK⟩

private def q10Shape21T32 : Tree := (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 5 6 8))) (.tip (.cover 0 2 5 6 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape21T32OK : fastTreeOK (forms 21) 134234624 130024472 q10Shape21T32=true := by decide

private def q10Shape21T24 : Tree := .split 14 q10Shape21T25 q10Shape21T32
private theorem q10Shape21T24OK : fastTreeOK (forms 21) 134218240 130024472 q10Shape21T24=true := by
  change (fastTreeOK (forms 21) 134218240 (130024472 ||| 2^14) q10Shape21T25 &&
    fastTreeOK (forms 21) (134218240 ||| 2^14) 130024472 q10Shape21T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T25OK,q10Shape21T32OK⟩

private def q10Shape21T33 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape21T33OK : fastTreeOK (forms 21) 134219264 130023448 q10Shape21T33=true := by decide

private def q10Shape21T23 : Tree := .split 10 q10Shape21T24 q10Shape21T33
private theorem q10Shape21T23OK : fastTreeOK (forms 21) 134218240 130023448 q10Shape21T23=true := by
  change (fastTreeOK (forms 21) 134218240 (130023448 ||| 2^10) q10Shape21T24 &&
    fastTreeOK (forms 21) (134218240 ||| 2^10) 130023448 q10Shape21T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T24OK,q10Shape21T33OK⟩

private def q10Shape21T9 : Tree := .split 9 q10Shape21T10 q10Shape21T23
private theorem q10Shape21T9OK : fastTreeOK (forms 21) 134217728 130023448 q10Shape21T9=true := by
  change (fastTreeOK (forms 21) 134217728 (130023448 ||| 2^9) q10Shape21T10 &&
    fastTreeOK (forms 21) (134217728 ||| 2^9) 130023448 q10Shape21T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T10OK,q10Shape21T23OK⟩

private def q10Shape21T38 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.split 17 (.tip (.cover 0 1 5 7 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))))) (.tip (.cover 0 2 4 5 9))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 8))))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9))))
private theorem q10Shape21T38OK : fastTreeOK (forms 21) 134217744 130074120 q10Shape21T38=true := by decide

private def q10Shape21T39 : Tree := (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9))))
private theorem q10Shape21T39OK : fastTreeOK (forms 21) 134250512 130041352 q10Shape21T39=true := by decide

private def q10Shape21T37 : Tree := .split 15 q10Shape21T38 q10Shape21T39
private theorem q10Shape21T37OK : fastTreeOK (forms 21) 134217744 130041352 q10Shape21T37=true := by
  change (fastTreeOK (forms 21) 134217744 (130041352 ||| 2^15) q10Shape21T38 &&
    fastTreeOK (forms 21) (134217744 ||| 2^15) 130041352 q10Shape21T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T38OK,q10Shape21T39OK⟩

private def q10Shape21T42 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 2 4 5 9))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 4 7 9))))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape21T42OK : fastTreeOK (forms 21) 134234128 130319880 q10Shape21T42=true := by decide

private def q10Shape21T43 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T43OK : fastTreeOK (forms 21) 134496272 130057736 q10Shape21T43=true := by decide

private def q10Shape21T41 : Tree := .split 18 q10Shape21T42 q10Shape21T43
private theorem q10Shape21T41OK : fastTreeOK (forms 21) 134234128 130057736 q10Shape21T41=true := by
  change (fastTreeOK (forms 21) 134234128 (130057736 ||| 2^18) q10Shape21T42 &&
    fastTreeOK (forms 21) (134234128 ||| 2^18) 130057736 q10Shape21T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T42OK,q10Shape21T43OK⟩

private def q10Shape21T44 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape21T44OK : fastTreeOK (forms 21) 134266896 130024968 q10Shape21T44=true := by decide

private def q10Shape21T40 : Tree := .split 15 q10Shape21T41 q10Shape21T44
private theorem q10Shape21T40OK : fastTreeOK (forms 21) 134234128 130024968 q10Shape21T40=true := by
  change (fastTreeOK (forms 21) 134234128 (130024968 ||| 2^15) q10Shape21T41 &&
    fastTreeOK (forms 21) (134234128 ||| 2^15) 130024968 q10Shape21T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T41OK,q10Shape21T44OK⟩

private def q10Shape21T36 : Tree := .split 14 q10Shape21T37 q10Shape21T40
private theorem q10Shape21T36OK : fastTreeOK (forms 21) 134217744 130024968 q10Shape21T36=true := by
  change (fastTreeOK (forms 21) 134217744 (130024968 ||| 2^14) q10Shape21T37 &&
    fastTreeOK (forms 21) (134217744 ||| 2^14) 130024968 q10Shape21T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T37OK,q10Shape21T40OK⟩

private def q10Shape21T45 : Tree := (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 4 5 7 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 5 7 8 9))) (.split 15 (.split 18 (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 4 5 7 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape21T45OK : fastTreeOK (forms 21) 134218768 130023944 q10Shape21T45=true := by decide

private def q10Shape21T35 : Tree := .split 10 q10Shape21T36 q10Shape21T45
private theorem q10Shape21T35OK : fastTreeOK (forms 21) 134217744 130023944 q10Shape21T35=true := by
  change (fastTreeOK (forms 21) 134217744 (130023944 ||| 2^10) q10Shape21T36 &&
    fastTreeOK (forms 21) (134217744 ||| 2^10) 130023944 q10Shape21T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T36OK,q10Shape21T45OK⟩

private def q10Shape21T50 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 2 3 5 9))) (.split 17 (.tip (.cover 0 2 3 5 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape21T50OK : fastTreeOK (forms 21) 134218256 130335752 q10Shape21T50=true := by decide

private def q10Shape21T51 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 2 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T51OK : fastTreeOK (forms 21) 134480400 130073608 q10Shape21T51=true := by decide

private def q10Shape21T49 : Tree := .split 18 q10Shape21T50 q10Shape21T51
private theorem q10Shape21T49OK : fastTreeOK (forms 21) 134218256 130073608 q10Shape21T49=true := by
  change (fastTreeOK (forms 21) 134218256 (130073608 ||| 2^18) q10Shape21T50 &&
    fastTreeOK (forms 21) (134218256 ||| 2^18) 130073608 q10Shape21T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T50OK,q10Shape21T51OK⟩

private def q10Shape21T52 : Tree := (.split 18 (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 3 4 5 8)))
private theorem q10Shape21T52OK : fastTreeOK (forms 21) 134251024 130040840 q10Shape21T52=true := by decide

private def q10Shape21T48 : Tree := .split 15 q10Shape21T49 q10Shape21T52
private theorem q10Shape21T48OK : fastTreeOK (forms 21) 134218256 130040840 q10Shape21T48=true := by
  change (fastTreeOK (forms 21) 134218256 (130040840 ||| 2^15) q10Shape21T49 &&
    fastTreeOK (forms 21) (134218256 ||| 2^15) 130040840 q10Shape21T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T49OK,q10Shape21T52OK⟩

private def q10Shape21T53 : Tree := (.split 15 (.split 18 (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 2 5 6 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape21T53OK : fastTreeOK (forms 21) 134234640 130024456 q10Shape21T53=true := by decide

private def q10Shape21T47 : Tree := .split 14 q10Shape21T48 q10Shape21T53
private theorem q10Shape21T47OK : fastTreeOK (forms 21) 134218256 130024456 q10Shape21T47=true := by
  change (fastTreeOK (forms 21) 134218256 (130024456 ||| 2^14) q10Shape21T48 &&
    fastTreeOK (forms 21) (134218256 ||| 2^14) 130024456 q10Shape21T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T48OK,q10Shape21T53OK⟩

private def q10Shape21T54 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape21T54OK : fastTreeOK (forms 21) 134219280 130023432 q10Shape21T54=true := by decide

private def q10Shape21T46 : Tree := .split 10 q10Shape21T47 q10Shape21T54
private theorem q10Shape21T46OK : fastTreeOK (forms 21) 134218256 130023432 q10Shape21T46=true := by
  change (fastTreeOK (forms 21) 134218256 (130023432 ||| 2^10) q10Shape21T47 &&
    fastTreeOK (forms 21) (134218256 ||| 2^10) 130023432 q10Shape21T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T47OK,q10Shape21T54OK⟩

private def q10Shape21T34 : Tree := .split 9 q10Shape21T35 q10Shape21T46
private theorem q10Shape21T34OK : fastTreeOK (forms 21) 134217744 130023432 q10Shape21T34=true := by
  change (fastTreeOK (forms 21) 134217744 (130023432 ||| 2^9) q10Shape21T35 &&
    fastTreeOK (forms 21) (134217744 ||| 2^9) 130023432 q10Shape21T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T35OK,q10Shape21T46OK⟩

private def q10Shape21T8 : Tree := .split 4 q10Shape21T9 q10Shape21T34
private theorem q10Shape21T8OK : fastTreeOK (forms 21) 134217728 130023432 q10Shape21T8=true := by
  change (fastTreeOK (forms 21) 134217728 (130023432 ||| 2^4) q10Shape21T9 &&
    fastTreeOK (forms 21) (134217728 ||| 2^4) 130023432 q10Shape21T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T9OK,q10Shape21T34OK⟩

private def q10Shape21T60 : Tree := (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 17 (.tip (.cover 0 1 5 6 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))))) (.tip (.cover 0 2 4 5 9))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 8))))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T60OK : fastTreeOK (forms 21) 134217736 130074128 q10Shape21T60=true := by decide

private def q10Shape21T62 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 2 4 5 9))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 6 9))))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 2 3 7 8))) (.tip (.cover 0 2 3 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape21T62OK : fastTreeOK (forms 21) 134250504 130303504 q10Shape21T62=true := by decide

private def q10Shape21T63 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 4 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T63OK : fastTreeOK (forms 21) 134512648 130041360 q10Shape21T63=true := by decide

private def q10Shape21T61 : Tree := .split 18 q10Shape21T62 q10Shape21T63
private theorem q10Shape21T61OK : fastTreeOK (forms 21) 134250504 130041360 q10Shape21T61=true := by
  change (fastTreeOK (forms 21) 134250504 (130041360 ||| 2^18) q10Shape21T62 &&
    fastTreeOK (forms 21) (134250504 ||| 2^18) 130041360 q10Shape21T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T62OK,q10Shape21T63OK⟩

private def q10Shape21T59 : Tree := .split 15 q10Shape21T60 q10Shape21T61
private theorem q10Shape21T59OK : fastTreeOK (forms 21) 134217736 130041360 q10Shape21T59=true := by
  change (fastTreeOK (forms 21) 134217736 (130041360 ||| 2^15) q10Shape21T60 &&
    fastTreeOK (forms 21) (134217736 ||| 2^15) 130041360 q10Shape21T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T60OK,q10Shape21T61OK⟩

private def q10Shape21T64 : Tree := (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 5 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape21T64OK : fastTreeOK (forms 21) 134234120 130024976 q10Shape21T64=true := by decide

private def q10Shape21T58 : Tree := .split 14 q10Shape21T59 q10Shape21T64
private theorem q10Shape21T58OK : fastTreeOK (forms 21) 134217736 130024976 q10Shape21T58=true := by
  change (fastTreeOK (forms 21) 134217736 (130024976 ||| 2^14) q10Shape21T59 &&
    fastTreeOK (forms 21) (134217736 ||| 2^14) 130024976 q10Shape21T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T59OK,q10Shape21T64OK⟩

private def q10Shape21T68 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.split 17 (.split 20 (.tip (.drop 7 8 9 (some 6) none none)) (.split 21 (.tip (.drop 7 8 9 (some 6) none none)) (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))))) (.tip (.cover 0 2 3 5 9))) (.split 17 (.tip (.cover 0 2 3 5 8)) (.split 20 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) (some 6))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape21T68OK : fastTreeOK (forms 21) 134218760 130335248 q10Shape21T68=true := by decide

private def q10Shape21T69 : Tree := (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 3 4 6 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape21T69OK : fastTreeOK (forms 21) 134480904 130073104 q10Shape21T69=true := by decide

private def q10Shape21T67 : Tree := .split 18 q10Shape21T68 q10Shape21T69
private theorem q10Shape21T67OK : fastTreeOK (forms 21) 134218760 130073104 q10Shape21T67=true := by
  change (fastTreeOK (forms 21) 134218760 (130073104 ||| 2^18) q10Shape21T68 &&
    fastTreeOK (forms 21) (134218760 ||| 2^18) 130073104 q10Shape21T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T68OK,q10Shape21T69OK⟩

private def q10Shape21T70 : Tree := (.split 18 (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 2 5 7 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 2 3 4 5 8)))
private theorem q10Shape21T70OK : fastTreeOK (forms 21) 134251528 130040336 q10Shape21T70=true := by decide

private def q10Shape21T66 : Tree := .split 15 q10Shape21T67 q10Shape21T70
private theorem q10Shape21T66OK : fastTreeOK (forms 21) 134218760 130040336 q10Shape21T66=true := by
  change (fastTreeOK (forms 21) 134218760 (130040336 ||| 2^15) q10Shape21T67 &&
    fastTreeOK (forms 21) (134218760 ||| 2^15) 130040336 q10Shape21T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T67OK,q10Shape21T70OK⟩

private def q10Shape21T71 : Tree := (.split 15 (.split 18 (.split 19 (.split 5 (.split 6 (.split 11 (.split 12 (.split 16 (.tip (.cover 0 3 5 6 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 1 4 8 9)))
private theorem q10Shape21T71OK : fastTreeOK (forms 21) 134235144 130023952 q10Shape21T71=true := by decide

private def q10Shape21T65 : Tree := .split 14 q10Shape21T66 q10Shape21T71
private theorem q10Shape21T65OK : fastTreeOK (forms 21) 134218760 130023952 q10Shape21T65=true := by
  change (fastTreeOK (forms 21) 134218760 (130023952 ||| 2^14) q10Shape21T66 &&
    fastTreeOK (forms 21) (134218760 ||| 2^14) 130023952 q10Shape21T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T66OK,q10Shape21T71OK⟩

private def q10Shape21T57 : Tree := .split 10 q10Shape21T58 q10Shape21T65
private theorem q10Shape21T57OK : fastTreeOK (forms 21) 134217736 130023952 q10Shape21T57=true := by
  change (fastTreeOK (forms 21) 134217736 (130023952 ||| 2^10) q10Shape21T58 &&
    fastTreeOK (forms 21) (134217736 ||| 2^10) 130023952 q10Shape21T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T58OK,q10Shape21T65OK⟩

private def q10Shape21T72 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 5 (.split 6 (.split 11 (.tip (.cover 0 4 5 6 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 19 (.split 5 (.split 6 (.split 11 (.tip (.cover 0 4 5 6 9)) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 2 3 4 5 8))) (.tip (.cover 0 4 6 8 9)))) (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape21T72OK : fastTreeOK (forms 21) 134218248 130023440 q10Shape21T72=true := by decide

private def q10Shape21T56 : Tree := .split 9 q10Shape21T57 q10Shape21T72
private theorem q10Shape21T56OK : fastTreeOK (forms 21) 134217736 130023440 q10Shape21T56=true := by
  change (fastTreeOK (forms 21) 134217736 (130023440 ||| 2^9) q10Shape21T57 &&
    fastTreeOK (forms 21) (134217736 ||| 2^9) 130023440 q10Shape21T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T57OK,q10Shape21T72OK⟩

private def q10Shape21T73 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape21T73OK : fastTreeOK (forms 21) 134217752 130023424 q10Shape21T73=true := by decide

private def q10Shape21T55 : Tree := .split 4 q10Shape21T56 q10Shape21T73
private theorem q10Shape21T55OK : fastTreeOK (forms 21) 134217736 130023424 q10Shape21T55=true := by
  change (fastTreeOK (forms 21) 134217736 (130023424 ||| 2^4) q10Shape21T56 &&
    fastTreeOK (forms 21) (134217736 ||| 2^4) 130023424 q10Shape21T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T56OK,q10Shape21T73OK⟩

private def q10Shape21T7 : Tree := .split 3 q10Shape21T8 q10Shape21T55
private theorem q10Shape21T7OK : fastTreeOK (forms 21) 134217728 130023424 q10Shape21T7=true := by
  change (fastTreeOK (forms 21) 134217728 (130023424 ||| 2^3) q10Shape21T8 &&
    fastTreeOK (forms 21) (134217728 ||| 2^3) 130023424 q10Shape21T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T8OK,q10Shape21T55OK⟩

private def q10Shape21T5 : Tree := .split 27 q10Shape21T6 q10Shape21T7
private theorem q10Shape21T5OK : fastTreeOK (forms 21) 0 130023424 q10Shape21T5=true := by
  change (fastTreeOK (forms 21) 0 (130023424 ||| 2^27) q10Shape21T6 &&
    fastTreeOK (forms 21) (0 ||| 2^27) 130023424 q10Shape21T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T6OK,q10Shape21T7OK⟩

private def q10Shape21T74 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape21T74OK : fastTreeOK (forms 21) 67108864 62914560 q10Shape21T74=true := by decide

private def q10Shape21T4 : Tree := .split 26 q10Shape21T5 q10Shape21T74
private theorem q10Shape21T4OK : fastTreeOK (forms 21) 0 62914560 q10Shape21T4=true := by
  change (fastTreeOK (forms 21) 0 (62914560 ||| 2^26) q10Shape21T5 &&
    fastTreeOK (forms 21) (0 ||| 2^26) 62914560 q10Shape21T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T5OK,q10Shape21T74OK⟩

private def q10Shape21T75 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape21T75OK : fastTreeOK (forms 21) 33554432 29360128 q10Shape21T75=true := by decide

private def q10Shape21T3 : Tree := .split 25 q10Shape21T4 q10Shape21T75
private theorem q10Shape21T3OK : fastTreeOK (forms 21) 0 29360128 q10Shape21T3=true := by
  change (fastTreeOK (forms 21) 0 (29360128 ||| 2^25) q10Shape21T4 &&
    fastTreeOK (forms 21) (0 ||| 2^25) 29360128 q10Shape21T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T4OK,q10Shape21T75OK⟩

private def q10Shape21T76 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape21T76OK : fastTreeOK (forms 21) 16777216 12582912 q10Shape21T76=true := by decide

private def q10Shape21T2 : Tree := .split 24 q10Shape21T3 q10Shape21T76
private theorem q10Shape21T2OK : fastTreeOK (forms 21) 0 12582912 q10Shape21T2=true := by
  change (fastTreeOK (forms 21) 0 (12582912 ||| 2^24) q10Shape21T3 &&
    fastTreeOK (forms 21) (0 ||| 2^24) 12582912 q10Shape21T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T3OK,q10Shape21T76OK⟩

private def q10Shape21T77 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape21T77OK : fastTreeOK (forms 21) 8388608 4194304 q10Shape21T77=true := by decide

private def q10Shape21T1 : Tree := .split 23 q10Shape21T2 q10Shape21T77
private theorem q10Shape21T1OK : fastTreeOK (forms 21) 0 4194304 q10Shape21T1=true := by
  change (fastTreeOK (forms 21) 0 (4194304 ||| 2^23) q10Shape21T2 &&
    fastTreeOK (forms 21) (0 ||| 2^23) 4194304 q10Shape21T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T2OK,q10Shape21T77OK⟩

private def q10Shape21T78 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape21T78OK : fastTreeOK (forms 21) 4194304 0 q10Shape21T78=true := by decide

private def q10Shape21T0 : Tree := .split 22 q10Shape21T1 q10Shape21T78
private theorem q10Shape21T0OK : fastTreeOK (forms 21) 0 0 q10Shape21T0=true := by
  change (fastTreeOK (forms 21) 0 (0 ||| 2^22) q10Shape21T1 &&
    fastTreeOK (forms 21) (0 ||| 2^22) 0 q10Shape21T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape21T1OK,q10Shape21T78OK⟩


theorem q10Shape21_cover (b : Nat→Bool) (H : Ranked (adj (forms 21) b)) :
    ∃ u v w z t,Effective (adj (forms 21) b) (adj (forms 21) b) u v w z t :=
  checked_fastTree (forms 21) b H q10Shape21T0 q10Shape21T0OK

#print axioms q10Shape21_cover
end Graffiti384b.Q10
