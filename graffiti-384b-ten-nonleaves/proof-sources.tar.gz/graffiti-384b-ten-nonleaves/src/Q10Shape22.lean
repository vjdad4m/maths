import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape22T10 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T10OK : fastTreeOK (forms 22) 0 268173312 q10Shape22T10=true := by decide

private def q10Shape22T13 : Tree := (.split 11 (.split 16 (.tip (.cover 0 1 5 6 7)) (.split 13 (.split 14 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 7)))) (.split 16 (.split 8 (.split 9 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 9))))
private theorem q10Shape22T13OK : fastTreeOK (forms 22) 67108864 201064544 q10Shape22T13=true := by decide

private def q10Shape22T14 : Tree := (.split 4 (.split 10 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 7)) (.split 12 (.split 8 (.split 9 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 5 6 8 9)))) (.split 16 (.split 17 (.split 8 (.split 9 (.tip (.cover 0 2 4 7 8)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T14OK : fastTreeOK (forms 22) 67108928 201064480 q10Shape22T14=true := by decide

private def q10Shape22T12 : Tree := .split 6 q10Shape22T13 q10Shape22T14
private theorem q10Shape22T12OK : fastTreeOK (forms 22) 67108864 201064480 q10Shape22T12=true := by
  change (fastTreeOK (forms 22) 67108864 (201064480 ||| 2^6) q10Shape22T13 &&
    fastTreeOK (forms 22) (67108864 ||| 2^6) 201064480 q10Shape22T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T13OK,q10Shape22T14OK⟩

private def q10Shape22T15 : Tree := (.split 11 (.split 16 (.split 2 (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 9)))
private theorem q10Shape22T15OK : fastTreeOK (forms 22) 67108896 201064448 q10Shape22T15=true := by decide

private def q10Shape22T11 : Tree := .split 5 q10Shape22T12 q10Shape22T15
private theorem q10Shape22T11OK : fastTreeOK (forms 22) 67108864 201064448 q10Shape22T11=true := by
  change (fastTreeOK (forms 22) 67108864 (201064448 ||| 2^5) q10Shape22T12 &&
    fastTreeOK (forms 22) (67108864 ||| 2^5) 201064448 q10Shape22T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T12OK,q10Shape22T15OK⟩

private def q10Shape22T9 : Tree := .split 26 q10Shape22T10 q10Shape22T11
private theorem q10Shape22T9OK : fastTreeOK (forms 22) 0 201064448 q10Shape22T9=true := by
  change (fastTreeOK (forms 22) 0 (201064448 ||| 2^26) q10Shape22T10 &&
    fastTreeOK (forms 22) (0 ||| 2^26) 201064448 q10Shape22T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T10OK,q10Shape22T11OK⟩

private def q10Shape22T20 : Tree := (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 13 (.split 14 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 7)))) (.split 17 (.split 8 (.split 9 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 8))))
private theorem q10Shape22T20OK : fastTreeOK (forms 22) 33554432 234621024 q10Shape22T20=true := by decide

private def q10Shape22T21 : Tree := (.split 4 (.split 10 (.split 15 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 2 (.split 3 (.tip (.cover 0 1 3 4 7)) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 0 2 6 8 9)))) (.split 17 (.split 8 (.split 9 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T21OK : fastTreeOK (forms 22) 33556480 234618976 q10Shape22T21=true := by decide

private def q10Shape22T19 : Tree := .split 11 q10Shape22T20 q10Shape22T21
private theorem q10Shape22T19OK : fastTreeOK (forms 22) 33554432 234618976 q10Shape22T19=true := by
  change (fastTreeOK (forms 22) 33554432 (234618976 ||| 2^11) q10Shape22T20 &&
    fastTreeOK (forms 22) (33554432 ||| 2^11) 234618976 q10Shape22T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T20OK,q10Shape22T21OK⟩

private def q10Shape22T22 : Tree := (.split 12 (.split 17 (.split 2 (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape22T22OK : fastTreeOK (forms 22) 33554496 234618912 q10Shape22T22=true := by decide

private def q10Shape22T18 : Tree := .split 6 q10Shape22T19 q10Shape22T22
private theorem q10Shape22T18OK : fastTreeOK (forms 22) 33554432 234618912 q10Shape22T18=true := by
  change (fastTreeOK (forms 22) 33554432 (234618912 ||| 2^6) q10Shape22T19 &&
    fastTreeOK (forms 22) (33554432 ||| 2^6) 234618912 q10Shape22T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T19OK,q10Shape22T22OK⟩

private def q10Shape22T26 : Tree := (.split 11 (.split 15 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 8 (.split 9 (.tip (.cover 0 1 2 4 7)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 3 6 8 9)))) (.split 16 (.split 17 (.split 8 (.split 9 (.tip (.cover 0 2 4 7 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 5 6 8 9)))) (.tip (.cover 0 1 2 3 4))) (.split 16 (.split 17 (.split 12 (.tip (.cover 0 1 5 6 7)) (.split 8 (.split 9 (.tip (.cover 0 2 4 7 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7)))) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 5 6 8 9))))
private theorem q10Shape22T26OK : fastTreeOK (forms 22) 33554464 234619984 q10Shape22T26=true := by decide

private def q10Shape22T27 : Tree := (.split 12 (.split 17 (.split 2 (.split 3 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))
private theorem q10Shape22T27OK : fastTreeOK (forms 22) 33554528 234619920 q10Shape22T27=true := by decide

private def q10Shape22T25 : Tree := .split 6 q10Shape22T26 q10Shape22T27
private theorem q10Shape22T25OK : fastTreeOK (forms 22) 33554464 234619920 q10Shape22T25=true := by
  change (fastTreeOK (forms 22) 33554464 (234619920 ||| 2^6) q10Shape22T26 &&
    fastTreeOK (forms 22) (33554464 ||| 2^6) 234619920 q10Shape22T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T26OK,q10Shape22T27OK⟩

private def q10Shape22T28 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T28OK : fastTreeOK (forms 22) 33555488 234618896 q10Shape22T28=true := by decide

private def q10Shape22T24 : Tree := .split 10 q10Shape22T25 q10Shape22T28
private theorem q10Shape22T24OK : fastTreeOK (forms 22) 33554464 234618896 q10Shape22T24=true := by
  change (fastTreeOK (forms 22) 33554464 (234618896 ||| 2^10) q10Shape22T25 &&
    fastTreeOK (forms 22) (33554464 ||| 2^10) 234618896 q10Shape22T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T25OK,q10Shape22T28OK⟩

private def q10Shape22T29 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T29OK : fastTreeOK (forms 22) 33554480 234618880 q10Shape22T29=true := by decide

private def q10Shape22T23 : Tree := .split 4 q10Shape22T24 q10Shape22T29
private theorem q10Shape22T23OK : fastTreeOK (forms 22) 33554464 234618880 q10Shape22T23=true := by
  change (fastTreeOK (forms 22) 33554464 (234618880 ||| 2^4) q10Shape22T24 &&
    fastTreeOK (forms 22) (33554464 ||| 2^4) 234618880 q10Shape22T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T24OK,q10Shape22T29OK⟩

private def q10Shape22T17 : Tree := .split 5 q10Shape22T18 q10Shape22T23
private theorem q10Shape22T17OK : fastTreeOK (forms 22) 33554432 234618880 q10Shape22T17=true := by
  change (fastTreeOK (forms 22) 33554432 (234618880 ||| 2^5) q10Shape22T18 &&
    fastTreeOK (forms 22) (33554432 ||| 2^5) 234618880 q10Shape22T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T18OK,q10Shape22T23OK⟩

private def q10Shape22T30 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T30OK : fastTreeOK (forms 22) 100663296 167510016 q10Shape22T30=true := by decide

private def q10Shape22T16 : Tree := .split 26 q10Shape22T17 q10Shape22T30
private theorem q10Shape22T16OK : fastTreeOK (forms 22) 33554432 167510016 q10Shape22T16=true := by
  change (fastTreeOK (forms 22) 33554432 (167510016 ||| 2^26) q10Shape22T17 &&
    fastTreeOK (forms 22) (33554432 ||| 2^26) 167510016 q10Shape22T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T17OK,q10Shape22T30OK⟩

private def q10Shape22T8 : Tree := .split 25 q10Shape22T9 q10Shape22T16
private theorem q10Shape22T8OK : fastTreeOK (forms 22) 0 167510016 q10Shape22T8=true := by
  change (fastTreeOK (forms 22) 0 (167510016 ||| 2^25) q10Shape22T9 &&
    fastTreeOK (forms 22) (0 ||| 2^25) 167510016 q10Shape22T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T9OK,q10Shape22T16OK⟩

private def q10Shape22T35 : Tree := (.split 11 (.split 16 (.tip (.cover 0 1 5 6 7)) (.split 13 (.split 15 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 6 7)))) (.split 16 (.split 8 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 9))))
private theorem q10Shape22T35OK : fastTreeOK (forms 22) 16777216 251396192 q10Shape22T35=true := by decide

private def q10Shape22T36 : Tree := (.split 3 (.split 9 (.split 14 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 7)) (.split 12 (.split 8 (.split 10 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.split 16 (.split 17 (.split 8 (.split 10 (.tip (.cover 0 2 4 6 8)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T36OK : fastTreeOK (forms 22) 16777280 251396128 q10Shape22T36=true := by decide

private def q10Shape22T34 : Tree := .split 6 q10Shape22T35 q10Shape22T36
private theorem q10Shape22T34OK : fastTreeOK (forms 22) 16777216 251396128 q10Shape22T34=true := by
  change (fastTreeOK (forms 22) 16777216 (251396128 ||| 2^6) q10Shape22T35 &&
    fastTreeOK (forms 22) (16777216 ||| 2^6) 251396128 q10Shape22T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T35OK,q10Shape22T36OK⟩

private def q10Shape22T37 : Tree := (.split 11 (.split 16 (.split 2 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 9)))
private theorem q10Shape22T37OK : fastTreeOK (forms 22) 16777248 251396096 q10Shape22T37=true := by decide

private def q10Shape22T33 : Tree := .split 5 q10Shape22T34 q10Shape22T37
private theorem q10Shape22T33OK : fastTreeOK (forms 22) 16777216 251396096 q10Shape22T33=true := by
  change (fastTreeOK (forms 22) 16777216 (251396096 ||| 2^5) q10Shape22T34 &&
    fastTreeOK (forms 22) (16777216 ||| 2^5) 251396096 q10Shape22T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T34OK,q10Shape22T37OK⟩

private def q10Shape22T38 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape22T38OK : fastTreeOK (forms 22) 83886080 184287232 q10Shape22T38=true := by decide

private def q10Shape22T32 : Tree := .split 26 q10Shape22T33 q10Shape22T38
private theorem q10Shape22T32OK : fastTreeOK (forms 22) 16777216 184287232 q10Shape22T32=true := by
  change (fastTreeOK (forms 22) 16777216 (184287232 ||| 2^26) q10Shape22T33 &&
    fastTreeOK (forms 22) (16777216 ||| 2^26) 184287232 q10Shape22T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T33OK,q10Shape22T38OK⟩

private def q10Shape22T39 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T39OK : fastTreeOK (forms 22) 50331648 150732800 q10Shape22T39=true := by decide

private def q10Shape22T31 : Tree := .split 25 q10Shape22T32 q10Shape22T39
private theorem q10Shape22T31OK : fastTreeOK (forms 22) 16777216 150732800 q10Shape22T31=true := by
  change (fastTreeOK (forms 22) 16777216 (150732800 ||| 2^25) q10Shape22T32 &&
    fastTreeOK (forms 22) (16777216 ||| 2^25) 150732800 q10Shape22T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T32OK,q10Shape22T39OK⟩

private def q10Shape22T7 : Tree := .split 24 q10Shape22T8 q10Shape22T31
private theorem q10Shape22T7OK : fastTreeOK (forms 22) 0 150732800 q10Shape22T7=true := by
  change (fastTreeOK (forms 22) 0 (150732800 ||| 2^24) q10Shape22T8 &&
    fastTreeOK (forms 22) (0 ||| 2^24) 150732800 q10Shape22T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T8OK,q10Shape22T31OK⟩

private def q10Shape22T46 : Tree := (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 13 (.split 15 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 6 7)))) (.split 17 (.split 8 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 8))))
private theorem q10Shape22T46OK : fastTreeOK (forms 22) 8388608 259786848 q10Shape22T46=true := by decide

private def q10Shape22T47 : Tree := (.split 3 (.split 9 (.split 14 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 2 (.split 4 (.tip (.cover 0 1 3 4 6)) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 17 (.split 8 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T47OK : fastTreeOK (forms 22) 8390656 259784800 q10Shape22T47=true := by decide

private def q10Shape22T45 : Tree := .split 11 q10Shape22T46 q10Shape22T47
private theorem q10Shape22T45OK : fastTreeOK (forms 22) 8388608 259784800 q10Shape22T45=true := by
  change (fastTreeOK (forms 22) 8388608 (259784800 ||| 2^11) q10Shape22T46 &&
    fastTreeOK (forms 22) (8388608 ||| 2^11) 259784800 q10Shape22T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T46OK,q10Shape22T47OK⟩

private def q10Shape22T48 : Tree := (.split 12 (.split 17 (.split 2 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape22T48OK : fastTreeOK (forms 22) 8388672 259784736 q10Shape22T48=true := by decide

private def q10Shape22T44 : Tree := .split 6 q10Shape22T45 q10Shape22T48
private theorem q10Shape22T44OK : fastTreeOK (forms 22) 8388608 259784736 q10Shape22T44=true := by
  change (fastTreeOK (forms 22) 8388608 (259784736 ||| 2^6) q10Shape22T45 &&
    fastTreeOK (forms 22) (8388608 ||| 2^6) 259784736 q10Shape22T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T45OK,q10Shape22T48OK⟩

private def q10Shape22T52 : Tree := (.split 14 (.split 11 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 8 (.split 10 (.tip (.cover 0 1 2 4 6)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 16 (.split 17 (.split 8 (.split 10 (.tip (.cover 0 2 4 6 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 5 7 8 9)))) (.split 16 (.split 17 (.split 12 (.tip (.cover 0 1 5 6 7)) (.split 8 (.split 10 (.tip (.cover 0 2 4 6 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7)))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9)))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T52OK : fastTreeOK (forms 22) 8388640 259785288 q10Shape22T52=true := by decide

private def q10Shape22T53 : Tree := (.split 12 (.split 17 (.split 2 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6)))
private theorem q10Shape22T53OK : fastTreeOK (forms 22) 8388704 259785224 q10Shape22T53=true := by decide

private def q10Shape22T51 : Tree := .split 6 q10Shape22T52 q10Shape22T53
private theorem q10Shape22T51OK : fastTreeOK (forms 22) 8388640 259785224 q10Shape22T51=true := by
  change (fastTreeOK (forms 22) 8388640 (259785224 ||| 2^6) q10Shape22T52 &&
    fastTreeOK (forms 22) (8388640 ||| 2^6) 259785224 q10Shape22T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T52OK,q10Shape22T53OK⟩

private def q10Shape22T54 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T54OK : fastTreeOK (forms 22) 8389152 259784712 q10Shape22T54=true := by decide

private def q10Shape22T50 : Tree := .split 9 q10Shape22T51 q10Shape22T54
private theorem q10Shape22T50OK : fastTreeOK (forms 22) 8388640 259784712 q10Shape22T50=true := by
  change (fastTreeOK (forms 22) 8388640 (259784712 ||| 2^9) q10Shape22T51 &&
    fastTreeOK (forms 22) (8388640 ||| 2^9) 259784712 q10Shape22T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T51OK,q10Shape22T54OK⟩

private def q10Shape22T55 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T55OK : fastTreeOK (forms 22) 8388648 259784704 q10Shape22T55=true := by decide

private def q10Shape22T49 : Tree := .split 3 q10Shape22T50 q10Shape22T55
private theorem q10Shape22T49OK : fastTreeOK (forms 22) 8388640 259784704 q10Shape22T49=true := by
  change (fastTreeOK (forms 22) 8388640 (259784704 ||| 2^3) q10Shape22T50 &&
    fastTreeOK (forms 22) (8388640 ||| 2^3) 259784704 q10Shape22T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T50OK,q10Shape22T55OK⟩

private def q10Shape22T43 : Tree := .split 5 q10Shape22T44 q10Shape22T49
private theorem q10Shape22T43OK : fastTreeOK (forms 22) 8388608 259784704 q10Shape22T43=true := by
  change (fastTreeOK (forms 22) 8388608 (259784704 ||| 2^5) q10Shape22T44 &&
    fastTreeOK (forms 22) (8388608 ||| 2^5) 259784704 q10Shape22T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T44OK,q10Shape22T49OK⟩

private def q10Shape22T56 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T56OK : fastTreeOK (forms 22) 75497472 192675840 q10Shape22T56=true := by decide

private def q10Shape22T42 : Tree := .split 26 q10Shape22T43 q10Shape22T56
private theorem q10Shape22T42OK : fastTreeOK (forms 22) 8388608 192675840 q10Shape22T42=true := by
  change (fastTreeOK (forms 22) 8388608 (192675840 ||| 2^26) q10Shape22T43 &&
    fastTreeOK (forms 22) (8388608 ||| 2^26) 192675840 q10Shape22T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T43OK,q10Shape22T56OK⟩

private def q10Shape22T57 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape22T57OK : fastTreeOK (forms 22) 41943040 159121408 q10Shape22T57=true := by decide

private def q10Shape22T41 : Tree := .split 25 q10Shape22T42 q10Shape22T57
private theorem q10Shape22T41OK : fastTreeOK (forms 22) 8388608 159121408 q10Shape22T41=true := by
  change (fastTreeOK (forms 22) 8388608 (159121408 ||| 2^25) q10Shape22T42 &&
    fastTreeOK (forms 22) (8388608 ||| 2^25) 159121408 q10Shape22T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T42OK,q10Shape22T57OK⟩

private def q10Shape22T58 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T58OK : fastTreeOK (forms 22) 25165824 142344192 q10Shape22T58=true := by decide

private def q10Shape22T40 : Tree := .split 24 q10Shape22T41 q10Shape22T58
private theorem q10Shape22T40OK : fastTreeOK (forms 22) 8388608 142344192 q10Shape22T40=true := by
  change (fastTreeOK (forms 22) 8388608 (142344192 ||| 2^24) q10Shape22T41 &&
    fastTreeOK (forms 22) (8388608 ||| 2^24) 142344192 q10Shape22T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T41OK,q10Shape22T58OK⟩

private def q10Shape22T6 : Tree := .split 23 q10Shape22T7 q10Shape22T40
private theorem q10Shape22T6OK : fastTreeOK (forms 22) 0 142344192 q10Shape22T6=true := by
  change (fastTreeOK (forms 22) 0 (142344192 ||| 2^23) q10Shape22T7 &&
    fastTreeOK (forms 22) (0 ||| 2^23) 142344192 q10Shape22T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T7OK,q10Shape22T40OK⟩

private def q10Shape22T65 : Tree := (.split 11 (.split 16 (.tip (.cover 0 1 5 6 7)) (.split 14 (.split 15 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 7)))) (.split 16 (.split 9 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 2 3 4 9))))
private theorem q10Shape22T65OK : fastTreeOK (forms 22) 2097152 266076256 q10Shape22T65=true := by decide

private def q10Shape22T66 : Tree := (.split 2 (.split 8 (.split 13 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 7)) (.split 12 (.split 9 (.split 10 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 16 (.split 17 (.split 9 (.split 10 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T66OK : fastTreeOK (forms 22) 2097216 266076192 q10Shape22T66=true := by decide

private def q10Shape22T64 : Tree := .split 6 q10Shape22T65 q10Shape22T66
private theorem q10Shape22T64OK : fastTreeOK (forms 22) 2097152 266076192 q10Shape22T64=true := by
  change (fastTreeOK (forms 22) 2097152 (266076192 ||| 2^6) q10Shape22T65 &&
    fastTreeOK (forms 22) (2097152 ||| 2^6) 266076192 q10Shape22T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T65OK,q10Shape22T66OK⟩

private def q10Shape22T67 : Tree := (.split 11 (.split 16 (.split 3 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 9)))
private theorem q10Shape22T67OK : fastTreeOK (forms 22) 2097184 266076160 q10Shape22T67=true := by decide

private def q10Shape22T63 : Tree := .split 5 q10Shape22T64 q10Shape22T67
private theorem q10Shape22T63OK : fastTreeOK (forms 22) 2097152 266076160 q10Shape22T63=true := by
  change (fastTreeOK (forms 22) 2097152 (266076160 ||| 2^5) q10Shape22T64 &&
    fastTreeOK (forms 22) (2097152 ||| 2^5) 266076160 q10Shape22T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T64OK,q10Shape22T67OK⟩

private def q10Shape22T68 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape22T68OK : fastTreeOK (forms 22) 69206016 198967296 q10Shape22T68=true := by decide

private def q10Shape22T62 : Tree := .split 26 q10Shape22T63 q10Shape22T68
private theorem q10Shape22T62OK : fastTreeOK (forms 22) 2097152 198967296 q10Shape22T62=true := by
  change (fastTreeOK (forms 22) 2097152 (198967296 ||| 2^26) q10Shape22T63 &&
    fastTreeOK (forms 22) (2097152 ||| 2^26) 198967296 q10Shape22T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T63OK,q10Shape22T68OK⟩

private def q10Shape22T69 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T69OK : fastTreeOK (forms 22) 35651584 165412864 q10Shape22T69=true := by decide

private def q10Shape22T61 : Tree := .split 25 q10Shape22T62 q10Shape22T69
private theorem q10Shape22T61OK : fastTreeOK (forms 22) 2097152 165412864 q10Shape22T61=true := by
  change (fastTreeOK (forms 22) 2097152 (165412864 ||| 2^25) q10Shape22T62 &&
    fastTreeOK (forms 22) (2097152 ||| 2^25) 165412864 q10Shape22T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T62OK,q10Shape22T69OK⟩

private def q10Shape22T70 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape22T70OK : fastTreeOK (forms 22) 18874368 148635648 q10Shape22T70=true := by decide

private def q10Shape22T60 : Tree := .split 24 q10Shape22T61 q10Shape22T70
private theorem q10Shape22T60OK : fastTreeOK (forms 22) 2097152 148635648 q10Shape22T60=true := by
  change (fastTreeOK (forms 22) 2097152 (148635648 ||| 2^24) q10Shape22T61 &&
    fastTreeOK (forms 22) (2097152 ||| 2^24) 148635648 q10Shape22T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T61OK,q10Shape22T70OK⟩

private def q10Shape22T71 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T71OK : fastTreeOK (forms 22) 10485760 140247040 q10Shape22T71=true := by decide

private def q10Shape22T59 : Tree := .split 23 q10Shape22T60 q10Shape22T71
private theorem q10Shape22T59OK : fastTreeOK (forms 22) 2097152 140247040 q10Shape22T59=true := by
  change (fastTreeOK (forms 22) 2097152 (140247040 ||| 2^23) q10Shape22T60 &&
    fastTreeOK (forms 22) (2097152 ||| 2^23) 140247040 q10Shape22T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T60OK,q10Shape22T71OK⟩

private def q10Shape22T5 : Tree := .split 21 q10Shape22T6 q10Shape22T59
private theorem q10Shape22T5OK : fastTreeOK (forms 22) 0 140247040 q10Shape22T5=true := by
  change (fastTreeOK (forms 22) 0 (140247040 ||| 2^21) q10Shape22T6 &&
    fastTreeOK (forms 22) (0 ||| 2^21) 140247040 q10Shape22T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T6OK,q10Shape22T59OK⟩

private def q10Shape22T80 : Tree := (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 14 (.split 15 (.tip (.cover 0 2 3 8 9)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 7)))) (.split 17 (.split 9 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 2 3 4 8))))
private theorem q10Shape22T80OK : fastTreeOK (forms 22) 1048576 267126880 q10Shape22T80=true := by decide

private def q10Shape22T81 : Tree := (.split 2 (.split 8 (.split 13 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 17 (.split 9 (.split 10 (.tip (.cover 0 2 4 8 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 4)))
private theorem q10Shape22T81OK : fastTreeOK (forms 22) 1050624 267124832 q10Shape22T81=true := by decide

private def q10Shape22T79 : Tree := .split 11 q10Shape22T80 q10Shape22T81
private theorem q10Shape22T79OK : fastTreeOK (forms 22) 1048576 267124832 q10Shape22T79=true := by
  change (fastTreeOK (forms 22) 1048576 (267124832 ||| 2^11) q10Shape22T80 &&
    fastTreeOK (forms 22) (1048576 ||| 2^11) 267124832 q10Shape22T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T80OK,q10Shape22T81OK⟩

private def q10Shape22T82 : Tree := (.split 12 (.split 17 (.split 3 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8)))
private theorem q10Shape22T82OK : fastTreeOK (forms 22) 1048640 267124768 q10Shape22T82=true := by decide

private def q10Shape22T78 : Tree := .split 6 q10Shape22T79 q10Shape22T82
private theorem q10Shape22T78OK : fastTreeOK (forms 22) 1048576 267124768 q10Shape22T78=true := by
  change (fastTreeOK (forms 22) 1048576 (267124768 ||| 2^6) q10Shape22T79 &&
    fastTreeOK (forms 22) (1048576 ||| 2^6) 267124768 q10Shape22T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T79OK,q10Shape22T82OK⟩

private def q10Shape22T87 : Tree := (.split 11 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 9 (.split 10 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 16 (.split 17 (.split 9 (.split 10 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9)))) (.split 16 (.split 17 (.split 12 (.tip (.cover 0 1 5 6 7)) (.split 9 (.split 10 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7)))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))))
private theorem q10Shape22T87OK : fastTreeOK (forms 22) 1048608 267133252 q10Shape22T87=true := by decide

private def q10Shape22T88 : Tree := (.split 12 (.split 17 (.split 3 (.split 4 (.tip (.cover 0 3 4 8 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape22T88OK : fastTreeOK (forms 22) 1048672 267133188 q10Shape22T88=true := by decide

private def q10Shape22T86 : Tree := .split 6 q10Shape22T87 q10Shape22T88
private theorem q10Shape22T86OK : fastTreeOK (forms 22) 1048608 267133188 q10Shape22T86=true := by
  change (fastTreeOK (forms 22) 1048608 (267133188 ||| 2^6) q10Shape22T87 &&
    fastTreeOK (forms 22) (1048608 ||| 2^6) 267133188 q10Shape22T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T87OK,q10Shape22T88OK⟩

private def q10Shape22T89 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T89OK : fastTreeOK (forms 22) 1056800 267124996 q10Shape22T89=true := by decide

private def q10Shape22T85 : Tree := .split 13 q10Shape22T86 q10Shape22T89
private theorem q10Shape22T85OK : fastTreeOK (forms 22) 1048608 267124996 q10Shape22T85=true := by
  change (fastTreeOK (forms 22) 1048608 (267124996 ||| 2^13) q10Shape22T86 &&
    fastTreeOK (forms 22) (1048608 ||| 2^13) 267124996 q10Shape22T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T86OK,q10Shape22T89OK⟩

private def q10Shape22T90 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T90OK : fastTreeOK (forms 22) 1048864 267124740 q10Shape22T90=true := by decide

private def q10Shape22T84 : Tree := .split 8 q10Shape22T85 q10Shape22T90
private theorem q10Shape22T84OK : fastTreeOK (forms 22) 1048608 267124740 q10Shape22T84=true := by
  change (fastTreeOK (forms 22) 1048608 (267124740 ||| 2^8) q10Shape22T85 &&
    fastTreeOK (forms 22) (1048608 ||| 2^8) 267124740 q10Shape22T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T85OK,q10Shape22T90OK⟩

private def q10Shape22T91 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape22T91OK : fastTreeOK (forms 22) 1048612 267124736 q10Shape22T91=true := by decide

private def q10Shape22T83 : Tree := .split 2 q10Shape22T84 q10Shape22T91
private theorem q10Shape22T83OK : fastTreeOK (forms 22) 1048608 267124736 q10Shape22T83=true := by
  change (fastTreeOK (forms 22) 1048608 (267124736 ||| 2^2) q10Shape22T84 &&
    fastTreeOK (forms 22) (1048608 ||| 2^2) 267124736 q10Shape22T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T84OK,q10Shape22T91OK⟩

private def q10Shape22T77 : Tree := .split 5 q10Shape22T78 q10Shape22T83
private theorem q10Shape22T77OK : fastTreeOK (forms 22) 1048576 267124736 q10Shape22T77=true := by
  change (fastTreeOK (forms 22) 1048576 (267124736 ||| 2^5) q10Shape22T78 &&
    fastTreeOK (forms 22) (1048576 ||| 2^5) 267124736 q10Shape22T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T78OK,q10Shape22T83OK⟩

private def q10Shape22T92 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T92OK : fastTreeOK (forms 22) 68157440 200015872 q10Shape22T92=true := by decide

private def q10Shape22T76 : Tree := .split 26 q10Shape22T77 q10Shape22T92
private theorem q10Shape22T76OK : fastTreeOK (forms 22) 1048576 200015872 q10Shape22T76=true := by
  change (fastTreeOK (forms 22) 1048576 (200015872 ||| 2^26) q10Shape22T77 &&
    fastTreeOK (forms 22) (1048576 ||| 2^26) 200015872 q10Shape22T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T77OK,q10Shape22T92OK⟩

private def q10Shape22T93 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape22T93OK : fastTreeOK (forms 22) 34603008 166461440 q10Shape22T93=true := by decide

private def q10Shape22T75 : Tree := .split 25 q10Shape22T76 q10Shape22T93
private theorem q10Shape22T75OK : fastTreeOK (forms 22) 1048576 166461440 q10Shape22T75=true := by
  change (fastTreeOK (forms 22) 1048576 (166461440 ||| 2^25) q10Shape22T76 &&
    fastTreeOK (forms 22) (1048576 ||| 2^25) 166461440 q10Shape22T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T76OK,q10Shape22T93OK⟩

private def q10Shape22T94 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T94OK : fastTreeOK (forms 22) 17825792 149684224 q10Shape22T94=true := by decide

private def q10Shape22T74 : Tree := .split 24 q10Shape22T75 q10Shape22T94
private theorem q10Shape22T74OK : fastTreeOK (forms 22) 1048576 149684224 q10Shape22T74=true := by
  change (fastTreeOK (forms 22) 1048576 (149684224 ||| 2^24) q10Shape22T75 &&
    fastTreeOK (forms 22) (1048576 ||| 2^24) 149684224 q10Shape22T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T75OK,q10Shape22T94OK⟩

private def q10Shape22T95 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape22T95OK : fastTreeOK (forms 22) 9437184 141295616 q10Shape22T95=true := by decide

private def q10Shape22T73 : Tree := .split 23 q10Shape22T74 q10Shape22T95
private theorem q10Shape22T73OK : fastTreeOK (forms 22) 1048576 141295616 q10Shape22T73=true := by
  change (fastTreeOK (forms 22) 1048576 (141295616 ||| 2^23) q10Shape22T74 &&
    fastTreeOK (forms 22) (1048576 ||| 2^23) 141295616 q10Shape22T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T74OK,q10Shape22T95OK⟩

private def q10Shape22T96 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape22T96OK : fastTreeOK (forms 22) 3145728 139198464 q10Shape22T96=true := by decide

private def q10Shape22T72 : Tree := .split 21 q10Shape22T73 q10Shape22T96
private theorem q10Shape22T72OK : fastTreeOK (forms 22) 1048576 139198464 q10Shape22T72=true := by
  change (fastTreeOK (forms 22) 1048576 (139198464 ||| 2^21) q10Shape22T73 &&
    fastTreeOK (forms 22) (1048576 ||| 2^21) 139198464 q10Shape22T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T73OK,q10Shape22T96OK⟩

private def q10Shape22T4 : Tree := .split 20 q10Shape22T5 q10Shape22T72
private theorem q10Shape22T4OK : fastTreeOK (forms 22) 0 139198464 q10Shape22T4=true := by
  change (fastTreeOK (forms 22) 0 (139198464 ||| 2^20) q10Shape22T5 &&
    fastTreeOK (forms 22) (0 ||| 2^20) 139198464 q10Shape22T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T5OK,q10Shape22T72OK⟩

private def q10Shape22T105 : Tree := (.split 2 (.tip (.cover 0 1 3 4 6)) (.split 8 (.split 9 (.split 10 (.split 13 (.split 14 (.split 15 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 6)) (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 6 8 9)))) (.split 17 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 0 2 6 8 9)))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 7))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 7))) (.tip (.cover 0 1 3 4 6))))
private theorem q10Shape22T105OK : fastTreeOK (forms 22) 4194304 263979104 q10Shape22T105=true := by decide

private def q10Shape22T106 : Tree := (.split 2 (.split 12 (.split 17 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 8 (.tip (.cover 0 1 4 6 9)) (.tip (.cover 0 3 6 8 9)))) (.split 8 (.tip (.cover 0 4 6 8 9)) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 2 6 8)))
private theorem q10Shape22T106OK : fastTreeOK (forms 22) 4194368 263979040 q10Shape22T106=true := by decide

private def q10Shape22T104 : Tree := .split 6 q10Shape22T105 q10Shape22T106
private theorem q10Shape22T104OK : fastTreeOK (forms 22) 4194304 263979040 q10Shape22T104=true := by
  change (fastTreeOK (forms 22) 4194304 (263979040 ||| 2^6) q10Shape22T105 &&
    fastTreeOK (forms 22) (4194304 ||| 2^6) 263979040 q10Shape22T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T105OK,q10Shape22T106OK⟩

private def q10Shape22T107 : Tree := (.split 6 (.split 2 (.split 11 (.split 16 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 8)) (.split 8 (.tip (.cover 0 1 4 6 8)) (.tip (.cover 0 3 6 8 9)))) (.split 8 (.tip (.cover 0 4 6 8 9)) (.tip (.cover 0 1 3 6 8)))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 3 4 6))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 5 6)))
private theorem q10Shape22T107OK : fastTreeOK (forms 22) 4194336 263979008 q10Shape22T107=true := by decide

private def q10Shape22T103 : Tree := .split 5 q10Shape22T104 q10Shape22T107
private theorem q10Shape22T103OK : fastTreeOK (forms 22) 4194304 263979008 q10Shape22T103=true := by
  change (fastTreeOK (forms 22) 4194304 (263979008 ||| 2^5) q10Shape22T104 &&
    fastTreeOK (forms 22) (4194304 ||| 2^5) 263979008 q10Shape22T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T104OK,q10Shape22T107OK⟩

private def q10Shape22T108 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape22T108OK : fastTreeOK (forms 22) 71303168 196870144 q10Shape22T108=true := by decide

private def q10Shape22T102 : Tree := .split 26 q10Shape22T103 q10Shape22T108
private theorem q10Shape22T102OK : fastTreeOK (forms 22) 4194304 196870144 q10Shape22T102=true := by
  change (fastTreeOK (forms 22) 4194304 (196870144 ||| 2^26) q10Shape22T103 &&
    fastTreeOK (forms 22) (4194304 ||| 2^26) 196870144 q10Shape22T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T103OK,q10Shape22T108OK⟩

private def q10Shape22T109 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape22T109OK : fastTreeOK (forms 22) 37748736 163315712 q10Shape22T109=true := by decide

private def q10Shape22T101 : Tree := .split 25 q10Shape22T102 q10Shape22T109
private theorem q10Shape22T101OK : fastTreeOK (forms 22) 4194304 163315712 q10Shape22T101=true := by
  change (fastTreeOK (forms 22) 4194304 (163315712 ||| 2^25) q10Shape22T102 &&
    fastTreeOK (forms 22) (4194304 ||| 2^25) 163315712 q10Shape22T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T102OK,q10Shape22T109OK⟩

private def q10Shape22T110 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T110OK : fastTreeOK (forms 22) 20971520 146538496 q10Shape22T110=true := by decide

private def q10Shape22T100 : Tree := .split 24 q10Shape22T101 q10Shape22T110
private theorem q10Shape22T100OK : fastTreeOK (forms 22) 4194304 146538496 q10Shape22T100=true := by
  change (fastTreeOK (forms 22) 4194304 (146538496 ||| 2^24) q10Shape22T101 &&
    fastTreeOK (forms 22) (4194304 ||| 2^24) 146538496 q10Shape22T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T101OK,q10Shape22T110OK⟩

private def q10Shape22T111 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape22T111OK : fastTreeOK (forms 22) 12582912 138149888 q10Shape22T111=true := by decide

private def q10Shape22T99 : Tree := .split 23 q10Shape22T100 q10Shape22T111
private theorem q10Shape22T99OK : fastTreeOK (forms 22) 4194304 138149888 q10Shape22T99=true := by
  change (fastTreeOK (forms 22) 4194304 (138149888 ||| 2^23) q10Shape22T100 &&
    fastTreeOK (forms 22) (4194304 ||| 2^23) 138149888 q10Shape22T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T100OK,q10Shape22T111OK⟩

private def q10Shape22T112 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T112OK : fastTreeOK (forms 22) 6291456 136052736 q10Shape22T112=true := by decide

private def q10Shape22T98 : Tree := .split 21 q10Shape22T99 q10Shape22T112
private theorem q10Shape22T98OK : fastTreeOK (forms 22) 4194304 136052736 q10Shape22T98=true := by
  change (fastTreeOK (forms 22) 4194304 (136052736 ||| 2^21) q10Shape22T99 &&
    fastTreeOK (forms 22) (4194304 ||| 2^21) 136052736 q10Shape22T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T99OK,q10Shape22T112OK⟩

private def q10Shape22T113 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape22T113OK : fastTreeOK (forms 22) 5242880 135004160 q10Shape22T113=true := by decide

private def q10Shape22T97 : Tree := .split 20 q10Shape22T98 q10Shape22T113
private theorem q10Shape22T97OK : fastTreeOK (forms 22) 4194304 135004160 q10Shape22T97=true := by
  change (fastTreeOK (forms 22) 4194304 (135004160 ||| 2^20) q10Shape22T98 &&
    fastTreeOK (forms 22) (4194304 ||| 2^20) 135004160 q10Shape22T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T98OK,q10Shape22T113OK⟩

private def q10Shape22T3 : Tree := .split 22 q10Shape22T4 q10Shape22T97
private theorem q10Shape22T3OK : fastTreeOK (forms 22) 0 135004160 q10Shape22T3=true := by
  change (fastTreeOK (forms 22) 0 (135004160 ||| 2^22) q10Shape22T4 &&
    fastTreeOK (forms 22) (0 ||| 2^22) 135004160 q10Shape22T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T4OK,q10Shape22T97OK⟩

private def q10Shape22T123 : Tree := (.split 3 (.tip (.cover 0 1 3 4 5)) (.split 8 (.split 9 (.split 10 (.split 13 (.split 14 (.split 15 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 6)) (.split 16 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 5 8 9)))) (.split 17 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 1 3 4 6 7))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 1 3 4 6 7))))
private theorem q10Shape22T123OK : fastTreeOK (forms 22) 524288 267649120 q10Shape22T123=true := by decide

private def q10Shape22T124 : Tree := (.split 3 (.split 12 (.split 17 (.split 11 (.split 16 (.tip (.cover 0 1 5 6 9)) (.split 9 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 5 8 9)))) (.split 9 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 5 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 8)))
private theorem q10Shape22T124OK : fastTreeOK (forms 22) 524352 267649056 q10Shape22T124=true := by decide

private def q10Shape22T122 : Tree := .split 6 q10Shape22T123 q10Shape22T124
private theorem q10Shape22T122OK : fastTreeOK (forms 22) 524288 267649056 q10Shape22T122=true := by
  change (fastTreeOK (forms 22) 524288 (267649056 ||| 2^6) q10Shape22T123 &&
    fastTreeOK (forms 22) (524288 ||| 2^6) 267649056 q10Shape22T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T123OK,q10Shape22T124OK⟩

private def q10Shape22T125 : Tree := (.split 6 (.split 3 (.split 11 (.split 16 (.split 12 (.split 17 (.tip (.cover 0 1 5 6 8)) (.split 9 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 3 5 8 9)))) (.split 9 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 5 8)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 5 6)))
private theorem q10Shape22T125OK : fastTreeOK (forms 22) 524320 267649024 q10Shape22T125=true := by decide

private def q10Shape22T121 : Tree := .split 5 q10Shape22T122 q10Shape22T125
private theorem q10Shape22T121OK : fastTreeOK (forms 22) 524288 267649024 q10Shape22T121=true := by
  change (fastTreeOK (forms 22) 524288 (267649024 ||| 2^5) q10Shape22T122 &&
    fastTreeOK (forms 22) (524288 ||| 2^5) 267649024 q10Shape22T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T122OK,q10Shape22T125OK⟩

private def q10Shape22T126 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape22T126OK : fastTreeOK (forms 22) 67633152 200540160 q10Shape22T126=true := by decide

private def q10Shape22T120 : Tree := .split 26 q10Shape22T121 q10Shape22T126
private theorem q10Shape22T120OK : fastTreeOK (forms 22) 524288 200540160 q10Shape22T120=true := by
  change (fastTreeOK (forms 22) 524288 (200540160 ||| 2^26) q10Shape22T121 &&
    fastTreeOK (forms 22) (524288 ||| 2^26) 200540160 q10Shape22T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T121OK,q10Shape22T126OK⟩

private def q10Shape22T127 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape22T127OK : fastTreeOK (forms 22) 34078720 166985728 q10Shape22T127=true := by decide

private def q10Shape22T119 : Tree := .split 25 q10Shape22T120 q10Shape22T127
private theorem q10Shape22T119OK : fastTreeOK (forms 22) 524288 166985728 q10Shape22T119=true := by
  change (fastTreeOK (forms 22) 524288 (166985728 ||| 2^25) q10Shape22T120 &&
    fastTreeOK (forms 22) (524288 ||| 2^25) 166985728 q10Shape22T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T120OK,q10Shape22T127OK⟩

private def q10Shape22T128 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T128OK : fastTreeOK (forms 22) 17301504 150208512 q10Shape22T128=true := by decide

private def q10Shape22T118 : Tree := .split 24 q10Shape22T119 q10Shape22T128
private theorem q10Shape22T118OK : fastTreeOK (forms 22) 524288 150208512 q10Shape22T118=true := by
  change (fastTreeOK (forms 22) 524288 (150208512 ||| 2^24) q10Shape22T119 &&
    fastTreeOK (forms 22) (524288 ||| 2^24) 150208512 q10Shape22T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T119OK,q10Shape22T128OK⟩

private def q10Shape22T129 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape22T129OK : fastTreeOK (forms 22) 8912896 141819904 q10Shape22T129=true := by decide

private def q10Shape22T117 : Tree := .split 23 q10Shape22T118 q10Shape22T129
private theorem q10Shape22T117OK : fastTreeOK (forms 22) 524288 141819904 q10Shape22T117=true := by
  change (fastTreeOK (forms 22) 524288 (141819904 ||| 2^23) q10Shape22T118 &&
    fastTreeOK (forms 22) (524288 ||| 2^23) 141819904 q10Shape22T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T118OK,q10Shape22T129OK⟩

private def q10Shape22T130 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T130OK : fastTreeOK (forms 22) 2621440 139722752 q10Shape22T130=true := by decide

private def q10Shape22T116 : Tree := .split 21 q10Shape22T117 q10Shape22T130
private theorem q10Shape22T116OK : fastTreeOK (forms 22) 524288 139722752 q10Shape22T116=true := by
  change (fastTreeOK (forms 22) 524288 (139722752 ||| 2^21) q10Shape22T117 &&
    fastTreeOK (forms 22) (524288 ||| 2^21) 139722752 q10Shape22T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T117OK,q10Shape22T130OK⟩

private def q10Shape22T131 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape22T131OK : fastTreeOK (forms 22) 1572864 138674176 q10Shape22T131=true := by decide

private def q10Shape22T115 : Tree := .split 20 q10Shape22T116 q10Shape22T131
private theorem q10Shape22T115OK : fastTreeOK (forms 22) 524288 138674176 q10Shape22T115=true := by
  change (fastTreeOK (forms 22) 524288 (138674176 ||| 2^20) q10Shape22T116 &&
    fastTreeOK (forms 22) (524288 ||| 2^20) 138674176 q10Shape22T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T116OK,q10Shape22T131OK⟩

private def q10Shape22T132 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape22T132OK : fastTreeOK (forms 22) 4718592 134479872 q10Shape22T132=true := by decide

private def q10Shape22T114 : Tree := .split 22 q10Shape22T115 q10Shape22T132
private theorem q10Shape22T114OK : fastTreeOK (forms 22) 524288 134479872 q10Shape22T114=true := by
  change (fastTreeOK (forms 22) 524288 (134479872 ||| 2^22) q10Shape22T115 &&
    fastTreeOK (forms 22) (524288 ||| 2^22) 134479872 q10Shape22T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T115OK,q10Shape22T132OK⟩

private def q10Shape22T2 : Tree := .split 19 q10Shape22T3 q10Shape22T114
private theorem q10Shape22T2OK : fastTreeOK (forms 22) 0 134479872 q10Shape22T2=true := by
  change (fastTreeOK (forms 22) 0 (134479872 ||| 2^19) q10Shape22T3 &&
    fastTreeOK (forms 22) (0 ||| 2^19) 134479872 q10Shape22T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T3OK,q10Shape22T114OK⟩

private def q10Shape22T143 : Tree := (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 8 (.split 9 (.split 10 (.split 13 (.split 14 (.split 15 (.split 11 (.split 12 (.tip (.cover 0 1 4 5 7)) (.split 16 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 2 5 8 9)))) (.split 17 (.tip (.cover 0 1 3 5 7)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 1 3 4 5 7))) (.tip (.cover 1 3 4 6 7))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 1 3 4 5 7))) (.tip (.cover 1 3 4 6 7))))
private theorem q10Shape22T143OK : fastTreeOK (forms 22) 262144 267911264 q10Shape22T143=true := by decide

private def q10Shape22T144 : Tree := (.split 4 (.split 12 (.split 17 (.split 11 (.split 16 (.tip (.cover 0 1 5 7 9)) (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 5 8 9)))) (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 5 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 8)))
private theorem q10Shape22T144OK : fastTreeOK (forms 22) 262208 267911200 q10Shape22T144=true := by decide

private def q10Shape22T142 : Tree := .split 6 q10Shape22T143 q10Shape22T144
private theorem q10Shape22T142OK : fastTreeOK (forms 22) 262144 267911200 q10Shape22T142=true := by
  change (fastTreeOK (forms 22) 262144 (267911200 ||| 2^6) q10Shape22T143 &&
    fastTreeOK (forms 22) (262144 ||| 2^6) 267911200 q10Shape22T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T143OK,q10Shape22T144OK⟩

private def q10Shape22T145 : Tree := (.split 6 (.split 4 (.split 11 (.split 16 (.split 12 (.split 17 (.tip (.cover 0 1 5 7 8)) (.split 10 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 3 5 8 9)))) (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 5 8)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 5 7)))
private theorem q10Shape22T145OK : fastTreeOK (forms 22) 262176 267911168 q10Shape22T145=true := by decide

private def q10Shape22T141 : Tree := .split 5 q10Shape22T142 q10Shape22T145
private theorem q10Shape22T141OK : fastTreeOK (forms 22) 262144 267911168 q10Shape22T141=true := by
  change (fastTreeOK (forms 22) 262144 (267911168 ||| 2^5) q10Shape22T142 &&
    fastTreeOK (forms 22) (262144 ||| 2^5) 267911168 q10Shape22T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T142OK,q10Shape22T145OK⟩

private def q10Shape22T146 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape22T146OK : fastTreeOK (forms 22) 67371008 200802304 q10Shape22T146=true := by decide

private def q10Shape22T140 : Tree := .split 26 q10Shape22T141 q10Shape22T146
private theorem q10Shape22T140OK : fastTreeOK (forms 22) 262144 200802304 q10Shape22T140=true := by
  change (fastTreeOK (forms 22) 262144 (200802304 ||| 2^26) q10Shape22T141 &&
    fastTreeOK (forms 22) (262144 ||| 2^26) 200802304 q10Shape22T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T141OK,q10Shape22T146OK⟩

private def q10Shape22T147 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape22T147OK : fastTreeOK (forms 22) 33816576 167247872 q10Shape22T147=true := by decide

private def q10Shape22T139 : Tree := .split 25 q10Shape22T140 q10Shape22T147
private theorem q10Shape22T139OK : fastTreeOK (forms 22) 262144 167247872 q10Shape22T139=true := by
  change (fastTreeOK (forms 22) 262144 (167247872 ||| 2^25) q10Shape22T140 &&
    fastTreeOK (forms 22) (262144 ||| 2^25) 167247872 q10Shape22T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T140OK,q10Shape22T147OK⟩

private def q10Shape22T148 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape22T148OK : fastTreeOK (forms 22) 17039360 150470656 q10Shape22T148=true := by decide

private def q10Shape22T138 : Tree := .split 24 q10Shape22T139 q10Shape22T148
private theorem q10Shape22T138OK : fastTreeOK (forms 22) 262144 150470656 q10Shape22T138=true := by
  change (fastTreeOK (forms 22) 262144 (150470656 ||| 2^24) q10Shape22T139 &&
    fastTreeOK (forms 22) (262144 ||| 2^24) 150470656 q10Shape22T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T139OK,q10Shape22T148OK⟩

private def q10Shape22T149 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape22T149OK : fastTreeOK (forms 22) 8650752 142082048 q10Shape22T149=true := by decide

private def q10Shape22T137 : Tree := .split 23 q10Shape22T138 q10Shape22T149
private theorem q10Shape22T137OK : fastTreeOK (forms 22) 262144 142082048 q10Shape22T137=true := by
  change (fastTreeOK (forms 22) 262144 (142082048 ||| 2^23) q10Shape22T138 &&
    fastTreeOK (forms 22) (262144 ||| 2^23) 142082048 q10Shape22T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T138OK,q10Shape22T149OK⟩

private def q10Shape22T150 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape22T150OK : fastTreeOK (forms 22) 2359296 139984896 q10Shape22T150=true := by decide

private def q10Shape22T136 : Tree := .split 21 q10Shape22T137 q10Shape22T150
private theorem q10Shape22T136OK : fastTreeOK (forms 22) 262144 139984896 q10Shape22T136=true := by
  change (fastTreeOK (forms 22) 262144 (139984896 ||| 2^21) q10Shape22T137 &&
    fastTreeOK (forms 22) (262144 ||| 2^21) 139984896 q10Shape22T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T137OK,q10Shape22T150OK⟩

private def q10Shape22T151 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape22T151OK : fastTreeOK (forms 22) 1310720 138936320 q10Shape22T151=true := by decide

private def q10Shape22T135 : Tree := .split 20 q10Shape22T136 q10Shape22T151
private theorem q10Shape22T135OK : fastTreeOK (forms 22) 262144 138936320 q10Shape22T135=true := by
  change (fastTreeOK (forms 22) 262144 (138936320 ||| 2^20) q10Shape22T136 &&
    fastTreeOK (forms 22) (262144 ||| 2^20) 138936320 q10Shape22T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T136OK,q10Shape22T151OK⟩

private def q10Shape22T152 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape22T152OK : fastTreeOK (forms 22) 4456448 134742016 q10Shape22T152=true := by decide

private def q10Shape22T134 : Tree := .split 22 q10Shape22T135 q10Shape22T152
private theorem q10Shape22T134OK : fastTreeOK (forms 22) 262144 134742016 q10Shape22T134=true := by
  change (fastTreeOK (forms 22) 262144 (134742016 ||| 2^22) q10Shape22T135 &&
    fastTreeOK (forms 22) (262144 ||| 2^22) 134742016 q10Shape22T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T135OK,q10Shape22T152OK⟩

private def q10Shape22T153 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape22T153OK : fastTreeOK (forms 22) 786432 134217728 q10Shape22T153=true := by decide

private def q10Shape22T133 : Tree := .split 19 q10Shape22T134 q10Shape22T153
private theorem q10Shape22T133OK : fastTreeOK (forms 22) 262144 134217728 q10Shape22T133=true := by
  change (fastTreeOK (forms 22) 262144 (134217728 ||| 2^19) q10Shape22T134 &&
    fastTreeOK (forms 22) (262144 ||| 2^19) 134217728 q10Shape22T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T134OK,q10Shape22T153OK⟩

private def q10Shape22T1 : Tree := .split 18 q10Shape22T2 q10Shape22T133
private theorem q10Shape22T1OK : fastTreeOK (forms 22) 0 134217728 q10Shape22T1=true := by
  change (fastTreeOK (forms 22) 0 (134217728 ||| 2^18) q10Shape22T2 &&
    fastTreeOK (forms 22) (0 ||| 2^18) 134217728 q10Shape22T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T2OK,q10Shape22T133OK⟩

private def q10Shape22T167 : Tree := (.split 16 (.split 17 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 8)) (.split 10 (.split 15 (.tip (.drop 2 8 9 (some 1) (some 7) (some 7))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 8)))) (.split 4 (.split 9 (.split 14 (.tip (.drop 2 8 9 (some 1) (some 6) (some 6))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 2 5 8)))) (.split 3 (.split 4 (.split 8 (.split 13 (.tip (.drop 2 8 9 (some 1) (some 5) (some 5))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 3 4 8))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))))))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9)))
private theorem q10Shape22T167OK : fastTreeOK (forms 22) 134217728 133961824 q10Shape22T167=true := by decide

private def q10Shape22T168 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape22T168OK : fastTreeOK (forms 22) 134221824 133957728 q10Shape22T168=true := by decide

private def q10Shape22T166 : Tree := .split 12 q10Shape22T167 q10Shape22T168
private theorem q10Shape22T166OK : fastTreeOK (forms 22) 134217728 133957728 q10Shape22T166=true := by
  change (fastTreeOK (forms 22) 134217728 (133957728 ||| 2^12) q10Shape22T167 &&
    fastTreeOK (forms 22) (134217728 ||| 2^12) 133957728 q10Shape22T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T167OK,q10Shape22T168OK⟩

private def q10Shape22T169 : Tree := (.tip (.cover 0 2 3 4 9))
private theorem q10Shape22T169OK : fastTreeOK (forms 22) 134219776 133955680 q10Shape22T169=true := by decide

private def q10Shape22T165 : Tree := .split 11 q10Shape22T166 q10Shape22T169
private theorem q10Shape22T165OK : fastTreeOK (forms 22) 134217728 133955680 q10Shape22T165=true := by
  change (fastTreeOK (forms 22) 134217728 (133955680 ||| 2^11) q10Shape22T166 &&
    fastTreeOK (forms 22) (134217728 ||| 2^11) 133955680 q10Shape22T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T166OK,q10Shape22T169OK⟩

private def q10Shape22T170 : Tree := (.tip (.cover 0 2 3 4 8))
private theorem q10Shape22T170OK : fastTreeOK (forms 22) 134217792 133955616 q10Shape22T170=true := by decide

private def q10Shape22T164 : Tree := .split 6 q10Shape22T165 q10Shape22T170
private theorem q10Shape22T164OK : fastTreeOK (forms 22) 134217728 133955616 q10Shape22T164=true := by
  change (fastTreeOK (forms 22) 134217728 (133955616 ||| 2^6) q10Shape22T165 &&
    fastTreeOK (forms 22) (134217728 ||| 2^6) 133955616 q10Shape22T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T165OK,q10Shape22T170OK⟩

private def q10Shape22T171 : Tree := (.tip (.cover 0 2 3 4 9))
private theorem q10Shape22T171OK : fastTreeOK (forms 22) 134217760 133955584 q10Shape22T171=true := by decide

private def q10Shape22T163 : Tree := .split 5 q10Shape22T164 q10Shape22T171
private theorem q10Shape22T163OK : fastTreeOK (forms 22) 134217728 133955584 q10Shape22T163=true := by
  change (fastTreeOK (forms 22) 134217728 (133955584 ||| 2^5) q10Shape22T164 &&
    fastTreeOK (forms 22) (134217728 ||| 2^5) 133955584 q10Shape22T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T164OK,q10Shape22T171OK⟩

private def q10Shape22T172 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape22T172OK : fastTreeOK (forms 22) 201326592 66846720 q10Shape22T172=true := by decide

private def q10Shape22T162 : Tree := .split 26 q10Shape22T163 q10Shape22T172
private theorem q10Shape22T162OK : fastTreeOK (forms 22) 134217728 66846720 q10Shape22T162=true := by
  change (fastTreeOK (forms 22) 134217728 (66846720 ||| 2^26) q10Shape22T163 &&
    fastTreeOK (forms 22) (134217728 ||| 2^26) 66846720 q10Shape22T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T163OK,q10Shape22T172OK⟩

private def q10Shape22T173 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T173OK : fastTreeOK (forms 22) 167772160 33292288 q10Shape22T173=true := by decide

private def q10Shape22T161 : Tree := .split 25 q10Shape22T162 q10Shape22T173
private theorem q10Shape22T161OK : fastTreeOK (forms 22) 134217728 33292288 q10Shape22T161=true := by
  change (fastTreeOK (forms 22) 134217728 (33292288 ||| 2^25) q10Shape22T162 &&
    fastTreeOK (forms 22) (134217728 ||| 2^25) 33292288 q10Shape22T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T162OK,q10Shape22T173OK⟩

private def q10Shape22T174 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape22T174OK : fastTreeOK (forms 22) 150994944 16515072 q10Shape22T174=true := by decide

private def q10Shape22T160 : Tree := .split 24 q10Shape22T161 q10Shape22T174
private theorem q10Shape22T160OK : fastTreeOK (forms 22) 134217728 16515072 q10Shape22T160=true := by
  change (fastTreeOK (forms 22) 134217728 (16515072 ||| 2^24) q10Shape22T161 &&
    fastTreeOK (forms 22) (134217728 ||| 2^24) 16515072 q10Shape22T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T161OK,q10Shape22T174OK⟩

private def q10Shape22T175 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape22T175OK : fastTreeOK (forms 22) 142606336 8126464 q10Shape22T175=true := by decide

private def q10Shape22T159 : Tree := .split 23 q10Shape22T160 q10Shape22T175
private theorem q10Shape22T159OK : fastTreeOK (forms 22) 134217728 8126464 q10Shape22T159=true := by
  change (fastTreeOK (forms 22) 134217728 (8126464 ||| 2^23) q10Shape22T160 &&
    fastTreeOK (forms 22) (134217728 ||| 2^23) 8126464 q10Shape22T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T160OK,q10Shape22T175OK⟩

private def q10Shape22T176 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape22T176OK : fastTreeOK (forms 22) 136314880 6029312 q10Shape22T176=true := by decide

private def q10Shape22T158 : Tree := .split 21 q10Shape22T159 q10Shape22T176
private theorem q10Shape22T158OK : fastTreeOK (forms 22) 134217728 6029312 q10Shape22T158=true := by
  change (fastTreeOK (forms 22) 134217728 (6029312 ||| 2^21) q10Shape22T159 &&
    fastTreeOK (forms 22) (134217728 ||| 2^21) 6029312 q10Shape22T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T159OK,q10Shape22T176OK⟩

private def q10Shape22T177 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape22T177OK : fastTreeOK (forms 22) 135266304 4980736 q10Shape22T177=true := by decide

private def q10Shape22T157 : Tree := .split 20 q10Shape22T158 q10Shape22T177
private theorem q10Shape22T157OK : fastTreeOK (forms 22) 134217728 4980736 q10Shape22T157=true := by
  change (fastTreeOK (forms 22) 134217728 (4980736 ||| 2^20) q10Shape22T158 &&
    fastTreeOK (forms 22) (134217728 ||| 2^20) 4980736 q10Shape22T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T158OK,q10Shape22T177OK⟩

private def q10Shape22T178 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T178OK : fastTreeOK (forms 22) 138412032 786432 q10Shape22T178=true := by decide

private def q10Shape22T156 : Tree := .split 22 q10Shape22T157 q10Shape22T178
private theorem q10Shape22T156OK : fastTreeOK (forms 22) 134217728 786432 q10Shape22T156=true := by
  change (fastTreeOK (forms 22) 134217728 (786432 ||| 2^22) q10Shape22T157 &&
    fastTreeOK (forms 22) (134217728 ||| 2^22) 786432 q10Shape22T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T157OK,q10Shape22T178OK⟩

private def q10Shape22T179 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape22T179OK : fastTreeOK (forms 22) 134742016 262144 q10Shape22T179=true := by decide

private def q10Shape22T155 : Tree := .split 19 q10Shape22T156 q10Shape22T179
private theorem q10Shape22T155OK : fastTreeOK (forms 22) 134217728 262144 q10Shape22T155=true := by
  change (fastTreeOK (forms 22) 134217728 (262144 ||| 2^19) q10Shape22T156 &&
    fastTreeOK (forms 22) (134217728 ||| 2^19) 262144 q10Shape22T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T156OK,q10Shape22T179OK⟩

private def q10Shape22T180 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape22T180OK : fastTreeOK (forms 22) 134479872 0 q10Shape22T180=true := by decide

private def q10Shape22T154 : Tree := .split 18 q10Shape22T155 q10Shape22T180
private theorem q10Shape22T154OK : fastTreeOK (forms 22) 134217728 0 q10Shape22T154=true := by
  change (fastTreeOK (forms 22) 134217728 (0 ||| 2^18) q10Shape22T155 &&
    fastTreeOK (forms 22) (134217728 ||| 2^18) 0 q10Shape22T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T155OK,q10Shape22T180OK⟩

private def q10Shape22T0 : Tree := .split 27 q10Shape22T1 q10Shape22T154
private theorem q10Shape22T0OK : fastTreeOK (forms 22) 0 0 q10Shape22T0=true := by
  change (fastTreeOK (forms 22) 0 (0 ||| 2^27) q10Shape22T1 &&
    fastTreeOK (forms 22) (0 ||| 2^27) 0 q10Shape22T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape22T1OK,q10Shape22T154OK⟩


theorem q10Shape22_cover (b : Nat→Bool) (H : Ranked (adj (forms 22) b)) :
    ∃ u v w z t,Effective (adj (forms 22) b) (adj (forms 22) b) u v w z t :=
  checked_fastTree (forms 22) b H q10Shape22T0 q10Shape22T0OK

#print axioms q10Shape22_cover
end Graffiti384b.Q10
