import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape23T10 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape23T10OK : fastTreeOK (forms 23) 0 265357344 q10Shape23T10=true := by decide

private def q10Shape23T13 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 1 5 7 9)) (.split 15 (.split 18 (.split 19 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 8 9))))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 18 (.split 19 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape23T13OK : fastTreeOK (forms 23) 1048576 264308792 q10Shape23T13=true := by decide

private def q10Shape23T15 : Tree := (.split 10 (.split 14 (.tip (.cover 0 1 5 7 9)) (.split 15 (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 4 8 9))) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 2 3 4 8)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 8 9)))) (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 4 7 8 9))))
private theorem q10Shape23T15OK : fastTreeOK (forms 23) 1048592 264309288 q10Shape23T15=true := by decide

private def q10Shape23T16 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 1 4 5 6 7)) (.split 17 (.tip (.cover 0 1 3 5 7)) (.tip (.cover 0 2 3 4 8)))) (.split 12 (.split 17 (.tip (.cover 0 1 2 5 6)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape23T16OK : fastTreeOK (forms 23) 1049104 264308776 q10Shape23T16=true := by decide

private def q10Shape23T14 : Tree := .split 9 q10Shape23T15 q10Shape23T16
private theorem q10Shape23T14OK : fastTreeOK (forms 23) 1048592 264308776 q10Shape23T14=true := by
  change (fastTreeOK (forms 23) 1048592 (264308776 ||| 2^9) q10Shape23T15 &&
    fastTreeOK (forms 23) (1048592 ||| 2^9) 264308776 q10Shape23T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T15OK,q10Shape23T16OK⟩

private def q10Shape23T12 : Tree := .split 4 q10Shape23T13 q10Shape23T14
private theorem q10Shape23T12OK : fastTreeOK (forms 23) 1048576 264308776 q10Shape23T12=true := by
  change (fastTreeOK (forms 23) 1048576 (264308776 ||| 2^4) q10Shape23T13 &&
    fastTreeOK (forms 23) (1048576 ||| 2^4) 264308776 q10Shape23T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T13OK,q10Shape23T14OK⟩

private def q10Shape23T19 : Tree := (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 4 8 9))) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 2 3 4 8)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 4 5 9))) (.split 14 (.split 15 (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 1 4 5 6 7)) (.split 17 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 0 2 3 4 8)))) (.split 12 (.split 17 (.tip (.cover 0 1 2 5 7)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 3 6 8 9))))
private theorem q10Shape23T19OK : fastTreeOK (forms 23) 1048584 264309296 q10Shape23T19=true := by decide

private def q10Shape23T20 : Tree := (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape23T20OK : fastTreeOK (forms 23) 1049096 264308784 q10Shape23T20=true := by decide

private def q10Shape23T18 : Tree := .split 9 q10Shape23T19 q10Shape23T20
private theorem q10Shape23T18OK : fastTreeOK (forms 23) 1048584 264308784 q10Shape23T18=true := by
  change (fastTreeOK (forms 23) 1048584 (264308784 ||| 2^9) q10Shape23T19 &&
    fastTreeOK (forms 23) (1048584 ||| 2^9) 264308784 q10Shape23T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T19OK,q10Shape23T20OK⟩

private def q10Shape23T21 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape23T21OK : fastTreeOK (forms 23) 1048600 264308768 q10Shape23T21=true := by decide

private def q10Shape23T17 : Tree := .split 4 q10Shape23T18 q10Shape23T21
private theorem q10Shape23T17OK : fastTreeOK (forms 23) 1048584 264308768 q10Shape23T17=true := by
  change (fastTreeOK (forms 23) 1048584 (264308768 ||| 2^4) q10Shape23T18 &&
    fastTreeOK (forms 23) (1048584 ||| 2^4) 264308768 q10Shape23T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T18OK,q10Shape23T21OK⟩

private def q10Shape23T11 : Tree := .split 3 q10Shape23T12 q10Shape23T17
private theorem q10Shape23T11OK : fastTreeOK (forms 23) 1048576 264308768 q10Shape23T11=true := by
  change (fastTreeOK (forms 23) 1048576 (264308768 ||| 2^3) q10Shape23T12 &&
    fastTreeOK (forms 23) (1048576 ||| 2^3) 264308768 q10Shape23T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T12OK,q10Shape23T17OK⟩

private def q10Shape23T9 : Tree := .split 20 q10Shape23T10 q10Shape23T11
private theorem q10Shape23T9OK : fastTreeOK (forms 23) 0 264308768 q10Shape23T9=true := by
  change (fastTreeOK (forms 23) 0 (264308768 ||| 2^20) q10Shape23T10 &&
    fastTreeOK (forms 23) (0 ||| 2^20) 264308768 q10Shape23T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T10OK,q10Shape23T11OK⟩

private def q10Shape23T25 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 3 5 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape23T25OK : fastTreeOK (forms 23) 65536 265291832 q10Shape23T25=true := by decide

private def q10Shape23T27 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 6 (.split 12 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 5 8 9))) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 2 3 5 8)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.split 14 (.tip (.cover 0 5 7 8 9)) (.tip (.cover 0 1 4 7 9))))
private theorem q10Shape23T27OK : fastTreeOK (forms 23) 65552 265292328 q10Shape23T27=true := by decide

private def q10Shape23T28 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 1 4 5 6 7)) (.split 17 (.tip (.cover 0 2 3 5 8)) (.tip (.cover 0 1 3 4 7)))) (.split 12 (.split 17 (.tip (.cover 0 2 3 5 8)) (.tip (.cover 0 1 2 4 6))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape23T28OK : fastTreeOK (forms 23) 66064 265291816 q10Shape23T28=true := by decide

private def q10Shape23T26 : Tree := .split 9 q10Shape23T27 q10Shape23T28
private theorem q10Shape23T26OK : fastTreeOK (forms 23) 65552 265291816 q10Shape23T26=true := by
  change (fastTreeOK (forms 23) 65552 (265291816 ||| 2^9) q10Shape23T27 &&
    fastTreeOK (forms 23) (65552 ||| 2^9) 265291816 q10Shape23T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T27OK,q10Shape23T28OK⟩

private def q10Shape23T24 : Tree := .split 4 q10Shape23T25 q10Shape23T26
private theorem q10Shape23T24OK : fastTreeOK (forms 23) 65536 265291816 q10Shape23T24=true := by
  change (fastTreeOK (forms 23) 65536 (265291816 ||| 2^4) q10Shape23T25 &&
    fastTreeOK (forms 23) (65536 ||| 2^4) 265291816 q10Shape23T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T25OK,q10Shape23T26OK⟩

private def q10Shape23T31 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 6 (.split 12 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 5 8 9))) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 2 3 5 8))))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.split 14 (.split 15 (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 1 4 5 6 7)) (.split 17 (.tip (.cover 0 2 3 5 8)) (.tip (.cover 0 1 3 4 6)))) (.split 12 (.split 17 (.tip (.cover 0 2 3 5 8)) (.tip (.cover 0 1 2 4 7))) (.tip (.cover 0 1 2 3 8)))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))))
private theorem q10Shape23T31OK : fastTreeOK (forms 23) 65544 265292336 q10Shape23T31=true := by decide

private def q10Shape23T32 : Tree := (.split 10 (.split 14 (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape23T32OK : fastTreeOK (forms 23) 66056 265291824 q10Shape23T32=true := by decide

private def q10Shape23T30 : Tree := .split 9 q10Shape23T31 q10Shape23T32
private theorem q10Shape23T30OK : fastTreeOK (forms 23) 65544 265291824 q10Shape23T30=true := by
  change (fastTreeOK (forms 23) 65544 (265291824 ||| 2^9) q10Shape23T31 &&
    fastTreeOK (forms 23) (65544 ||| 2^9) 265291824 q10Shape23T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T31OK,q10Shape23T32OK⟩

private def q10Shape23T33 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape23T33OK : fastTreeOK (forms 23) 65560 265291808 q10Shape23T33=true := by decide

private def q10Shape23T29 : Tree := .split 4 q10Shape23T30 q10Shape23T33
private theorem q10Shape23T29OK : fastTreeOK (forms 23) 65544 265291808 q10Shape23T29=true := by
  change (fastTreeOK (forms 23) 65544 (265291808 ||| 2^4) q10Shape23T30 &&
    fastTreeOK (forms 23) (65544 ||| 2^4) 265291808 q10Shape23T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T30OK,q10Shape23T33OK⟩

private def q10Shape23T23 : Tree := .split 3 q10Shape23T24 q10Shape23T29
private theorem q10Shape23T23OK : fastTreeOK (forms 23) 65536 265291808 q10Shape23T23=true := by
  change (fastTreeOK (forms 23) 65536 (265291808 ||| 2^3) q10Shape23T24 &&
    fastTreeOK (forms 23) (65536 ||| 2^3) 265291808 q10Shape23T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T24OK,q10Shape23T29OK⟩

private def q10Shape23T34 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape23T34OK : fastTreeOK (forms 23) 1114112 264243232 q10Shape23T34=true := by decide

private def q10Shape23T22 : Tree := .split 20 q10Shape23T23 q10Shape23T34
private theorem q10Shape23T22OK : fastTreeOK (forms 23) 65536 264243232 q10Shape23T22=true := by
  change (fastTreeOK (forms 23) 65536 (264243232 ||| 2^20) q10Shape23T23 &&
    fastTreeOK (forms 23) (65536 ||| 2^20) 264243232 q10Shape23T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T23OK,q10Shape23T34OK⟩

private def q10Shape23T8 : Tree := .split 16 q10Shape23T9 q10Shape23T22
private theorem q10Shape23T8OK : fastTreeOK (forms 23) 0 264243232 q10Shape23T8=true := by
  change (fastTreeOK (forms 23) 0 (264243232 ||| 2^16) q10Shape23T9 &&
    fastTreeOK (forms 23) (0 ||| 2^16) 264243232 q10Shape23T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T9OK,q10Shape23T22OK⟩

private def q10Shape23T39 : Tree := (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 1 5 8 9))))) (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 6 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 4 5 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))
private theorem q10Shape23T39OK : fastTreeOK (forms 23) 2048 265355320 q10Shape23T39=true := by decide

private def q10Shape23T40 : Tree := (.split 9 (.split 10 (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 6 (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 17 (.tip (.cover 0 1 3 5 7)) (.tip (.cover 0 2 5 8 9)))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 5 7 8 9))) (.split 15 (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 17 (.tip (.cover 1 3 5 6 7)) (.tip (.cover 0 1 3 4 7)))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))
private theorem q10Shape23T40OK : fastTreeOK (forms 23) 2064 265355304 q10Shape23T40=true := by decide

private def q10Shape23T38 : Tree := .split 4 q10Shape23T39 q10Shape23T40
private theorem q10Shape23T38OK : fastTreeOK (forms 23) 2048 265355304 q10Shape23T38=true := by
  change (fastTreeOK (forms 23) 2048 (265355304 ||| 2^4) q10Shape23T39 &&
    fastTreeOK (forms 23) (2048 ||| 2^4) 265355304 q10Shape23T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T39OK,q10Shape23T40OK⟩

private def q10Shape23T41 : Tree := (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 6 (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 17 (.tip (.cover 0 1 3 5 6)) (.tip (.cover 0 2 5 8 9)))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 2 3 7))))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 19 (.split 6 (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 17 (.tip (.cover 1 3 5 6 7)) (.tip (.cover 0 1 3 4 6)))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 2 3 7)))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 4 6 8 9)))) (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape23T41OK : fastTreeOK (forms 23) 2056 265355296 q10Shape23T41=true := by decide

private def q10Shape23T37 : Tree := .split 3 q10Shape23T38 q10Shape23T41
private theorem q10Shape23T37OK : fastTreeOK (forms 23) 2048 265355296 q10Shape23T37=true := by
  change (fastTreeOK (forms 23) 2048 (265355296 ||| 2^3) q10Shape23T38 &&
    fastTreeOK (forms 23) (2048 ||| 2^3) 265355296 q10Shape23T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T38OK,q10Shape23T41OK⟩

private def q10Shape23T42 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape23T42OK : fastTreeOK (forms 23) 1050624 264306720 q10Shape23T42=true := by decide

private def q10Shape23T36 : Tree := .split 20 q10Shape23T37 q10Shape23T42
private theorem q10Shape23T36OK : fastTreeOK (forms 23) 2048 264306720 q10Shape23T36=true := by
  change (fastTreeOK (forms 23) 2048 (264306720 ||| 2^20) q10Shape23T37 &&
    fastTreeOK (forms 23) (2048 ||| 2^20) 264306720 q10Shape23T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T37OK,q10Shape23T42OK⟩

private def q10Shape23T43 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape23T43OK : fastTreeOK (forms 23) 67584 264241184 q10Shape23T43=true := by decide

private def q10Shape23T35 : Tree := .split 16 q10Shape23T36 q10Shape23T43
private theorem q10Shape23T35OK : fastTreeOK (forms 23) 2048 264241184 q10Shape23T35=true := by
  change (fastTreeOK (forms 23) 2048 (264241184 ||| 2^16) q10Shape23T36 &&
    fastTreeOK (forms 23) (2048 ||| 2^16) 264241184 q10Shape23T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T36OK,q10Shape23T43OK⟩

private def q10Shape23T7 : Tree := .split 11 q10Shape23T8 q10Shape23T35
private theorem q10Shape23T7OK : fastTreeOK (forms 23) 0 264241184 q10Shape23T7=true := by
  change (fastTreeOK (forms 23) 0 (264241184 ||| 2^11) q10Shape23T8 &&
    fastTreeOK (forms 23) (0 ||| 2^11) 264241184 q10Shape23T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T8OK,q10Shape23T35OK⟩

private def q10Shape23T51 : Tree := (.split 14 (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 8 9)))) (.tip (.cover 0 1 5 8 9))))) (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.tip (.cover 0 1 2 4 5)) (.tip (.cover 0 4 5 8 9))))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape23T51OK : fastTreeOK (forms 23) 32 265358872 q10Shape23T51=true := by decide

private def q10Shape23T52 : Tree := (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.split 17 (.tip (.cover 0 1 2 5 7)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 5 7 8 9))) (.split 15 (.split 18 (.split 19 (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.split 17 (.tip (.cover 1 2 5 6 7)) (.tip (.cover 0 1 2 4 7))) (.tip (.cover 0 1 2 3 6)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape23T52OK : fastTreeOK (forms 23) 1056 265357848 q10Shape23T52=true := by decide

private def q10Shape23T50 : Tree := .split 10 q10Shape23T51 q10Shape23T52
private theorem q10Shape23T50OK : fastTreeOK (forms 23) 32 265357848 q10Shape23T50=true := by
  change (fastTreeOK (forms 23) 32 (265357848 ||| 2^10) q10Shape23T51 &&
    fastTreeOK (forms 23) (32 ||| 2^10) 265357848 q10Shape23T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T51OK,q10Shape23T52OK⟩

private def q10Shape23T53 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.split 17 (.tip (.cover 0 1 2 5 6)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 1 2 3 7))))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 19 (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.split 17 (.tip (.cover 1 2 5 6 7)) (.tip (.cover 0 1 2 4 6))) (.tip (.cover 0 1 2 3 7)))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 4 6 8 9)))) (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape23T53OK : fastTreeOK (forms 23) 544 265357336 q10Shape23T53=true := by decide

private def q10Shape23T49 : Tree := .split 9 q10Shape23T50 q10Shape23T53
private theorem q10Shape23T49OK : fastTreeOK (forms 23) 32 265357336 q10Shape23T49=true := by
  change (fastTreeOK (forms 23) 32 (265357336 ||| 2^9) q10Shape23T50 &&
    fastTreeOK (forms 23) (32 ||| 2^9) 265357336 q10Shape23T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T50OK,q10Shape23T53OK⟩

private def q10Shape23T54 : Tree := (.tip (.cover 0 1 2 6 9))
private theorem q10Shape23T54OK : fastTreeOK (forms 23) 48 265357320 q10Shape23T54=true := by decide

private def q10Shape23T48 : Tree := .split 4 q10Shape23T49 q10Shape23T54
private theorem q10Shape23T48OK : fastTreeOK (forms 23) 32 265357320 q10Shape23T48=true := by
  change (fastTreeOK (forms 23) 32 (265357320 ||| 2^4) q10Shape23T49 &&
    fastTreeOK (forms 23) (32 ||| 2^4) 265357320 q10Shape23T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T49OK,q10Shape23T54OK⟩

private def q10Shape23T55 : Tree := (.tip (.cover 0 1 2 7 9))
private theorem q10Shape23T55OK : fastTreeOK (forms 23) 40 265357312 q10Shape23T55=true := by decide

private def q10Shape23T47 : Tree := .split 3 q10Shape23T48 q10Shape23T55
private theorem q10Shape23T47OK : fastTreeOK (forms 23) 32 265357312 q10Shape23T47=true := by
  change (fastTreeOK (forms 23) 32 (265357312 ||| 2^3) q10Shape23T48 &&
    fastTreeOK (forms 23) (32 ||| 2^3) 265357312 q10Shape23T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T48OK,q10Shape23T55OK⟩

private def q10Shape23T56 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape23T56OK : fastTreeOK (forms 23) 1048608 264308736 q10Shape23T56=true := by decide

private def q10Shape23T46 : Tree := .split 20 q10Shape23T47 q10Shape23T56
private theorem q10Shape23T46OK : fastTreeOK (forms 23) 32 264308736 q10Shape23T46=true := by
  change (fastTreeOK (forms 23) 32 (264308736 ||| 2^20) q10Shape23T47 &&
    fastTreeOK (forms 23) (32 ||| 2^20) 264308736 q10Shape23T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T47OK,q10Shape23T56OK⟩

private def q10Shape23T57 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape23T57OK : fastTreeOK (forms 23) 65568 264243200 q10Shape23T57=true := by decide

private def q10Shape23T45 : Tree := .split 16 q10Shape23T46 q10Shape23T57
private theorem q10Shape23T45OK : fastTreeOK (forms 23) 32 264243200 q10Shape23T45=true := by
  change (fastTreeOK (forms 23) 32 (264243200 ||| 2^16) q10Shape23T46 &&
    fastTreeOK (forms 23) (32 ||| 2^16) 264243200 q10Shape23T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T46OK,q10Shape23T57OK⟩

private def q10Shape23T58 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape23T58OK : fastTreeOK (forms 23) 2080 264241152 q10Shape23T58=true := by decide

private def q10Shape23T44 : Tree := .split 11 q10Shape23T45 q10Shape23T58
private theorem q10Shape23T44OK : fastTreeOK (forms 23) 32 264241152 q10Shape23T44=true := by
  change (fastTreeOK (forms 23) 32 (264241152 ||| 2^11) q10Shape23T45 &&
    fastTreeOK (forms 23) (32 ||| 2^11) 264241152 q10Shape23T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T45OK,q10Shape23T58OK⟩

private def q10Shape23T6 : Tree := .split 5 q10Shape23T7 q10Shape23T44
private theorem q10Shape23T6OK : fastTreeOK (forms 23) 0 264241152 q10Shape23T6=true := by
  change (fastTreeOK (forms 23) 0 (264241152 ||| 2^5) q10Shape23T7 &&
    fastTreeOK (forms 23) (0 ||| 2^5) 264241152 q10Shape23T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T7OK,q10Shape23T44OK⟩

private def q10Shape23T59 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape23T59OK : fastTreeOK (forms 23) 67108864 197132288 q10Shape23T59=true := by decide

private def q10Shape23T5 : Tree := .split 26 q10Shape23T6 q10Shape23T59
private theorem q10Shape23T5OK : fastTreeOK (forms 23) 0 197132288 q10Shape23T5=true := by
  change (fastTreeOK (forms 23) 0 (197132288 ||| 2^26) q10Shape23T6 &&
    fastTreeOK (forms 23) (0 ||| 2^26) 197132288 q10Shape23T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T6OK,q10Shape23T59OK⟩

private def q10Shape23T60 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape23T60OK : fastTreeOK (forms 23) 16777216 180355072 q10Shape23T60=true := by decide

private def q10Shape23T4 : Tree := .split 24 q10Shape23T5 q10Shape23T60
private theorem q10Shape23T4OK : fastTreeOK (forms 23) 0 180355072 q10Shape23T4=true := by
  change (fastTreeOK (forms 23) 0 (180355072 ||| 2^24) q10Shape23T5 &&
    fastTreeOK (forms 23) (0 ||| 2^24) 180355072 q10Shape23T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T5OK,q10Shape23T60OK⟩

private def q10Shape23T61 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape23T61OK : fastTreeOK (forms 23) 134217728 46137344 q10Shape23T61=true := by decide

private def q10Shape23T3 : Tree := .split 27 q10Shape23T4 q10Shape23T61
private theorem q10Shape23T3OK : fastTreeOK (forms 23) 0 46137344 q10Shape23T3=true := by
  change (fastTreeOK (forms 23) 0 (46137344 ||| 2^27) q10Shape23T4 &&
    fastTreeOK (forms 23) (0 ||| 2^27) 46137344 q10Shape23T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T4OK,q10Shape23T61OK⟩

private def q10Shape23T62 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape23T62OK : fastTreeOK (forms 23) 33554432 12582912 q10Shape23T62=true := by decide

private def q10Shape23T2 : Tree := .split 25 q10Shape23T3 q10Shape23T62
private theorem q10Shape23T2OK : fastTreeOK (forms 23) 0 12582912 q10Shape23T2=true := by
  change (fastTreeOK (forms 23) 0 (12582912 ||| 2^25) q10Shape23T3 &&
    fastTreeOK (forms 23) (0 ||| 2^25) 12582912 q10Shape23T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T3OK,q10Shape23T62OK⟩

private def q10Shape23T63 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape23T63OK : fastTreeOK (forms 23) 8388608 4194304 q10Shape23T63=true := by decide

private def q10Shape23T1 : Tree := .split 23 q10Shape23T2 q10Shape23T63
private theorem q10Shape23T1OK : fastTreeOK (forms 23) 0 4194304 q10Shape23T1=true := by
  change (fastTreeOK (forms 23) 0 (4194304 ||| 2^23) q10Shape23T2 &&
    fastTreeOK (forms 23) (0 ||| 2^23) 4194304 q10Shape23T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T2OK,q10Shape23T63OK⟩

private def q10Shape23T64 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape23T64OK : fastTreeOK (forms 23) 4194304 0 q10Shape23T64=true := by decide

private def q10Shape23T0 : Tree := .split 22 q10Shape23T1 q10Shape23T64
private theorem q10Shape23T0OK : fastTreeOK (forms 23) 0 0 q10Shape23T0=true := by
  change (fastTreeOK (forms 23) 0 (0 ||| 2^22) q10Shape23T1 &&
    fastTreeOK (forms 23) (0 ||| 2^22) 0 q10Shape23T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape23T1OK,q10Shape23T64OK⟩


theorem q10Shape23_cover (b : Nat→Bool) (H : Ranked (adj (forms 23) b)) :
    ∃ u v w z t,Effective (adj (forms 23) b) (adj (forms 23) b) u v w z t :=
  checked_fastTree (forms 23) b H q10Shape23T0 q10Shape23T0OK

#print axioms q10Shape23_cover
end Graffiti384b.Q10
