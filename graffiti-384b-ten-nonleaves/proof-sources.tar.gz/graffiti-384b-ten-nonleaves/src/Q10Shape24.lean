import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape24T10 : Tree := (.split 16 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 3 8 9)))) (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 1 5 6 7))))) (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 3 8 9)))) (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 8 9))))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 6 7))))
private theorem q10Shape24T10OK : fastTreeOK (forms 24) 0 264247392 q10Shape24T10=true := by decide

private def q10Shape24T12 : Tree := (.split 17 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 6 7)))))
private theorem q10Shape24T12OK : fastTreeOK (forms 24) 4096 264308832 q10Shape24T12=true := by decide

private def q10Shape24T13 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 8 9)))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 6 7)))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape24T13OK : fastTreeOK (forms 24) 69632 264243296 q10Shape24T13=true := by decide

private def q10Shape24T11 : Tree := .split 16 q10Shape24T12 q10Shape24T13
private theorem q10Shape24T11OK : fastTreeOK (forms 24) 4096 264243296 q10Shape24T11=true := by
  change (fastTreeOK (forms 24) 4096 (264243296 ||| 2^16) q10Shape24T12 &&
    fastTreeOK (forms 24) (4096 ||| 2^16) 264243296 q10Shape24T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T12OK,q10Shape24T13OK⟩

private def q10Shape24T9 : Tree := .split 12 q10Shape24T10 q10Shape24T11
private theorem q10Shape24T9OK : fastTreeOK (forms 24) 0 264243296 q10Shape24T9=true := by
  change (fastTreeOK (forms 24) 0 (264243296 ||| 2^12) q10Shape24T10 &&
    fastTreeOK (forms 24) (0 ||| 2^12) 264243296 q10Shape24T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T10OK,q10Shape24T11OK⟩

private def q10Shape24T17 : Tree := (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 8)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 8)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9))))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape24T17OK : fastTreeOK (forms 24) 2048 264441952 q10Shape24T17=true := by decide

private def q10Shape24T18 : Tree := (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9)))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape24T18OK : fastTreeOK (forms 24) 133120 264310880 q10Shape24T18=true := by decide

private def q10Shape24T16 : Tree := .split 17 q10Shape24T17 q10Shape24T18
private theorem q10Shape24T16OK : fastTreeOK (forms 24) 2048 264310880 q10Shape24T16=true := by
  change (fastTreeOK (forms 24) 2048 (264310880 ||| 2^17) q10Shape24T17 &&
    fastTreeOK (forms 24) (2048 ||| 2^17) 264310880 q10Shape24T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T17OK,q10Shape24T18OK⟩

private def q10Shape24T19 : Tree := (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape24T19OK : fastTreeOK (forms 24) 67584 264245344 q10Shape24T19=true := by decide

private def q10Shape24T15 : Tree := .split 16 q10Shape24T16 q10Shape24T19
private theorem q10Shape24T15OK : fastTreeOK (forms 24) 2048 264245344 q10Shape24T15=true := by
  change (fastTreeOK (forms 24) 2048 (264245344 ||| 2^16) q10Shape24T16 &&
    fastTreeOK (forms 24) (2048 ||| 2^16) 264245344 q10Shape24T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T16OK,q10Shape24T19OK⟩

private def q10Shape24T20 : Tree := (.tip (.cover 0 1 3 6 7))
private theorem q10Shape24T20OK : fastTreeOK (forms 24) 6144 264241248 q10Shape24T20=true := by decide

private def q10Shape24T14 : Tree := .split 12 q10Shape24T15 q10Shape24T20
private theorem q10Shape24T14OK : fastTreeOK (forms 24) 2048 264241248 q10Shape24T14=true := by
  change (fastTreeOK (forms 24) 2048 (264241248 ||| 2^12) q10Shape24T15 &&
    fastTreeOK (forms 24) (2048 ||| 2^12) 264241248 q10Shape24T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T15OK,q10Shape24T20OK⟩

private def q10Shape24T8 : Tree := .split 11 q10Shape24T9 q10Shape24T14
private theorem q10Shape24T8OK : fastTreeOK (forms 24) 0 264241248 q10Shape24T8=true := by
  change (fastTreeOK (forms 24) 0 (264241248 ||| 2^11) q10Shape24T9 &&
    fastTreeOK (forms 24) (0 ||| 2^11) 264241248 q10Shape24T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T9OK,q10Shape24T14OK⟩

private def q10Shape24T24 : Tree := (.split 17 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 3 4 8 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))))
private theorem q10Shape24T24OK : fastTreeOK (forms 24) 64 264312864 q10Shape24T24=true := by decide

private def q10Shape24T25 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape24T25OK : fastTreeOK (forms 24) 65600 264247328 q10Shape24T25=true := by decide

private def q10Shape24T23 : Tree := .split 16 q10Shape24T24 q10Shape24T25
private theorem q10Shape24T23OK : fastTreeOK (forms 24) 64 264247328 q10Shape24T23=true := by
  change (fastTreeOK (forms 24) 64 (264247328 ||| 2^16) q10Shape24T24 &&
    fastTreeOK (forms 24) (64 ||| 2^16) 264247328 q10Shape24T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T24OK,q10Shape24T25OK⟩

private def q10Shape24T26 : Tree := (.split 16 (.split 17 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.tip (.cover 1 5 6 7 9))) (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 1 4 6 7))))
private theorem q10Shape24T26OK : fastTreeOK (forms 24) 4160 264243232 q10Shape24T26=true := by decide

private def q10Shape24T22 : Tree := .split 12 q10Shape24T23 q10Shape24T26
private theorem q10Shape24T22OK : fastTreeOK (forms 24) 64 264243232 q10Shape24T22=true := by
  change (fastTreeOK (forms 24) 64 (264243232 ||| 2^12) q10Shape24T23 &&
    fastTreeOK (forms 24) (64 ||| 2^12) 264243232 q10Shape24T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T23OK,q10Shape24T26OK⟩

private def q10Shape24T29 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))))
private theorem q10Shape24T29OK : fastTreeOK (forms 24) 2112 264310816 q10Shape24T29=true := by decide

private def q10Shape24T30 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape24T30OK : fastTreeOK (forms 24) 67648 264245280 q10Shape24T30=true := by decide

private def q10Shape24T28 : Tree := .split 16 q10Shape24T29 q10Shape24T30
private theorem q10Shape24T28OK : fastTreeOK (forms 24) 2112 264245280 q10Shape24T28=true := by
  change (fastTreeOK (forms 24) 2112 (264245280 ||| 2^16) q10Shape24T29 &&
    fastTreeOK (forms 24) (2112 ||| 2^16) 264245280 q10Shape24T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T29OK,q10Shape24T30OK⟩

private def q10Shape24T31 : Tree := (.tip (.cover 0 1 3 6 7))
private theorem q10Shape24T31OK : fastTreeOK (forms 24) 6208 264241184 q10Shape24T31=true := by decide

private def q10Shape24T27 : Tree := .split 12 q10Shape24T28 q10Shape24T31
private theorem q10Shape24T27OK : fastTreeOK (forms 24) 2112 264241184 q10Shape24T27=true := by
  change (fastTreeOK (forms 24) 2112 (264241184 ||| 2^12) q10Shape24T28 &&
    fastTreeOK (forms 24) (2112 ||| 2^12) 264241184 q10Shape24T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T28OK,q10Shape24T31OK⟩

private def q10Shape24T21 : Tree := .split 11 q10Shape24T22 q10Shape24T27
private theorem q10Shape24T21OK : fastTreeOK (forms 24) 64 264241184 q10Shape24T21=true := by
  change (fastTreeOK (forms 24) 64 (264241184 ||| 2^11) q10Shape24T22 &&
    fastTreeOK (forms 24) (64 ||| 2^11) 264241184 q10Shape24T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T22OK,q10Shape24T27OK⟩

private def q10Shape24T7 : Tree := .split 6 q10Shape24T8 q10Shape24T21
private theorem q10Shape24T7OK : fastTreeOK (forms 24) 0 264241184 q10Shape24T7=true := by
  change (fastTreeOK (forms 24) 0 (264241184 ||| 2^6) q10Shape24T8 &&
    fastTreeOK (forms 24) (0 ||| 2^6) 264241184 q10Shape24T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T8OK,q10Shape24T21OK⟩

private def q10Shape24T37 : Tree := (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 14 (.tip (.cover 0 1 5 7 8)) (.tip (.cover 0 3 4 8 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 8)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape24T37OK : fastTreeOK (forms 24) 32 264443968 q10Shape24T37=true := by decide

private def q10Shape24T38 : Tree := (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 14 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 7 8)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.split 3 (.split 4 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape24T38OK : fastTreeOK (forms 24) 131104 264312896 q10Shape24T38=true := by decide

private def q10Shape24T36 : Tree := .split 17 q10Shape24T37 q10Shape24T38
private theorem q10Shape24T36OK : fastTreeOK (forms 24) 32 264312896 q10Shape24T36=true := by
  change (fastTreeOK (forms 24) 32 (264312896 ||| 2^17) q10Shape24T37 &&
    fastTreeOK (forms 24) (32 ||| 2^17) 264312896 q10Shape24T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T37OK,q10Shape24T38OK⟩

private def q10Shape24T39 : Tree := (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape24T39OK : fastTreeOK (forms 24) 65568 264247360 q10Shape24T39=true := by decide

private def q10Shape24T35 : Tree := .split 16 q10Shape24T36 q10Shape24T39
private theorem q10Shape24T35OK : fastTreeOK (forms 24) 32 264247360 q10Shape24T35=true := by
  change (fastTreeOK (forms 24) 32 (264247360 ||| 2^16) q10Shape24T36 &&
    fastTreeOK (forms 24) (32 ||| 2^16) 264247360 q10Shape24T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T36OK,q10Shape24T39OK⟩

private def q10Shape24T41 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.split 3 (.split 4 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))))
private theorem q10Shape24T41OK : fastTreeOK (forms 24) 4128 264308800 q10Shape24T41=true := by decide

private def q10Shape24T42 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape24T42OK : fastTreeOK (forms 24) 69664 264243264 q10Shape24T42=true := by decide

private def q10Shape24T40 : Tree := .split 16 q10Shape24T41 q10Shape24T42
private theorem q10Shape24T40OK : fastTreeOK (forms 24) 4128 264243264 q10Shape24T40=true := by
  change (fastTreeOK (forms 24) 4128 (264243264 ||| 2^16) q10Shape24T41 &&
    fastTreeOK (forms 24) (4128 ||| 2^16) 264243264 q10Shape24T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T41OK,q10Shape24T42OK⟩

private def q10Shape24T34 : Tree := .split 12 q10Shape24T35 q10Shape24T40
private theorem q10Shape24T34OK : fastTreeOK (forms 24) 32 264243264 q10Shape24T34=true := by
  change (fastTreeOK (forms 24) 32 (264243264 ||| 2^12) q10Shape24T35 &&
    fastTreeOK (forms 24) (32 ||| 2^12) 264243264 q10Shape24T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T35OK,q10Shape24T40OK⟩

private def q10Shape24T43 : Tree := (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 6 7))) (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9)))) (.split 17 (.tip (.cover 1 5 6 7 8)) (.tip (.cover 0 1 4 6 7)))) (.tip (.cover 0 1 3 6 7)))
private theorem q10Shape24T43OK : fastTreeOK (forms 24) 2080 264241216 q10Shape24T43=true := by decide

private def q10Shape24T33 : Tree := .split 11 q10Shape24T34 q10Shape24T43
private theorem q10Shape24T33OK : fastTreeOK (forms 24) 32 264241216 q10Shape24T33=true := by
  change (fastTreeOK (forms 24) 32 (264241216 ||| 2^11) q10Shape24T34 &&
    fastTreeOK (forms 24) (32 ||| 2^11) 264241216 q10Shape24T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T34OK,q10Shape24T43OK⟩

private def q10Shape24T44 : Tree := (.tip (.cover 0 1 2 6 7))
private theorem q10Shape24T44OK : fastTreeOK (forms 24) 96 264241152 q10Shape24T44=true := by decide

private def q10Shape24T32 : Tree := .split 6 q10Shape24T33 q10Shape24T44
private theorem q10Shape24T32OK : fastTreeOK (forms 24) 32 264241152 q10Shape24T32=true := by
  change (fastTreeOK (forms 24) 32 (264241152 ||| 2^6) q10Shape24T33 &&
    fastTreeOK (forms 24) (32 ||| 2^6) 264241152 q10Shape24T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T33OK,q10Shape24T44OK⟩

private def q10Shape24T6 : Tree := .split 5 q10Shape24T7 q10Shape24T32
private theorem q10Shape24T6OK : fastTreeOK (forms 24) 0 264241152 q10Shape24T6=true := by
  change (fastTreeOK (forms 24) 0 (264241152 ||| 2^5) q10Shape24T7 &&
    fastTreeOK (forms 24) (0 ||| 2^5) 264241152 q10Shape24T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T7OK,q10Shape24T32OK⟩

private def q10Shape24T45 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape24T45OK : fastTreeOK (forms 24) 67108864 197132288 q10Shape24T45=true := by decide

private def q10Shape24T5 : Tree := .split 26 q10Shape24T6 q10Shape24T45
private theorem q10Shape24T5OK : fastTreeOK (forms 24) 0 197132288 q10Shape24T5=true := by
  change (fastTreeOK (forms 24) 0 (197132288 ||| 2^26) q10Shape24T6 &&
    fastTreeOK (forms 24) (0 ||| 2^26) 197132288 q10Shape24T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T6OK,q10Shape24T45OK⟩

private def q10Shape24T46 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape24T46OK : fastTreeOK (forms 24) 33554432 163577856 q10Shape24T46=true := by decide

private def q10Shape24T4 : Tree := .split 25 q10Shape24T5 q10Shape24T46
private theorem q10Shape24T4OK : fastTreeOK (forms 24) 0 163577856 q10Shape24T4=true := by
  change (fastTreeOK (forms 24) 0 (163577856 ||| 2^25) q10Shape24T5 &&
    fastTreeOK (forms 24) (0 ||| 2^25) 163577856 q10Shape24T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T5OK,q10Shape24T46OK⟩

private def q10Shape24T47 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape24T47OK : fastTreeOK (forms 24) 16777216 146800640 q10Shape24T47=true := by decide

private def q10Shape24T3 : Tree := .split 24 q10Shape24T4 q10Shape24T47
private theorem q10Shape24T3OK : fastTreeOK (forms 24) 0 146800640 q10Shape24T3=true := by
  change (fastTreeOK (forms 24) 0 (146800640 ||| 2^24) q10Shape24T4 &&
    fastTreeOK (forms 24) (0 ||| 2^24) 146800640 q10Shape24T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T4OK,q10Shape24T47OK⟩

private def q10Shape24T48 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape24T48OK : fastTreeOK (forms 24) 8388608 138412032 q10Shape24T48=true := by decide

private def q10Shape24T2 : Tree := .split 23 q10Shape24T3 q10Shape24T48
private theorem q10Shape24T2OK : fastTreeOK (forms 24) 0 138412032 q10Shape24T2=true := by
  change (fastTreeOK (forms 24) 0 (138412032 ||| 2^23) q10Shape24T3 &&
    fastTreeOK (forms 24) (0 ||| 2^23) 138412032 q10Shape24T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T3OK,q10Shape24T48OK⟩

private def q10Shape24T49 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape24T49OK : fastTreeOK (forms 24) 4194304 134217728 q10Shape24T49=true := by decide

private def q10Shape24T1 : Tree := .split 22 q10Shape24T2 q10Shape24T49
private theorem q10Shape24T1OK : fastTreeOK (forms 24) 0 134217728 q10Shape24T1=true := by
  change (fastTreeOK (forms 24) 0 (134217728 ||| 2^22) q10Shape24T2 &&
    fastTreeOK (forms 24) (0 ||| 2^22) 134217728 q10Shape24T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T2OK,q10Shape24T49OK⟩

private def q10Shape24T50 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape24T50OK : fastTreeOK (forms 24) 134217728 0 q10Shape24T50=true := by decide

private def q10Shape24T0 : Tree := .split 27 q10Shape24T1 q10Shape24T50
private theorem q10Shape24T0OK : fastTreeOK (forms 24) 0 0 q10Shape24T0=true := by
  change (fastTreeOK (forms 24) 0 (0 ||| 2^27) q10Shape24T1 &&
    fastTreeOK (forms 24) (0 ||| 2^27) 0 q10Shape24T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape24T1OK,q10Shape24T50OK⟩


theorem q10Shape24_cover (b : Nat→Bool) (H : Ranked (adj (forms 24) b)) :
    ∃ u v w z t,Effective (adj (forms 24) b) (adj (forms 24) b) u v w z t :=
  checked_fastTree (forms 24) b H q10Shape24T0 q10Shape24T0OK

#print axioms q10Shape24_cover
end Graffiti384b.Q10
