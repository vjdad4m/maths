import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape25T5 : Tree := (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 21 (.split 24 (.split 26 (.split 27 (.split 6 (.split 12 (.split 17 (.tip (.small 1)) (.split 13 (.split 14 (.tip (.cover 0 2 3 7 9)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 6 7)))) (.split 17 (.split 8 (.split 9 (.tip (.cover 0 2 4 7 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 7)))) (.split 12 (.split 17 (.split 2 (.split 3 (.tip (.cover 0 3 4 7 9)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape25T5OK : fastTreeOK (forms 25) 0 14417920 q10Shape25T5=true := by decide

private def q10Shape25T6 : Tree := (.split 25 (.split 21 (.split 24 (.split 26 (.split 27 (.split 6 (.split 12 (.split 17 (.tip (.small 1)) (.split 13 (.split 15 (.tip (.cover 0 2 3 6 9)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 6 7)))) (.split 17 (.split 8 (.split 10 (.tip (.cover 0 2 4 6 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 2 3 4 6)))) (.split 12 (.split 17 (.split 2 (.split 4 (.tip (.cover 0 3 4 6 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape25T6OK : fastTreeOK (forms 25) 8388608 6029312 q10Shape25T6=true := by decide

private def q10Shape25T4 : Tree := .split 23 q10Shape25T5 q10Shape25T6
private theorem q10Shape25T4OK : fastTreeOK (forms 25) 0 6029312 q10Shape25T4=true := by
  change (fastTreeOK (forms 25) 0 (6029312 ||| 2^23) q10Shape25T5 &&
    fastTreeOK (forms 25) (0 ||| 2^23) 6029312 q10Shape25T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T5OK,q10Shape25T6OK⟩

private def q10Shape25T9 : Tree := (.split 21 (.split 24 (.split 26 (.split 27 (.split 6 (.split 12 (.split 17 (.tip (.small 1)) (.split 13 (.split 5 (.split 11 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 4 6 8)))) (.split 17 (.split 8 (.split 11 (.tip (.cover 0 2 4 6 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 2 3 4 6)))) (.split 12 (.split 17 (.split 2 (.split 5 (.tip (.cover 0 3 4 6 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape25T9OK : fastTreeOK (forms 25) 4194304 43778048 q10Shape25T9=true := by decide

private def q10Shape25T10 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape25T10OK : fastTreeOK (forms 25) 37748736 10223616 q10Shape25T10=true := by decide

private def q10Shape25T8 : Tree := .split 25 q10Shape25T9 q10Shape25T10
private theorem q10Shape25T8OK : fastTreeOK (forms 25) 4194304 10223616 q10Shape25T8=true := by
  change (fastTreeOK (forms 25) 4194304 (10223616 ||| 2^25) q10Shape25T9 &&
    fastTreeOK (forms 25) (4194304 ||| 2^25) 10223616 q10Shape25T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T9OK,q10Shape25T10OK⟩

private def q10Shape25T11 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape25T11OK : fastTreeOK (forms 25) 12582912 1835008 q10Shape25T11=true := by decide

private def q10Shape25T7 : Tree := .split 23 q10Shape25T8 q10Shape25T11
private theorem q10Shape25T7OK : fastTreeOK (forms 25) 4194304 1835008 q10Shape25T7=true := by
  change (fastTreeOK (forms 25) 4194304 (1835008 ||| 2^23) q10Shape25T8 &&
    fastTreeOK (forms 25) (4194304 ||| 2^23) 1835008 q10Shape25T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T8OK,q10Shape25T11OK⟩

private def q10Shape25T3 : Tree := .split 22 q10Shape25T4 q10Shape25T7
private theorem q10Shape25T3OK : fastTreeOK (forms 25) 0 1835008 q10Shape25T3=true := by
  change (fastTreeOK (forms 25) 0 (1835008 ||| 2^22) q10Shape25T4 &&
    fastTreeOK (forms 25) (0 ||| 2^22) 1835008 q10Shape25T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T4OK,q10Shape25T7OK⟩

private def q10Shape25T14 : Tree := (.split 25 (.split 21 (.split 24 (.split 26 (.split 27 (.split 6 (.split 12 (.split 17 (.tip (.small 1)) (.split 14 (.split 15 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 7)))) (.split 17 (.split 9 (.split 10 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 2 3 4 5)))) (.split 12 (.split 17 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape25T14OK : fastTreeOK (forms 25) 1048576 13369344 q10Shape25T14=true := by decide

private def q10Shape25T15 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape25T15OK : fastTreeOK (forms 25) 9437184 4980736 q10Shape25T15=true := by decide

private def q10Shape25T13 : Tree := .split 23 q10Shape25T14 q10Shape25T15
private theorem q10Shape25T13OK : fastTreeOK (forms 25) 1048576 4980736 q10Shape25T13=true := by
  change (fastTreeOK (forms 25) 1048576 (4980736 ||| 2^23) q10Shape25T14 &&
    fastTreeOK (forms 25) (1048576 ||| 2^23) 4980736 q10Shape25T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T14OK,q10Shape25T15OK⟩

private def q10Shape25T16 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape25T16OK : fastTreeOK (forms 25) 5242880 786432 q10Shape25T16=true := by decide

private def q10Shape25T12 : Tree := .split 22 q10Shape25T13 q10Shape25T16
private theorem q10Shape25T12OK : fastTreeOK (forms 25) 1048576 786432 q10Shape25T12=true := by
  change (fastTreeOK (forms 25) 1048576 (786432 ||| 2^22) q10Shape25T13 &&
    fastTreeOK (forms 25) (1048576 ||| 2^22) 786432 q10Shape25T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T13OK,q10Shape25T16OK⟩

private def q10Shape25T2 : Tree := .split 20 q10Shape25T3 q10Shape25T12
private theorem q10Shape25T2OK : fastTreeOK (forms 25) 0 786432 q10Shape25T2=true := by
  change (fastTreeOK (forms 25) 0 (786432 ||| 2^20) q10Shape25T3 &&
    fastTreeOK (forms 25) (0 ||| 2^20) 786432 q10Shape25T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T3OK,q10Shape25T12OK⟩

private def q10Shape25T21 : Tree := (.split 21 (.split 24 (.split 26 (.split 27 (.split 6 (.split 12 (.split 17 (.tip (.small 1)) (.split 14 (.split 5 (.split 11 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 1 4 5 8)))) (.split 17 (.split 9 (.split 11 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 5 6))) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 2 3 4 5)))) (.split 12 (.split 17 (.split 3 (.split 5 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 5 6))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 8)))
private theorem q10Shape25T21OK : fastTreeOK (forms 25) 524288 47448064 q10Shape25T21=true := by decide

private def q10Shape25T22 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape25T22OK : fastTreeOK (forms 25) 34078720 13893632 q10Shape25T22=true := by decide

private def q10Shape25T20 : Tree := .split 25 q10Shape25T21 q10Shape25T22
private theorem q10Shape25T20OK : fastTreeOK (forms 25) 524288 13893632 q10Shape25T20=true := by
  change (fastTreeOK (forms 25) 524288 (13893632 ||| 2^25) q10Shape25T21 &&
    fastTreeOK (forms 25) (524288 ||| 2^25) 13893632 q10Shape25T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T21OK,q10Shape25T22OK⟩

private def q10Shape25T23 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape25T23OK : fastTreeOK (forms 25) 8912896 5505024 q10Shape25T23=true := by decide

private def q10Shape25T19 : Tree := .split 23 q10Shape25T20 q10Shape25T23
private theorem q10Shape25T19OK : fastTreeOK (forms 25) 524288 5505024 q10Shape25T19=true := by
  change (fastTreeOK (forms 25) 524288 (5505024 ||| 2^23) q10Shape25T20 &&
    fastTreeOK (forms 25) (524288 ||| 2^23) 5505024 q10Shape25T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T20OK,q10Shape25T23OK⟩

private def q10Shape25T24 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape25T24OK : fastTreeOK (forms 25) 4718592 1310720 q10Shape25T24=true := by decide

private def q10Shape25T18 : Tree := .split 22 q10Shape25T19 q10Shape25T24
private theorem q10Shape25T18OK : fastTreeOK (forms 25) 524288 1310720 q10Shape25T18=true := by
  change (fastTreeOK (forms 25) 524288 (1310720 ||| 2^22) q10Shape25T19 &&
    fastTreeOK (forms 25) (524288 ||| 2^22) 1310720 q10Shape25T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T19OK,q10Shape25T24OK⟩

private def q10Shape25T25 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape25T25OK : fastTreeOK (forms 25) 1572864 262144 q10Shape25T25=true := by decide

private def q10Shape25T17 : Tree := .split 20 q10Shape25T18 q10Shape25T25
private theorem q10Shape25T17OK : fastTreeOK (forms 25) 524288 262144 q10Shape25T17=true := by
  change (fastTreeOK (forms 25) 524288 (262144 ||| 2^20) q10Shape25T18 &&
    fastTreeOK (forms 25) (524288 ||| 2^20) 262144 q10Shape25T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T18OK,q10Shape25T25OK⟩

private def q10Shape25T1 : Tree := .split 19 q10Shape25T2 q10Shape25T17
private theorem q10Shape25T1OK : fastTreeOK (forms 25) 0 262144 q10Shape25T1=true := by
  change (fastTreeOK (forms 25) 0 (262144 ||| 2^19) q10Shape25T2 &&
    fastTreeOK (forms 25) (0 ||| 2^19) 262144 q10Shape25T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T2OK,q10Shape25T17OK⟩

private def q10Shape25T36 : Tree := (.split 12 (.split 17 (.tip (.small 1)) (.split 2 (.split 15 (.split 16 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 4 5 8))) (.split 3 (.split 8 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 9 (.split 10 (.split 4 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 0 2 5 8 9))) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 9))))) (.split 17 (.split 10 (.split 11 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 5 7))) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 2 3 4 5))))
private theorem q10Shape25T36OK : fastTreeOK (forms 25) 262144 267911232 q10Shape25T36=true := by decide

private def q10Shape25T37 : Tree := (.split 12 (.split 17 (.split 4 (.split 5 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape25T37OK : fastTreeOK (forms 25) 262208 267911168 q10Shape25T37=true := by decide

private def q10Shape25T35 : Tree := .split 6 q10Shape25T36 q10Shape25T37
private theorem q10Shape25T35OK : fastTreeOK (forms 25) 262144 267911168 q10Shape25T35=true := by
  change (fastTreeOK (forms 25) 262144 (267911168 ||| 2^6) q10Shape25T36 &&
    fastTreeOK (forms 25) (262144 ||| 2^6) 267911168 q10Shape25T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T36OK,q10Shape25T37OK⟩

private def q10Shape25T38 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape25T38OK : fastTreeOK (forms 25) 134479872 133693440 q10Shape25T38=true := by decide

private def q10Shape25T34 : Tree := .split 27 q10Shape25T35 q10Shape25T38
private theorem q10Shape25T34OK : fastTreeOK (forms 25) 262144 133693440 q10Shape25T34=true := by
  change (fastTreeOK (forms 25) 262144 (133693440 ||| 2^27) q10Shape25T35 &&
    fastTreeOK (forms 25) (262144 ||| 2^27) 133693440 q10Shape25T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T35OK,q10Shape25T38OK⟩

private def q10Shape25T39 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape25T39OK : fastTreeOK (forms 25) 67371008 66584576 q10Shape25T39=true := by decide

private def q10Shape25T33 : Tree := .split 26 q10Shape25T34 q10Shape25T39
private theorem q10Shape25T33OK : fastTreeOK (forms 25) 262144 66584576 q10Shape25T33=true := by
  change (fastTreeOK (forms 25) 262144 (66584576 ||| 2^26) q10Shape25T34 &&
    fastTreeOK (forms 25) (262144 ||| 2^26) 66584576 q10Shape25T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T34OK,q10Shape25T39OK⟩

private def q10Shape25T40 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape25T40OK : fastTreeOK (forms 25) 17039360 49807360 q10Shape25T40=true := by decide

private def q10Shape25T32 : Tree := .split 24 q10Shape25T33 q10Shape25T40
private theorem q10Shape25T32OK : fastTreeOK (forms 25) 262144 49807360 q10Shape25T32=true := by
  change (fastTreeOK (forms 25) 262144 (49807360 ||| 2^24) q10Shape25T33 &&
    fastTreeOK (forms 25) (262144 ||| 2^24) 49807360 q10Shape25T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T33OK,q10Shape25T40OK⟩

private def q10Shape25T41 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape25T41OK : fastTreeOK (forms 25) 2359296 47710208 q10Shape25T41=true := by decide

private def q10Shape25T31 : Tree := .split 21 q10Shape25T32 q10Shape25T41
private theorem q10Shape25T31OK : fastTreeOK (forms 25) 262144 47710208 q10Shape25T31=true := by
  change (fastTreeOK (forms 25) 262144 (47710208 ||| 2^21) q10Shape25T32 &&
    fastTreeOK (forms 25) (262144 ||| 2^21) 47710208 q10Shape25T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T32OK,q10Shape25T41OK⟩

private def q10Shape25T42 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape25T42OK : fastTreeOK (forms 25) 33816576 14155776 q10Shape25T42=true := by decide

private def q10Shape25T30 : Tree := .split 25 q10Shape25T31 q10Shape25T42
private theorem q10Shape25T30OK : fastTreeOK (forms 25) 262144 14155776 q10Shape25T30=true := by
  change (fastTreeOK (forms 25) 262144 (14155776 ||| 2^25) q10Shape25T31 &&
    fastTreeOK (forms 25) (262144 ||| 2^25) 14155776 q10Shape25T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T31OK,q10Shape25T42OK⟩

private def q10Shape25T43 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape25T43OK : fastTreeOK (forms 25) 8650752 5767168 q10Shape25T43=true := by decide

private def q10Shape25T29 : Tree := .split 23 q10Shape25T30 q10Shape25T43
private theorem q10Shape25T29OK : fastTreeOK (forms 25) 262144 5767168 q10Shape25T29=true := by
  change (fastTreeOK (forms 25) 262144 (5767168 ||| 2^23) q10Shape25T30 &&
    fastTreeOK (forms 25) (262144 ||| 2^23) 5767168 q10Shape25T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T30OK,q10Shape25T43OK⟩

private def q10Shape25T44 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape25T44OK : fastTreeOK (forms 25) 4456448 1572864 q10Shape25T44=true := by decide

private def q10Shape25T28 : Tree := .split 22 q10Shape25T29 q10Shape25T44
private theorem q10Shape25T28OK : fastTreeOK (forms 25) 262144 1572864 q10Shape25T28=true := by
  change (fastTreeOK (forms 25) 262144 (1572864 ||| 2^22) q10Shape25T29 &&
    fastTreeOK (forms 25) (262144 ||| 2^22) 1572864 q10Shape25T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T29OK,q10Shape25T44OK⟩

private def q10Shape25T45 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape25T45OK : fastTreeOK (forms 25) 1310720 524288 q10Shape25T45=true := by decide

private def q10Shape25T27 : Tree := .split 20 q10Shape25T28 q10Shape25T45
private theorem q10Shape25T27OK : fastTreeOK (forms 25) 262144 524288 q10Shape25T27=true := by
  change (fastTreeOK (forms 25) 262144 (524288 ||| 2^20) q10Shape25T28 &&
    fastTreeOK (forms 25) (262144 ||| 2^20) 524288 q10Shape25T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T28OK,q10Shape25T45OK⟩

private def q10Shape25T46 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape25T46OK : fastTreeOK (forms 25) 786432 0 q10Shape25T46=true := by decide

private def q10Shape25T26 : Tree := .split 19 q10Shape25T27 q10Shape25T46
private theorem q10Shape25T26OK : fastTreeOK (forms 25) 262144 0 q10Shape25T26=true := by
  change (fastTreeOK (forms 25) 262144 (0 ||| 2^19) q10Shape25T27 &&
    fastTreeOK (forms 25) (262144 ||| 2^19) 0 q10Shape25T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T27OK,q10Shape25T46OK⟩

private def q10Shape25T0 : Tree := .split 18 q10Shape25T1 q10Shape25T26
private theorem q10Shape25T0OK : fastTreeOK (forms 25) 0 0 q10Shape25T0=true := by
  change (fastTreeOK (forms 25) 0 (0 ||| 2^18) q10Shape25T1 &&
    fastTreeOK (forms 25) (0 ||| 2^18) 0 q10Shape25T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape25T1OK,q10Shape25T26OK⟩


theorem q10Shape25_cover (b : Nat→Bool) (H : Ranked (adj (forms 25) b)) :
    ∃ u v w z t,Effective (adj (forms 25) b) (adj (forms 25) b) u v w z t :=
  checked_fastTree (forms 25) b H q10Shape25T0 q10Shape25T0OK

#print axioms q10Shape25_cover
end Graffiti384b.Q10
