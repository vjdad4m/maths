import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape26T0 : Tree := (.split 22 (.split 23 (.split 25 (.split 24 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 5)) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 8 9))) (.tip (.cover 0 1 7 8 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape26T0OK : fastTreeOK (forms 26) 0 0 q10Shape26T0=true := by decide


theorem q10Shape26_cover (b : Nat→Bool) (H : Ranked (adj (forms 26) b)) :
    ∃ u v w z t,Effective (adj (forms 26) b) (adj (forms 26) b) u v w z t :=
  checked_fastTree (forms 26) b H q10Shape26T0 q10Shape26T0OK

#print axioms q10Shape26_cover
end Graffiti384b.Q10
