import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape27T10 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape27T10OK : fastTreeOK (forms 27) 0 266473536 q10Shape27T10=true := by decide

private def q10Shape27T13 : Tree := (.split 5 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 11 (.split 14 (.tip (.cover 0 1 5 7 8)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 3 6 9)))) (.split 10 (.split 11 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 8)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 3 8 9)))))
private theorem q10Shape27T13OK : fastTreeOK (forms 27) 2097152 264376408 q10Shape27T13=true := by decide

private def q10Shape27T14 : Tree := (.split 5 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 4 5 7)) (.split 14 (.tip (.cover 0 1 5 7 8)) (.tip (.cover 0 2 3 4 9)))) (.tip (.cover 0 1 3 4 5))) (.split 10 (.split 11 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 5 6 7)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape27T14OK : fastTreeOK (forms 27) 2097168 264376392 q10Shape27T14=true := by decide

private def q10Shape27T12 : Tree := .split 4 q10Shape27T13 q10Shape27T14
private theorem q10Shape27T12OK : fastTreeOK (forms 27) 2097152 264376392 q10Shape27T12=true := by
  change (fastTreeOK (forms 27) 2097152 (264376392 ||| 2^4) q10Shape27T13 &&
    fastTreeOK (forms 27) (2097152 ||| 2^4) 264376392 q10Shape27T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T13OK,q10Shape27T14OK⟩

private def q10Shape27T15 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 4 5 6)) (.split 14 (.split 15 (.tip (.cover 0 1 5 6 8)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 5 8)))) (.split 11 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 5 6 7)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape27T15OK : fastTreeOK (forms 27) 2097160 264376384 q10Shape27T15=true := by decide

private def q10Shape27T11 : Tree := .split 3 q10Shape27T12 q10Shape27T15
private theorem q10Shape27T11OK : fastTreeOK (forms 27) 2097152 264376384 q10Shape27T11=true := by
  change (fastTreeOK (forms 27) 2097152 (264376384 ||| 2^3) q10Shape27T12 &&
    fastTreeOK (forms 27) (2097152 ||| 2^3) 264376384 q10Shape27T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T12OK,q10Shape27T15OK⟩

private def q10Shape27T9 : Tree := .split 21 q10Shape27T10 q10Shape27T11
private theorem q10Shape27T9OK : fastTreeOK (forms 27) 0 264376384 q10Shape27T9=true := by
  change (fastTreeOK (forms 27) 0 (264376384 ||| 2^21) q10Shape27T10 &&
    fastTreeOK (forms 27) (0 ||| 2^21) 264376384 q10Shape27T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T10OK,q10Shape27T11OK⟩

private def q10Shape27T19 : Tree := (.split 5 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 11 (.split 14 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 6 9)))) (.split 10 (.split 11 (.split 14 (.split 15 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 3 8 9)))))
private theorem q10Shape27T19OK : fastTreeOK (forms 27) 131072 266342488 q10Shape27T19=true := by decide

private def q10Shape27T20 : Tree := (.split 5 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 4 5 7)) (.split 14 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 7 8)))) (.tip (.cover 0 1 3 4 5))) (.split 10 (.split 11 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape27T20OK : fastTreeOK (forms 27) 131088 266342472 q10Shape27T20=true := by decide

private def q10Shape27T18 : Tree := .split 4 q10Shape27T19 q10Shape27T20
private theorem q10Shape27T18OK : fastTreeOK (forms 27) 131072 266342472 q10Shape27T18=true := by
  change (fastTreeOK (forms 27) 131072 (266342472 ||| 2^4) q10Shape27T19 &&
    fastTreeOK (forms 27) (131072 ||| 2^4) 266342472 q10Shape27T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T19OK,q10Shape27T20OK⟩

private def q10Shape27T21 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 4 5 6)) (.split 14 (.split 15 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8)))) (.split 11 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 1 4 6 7))) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 6 9)))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape27T21OK : fastTreeOK (forms 27) 131080 266342464 q10Shape27T21=true := by decide

private def q10Shape27T17 : Tree := .split 3 q10Shape27T18 q10Shape27T21
private theorem q10Shape27T17OK : fastTreeOK (forms 27) 131072 266342464 q10Shape27T17=true := by
  change (fastTreeOK (forms 27) 131072 (266342464 ||| 2^3) q10Shape27T18 &&
    fastTreeOK (forms 27) (131072 ||| 2^3) 266342464 q10Shape27T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T18OK,q10Shape27T21OK⟩

private def q10Shape27T22 : Tree := (.tip (.cover 0 2 3 4 5))
private theorem q10Shape27T22OK : fastTreeOK (forms 27) 2228224 264245312 q10Shape27T22=true := by decide

private def q10Shape27T16 : Tree := .split 21 q10Shape27T17 q10Shape27T22
private theorem q10Shape27T16OK : fastTreeOK (forms 27) 131072 264245312 q10Shape27T16=true := by
  change (fastTreeOK (forms 27) 131072 (264245312 ||| 2^21) q10Shape27T17 &&
    fastTreeOK (forms 27) (131072 ||| 2^21) 264245312 q10Shape27T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T17OK,q10Shape27T22OK⟩

private def q10Shape27T8 : Tree := .split 17 q10Shape27T9 q10Shape27T16
private theorem q10Shape27T8OK : fastTreeOK (forms 27) 0 264245312 q10Shape27T8=true := by
  change (fastTreeOK (forms 27) 0 (264245312 ||| 2^17) q10Shape27T9 &&
    fastTreeOK (forms 27) (0 ||| 2^17) 264245312 q10Shape27T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T9OK,q10Shape27T16OK⟩

private def q10Shape27T23 : Tree := (.split 17 (.split 21 (.split 3 (.split 4 (.split 5 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8)))) (.split 5 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 6 9)))) (.split 4 (.split 5 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 1 3 6 7))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape27T23OK : fastTreeOK (forms 27) 4096 264241216 q10Shape27T23=true := by decide

private def q10Shape27T7 : Tree := .split 12 q10Shape27T8 q10Shape27T23
private theorem q10Shape27T7OK : fastTreeOK (forms 27) 0 264241216 q10Shape27T7=true := by
  change (fastTreeOK (forms 27) 0 (264241216 ||| 2^12) q10Shape27T8 &&
    fastTreeOK (forms 27) (0 ||| 2^12) 264241216 q10Shape27T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T8OK,q10Shape27T23OK⟩

private def q10Shape27T24 : Tree := (.split 12 (.split 17 (.split 21 (.split 3 (.split 4 (.split 5 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 7))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 2 3 4 5)))
private theorem q10Shape27T24OK : fastTreeOK (forms 27) 64 264241152 q10Shape27T24=true := by decide

private def q10Shape27T6 : Tree := .split 6 q10Shape27T7 q10Shape27T24
private theorem q10Shape27T6OK : fastTreeOK (forms 27) 0 264241152 q10Shape27T6=true := by
  change (fastTreeOK (forms 27) 0 (264241152 ||| 2^6) q10Shape27T7 &&
    fastTreeOK (forms 27) (0 ||| 2^6) 264241152 q10Shape27T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T7OK,q10Shape27T24OK⟩

private def q10Shape27T25 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape27T25OK : fastTreeOK (forms 27) 134217728 130023424 q10Shape27T25=true := by decide

private def q10Shape27T5 : Tree := .split 27 q10Shape27T6 q10Shape27T25
private theorem q10Shape27T5OK : fastTreeOK (forms 27) 0 130023424 q10Shape27T5=true := by
  change (fastTreeOK (forms 27) 0 (130023424 ||| 2^27) q10Shape27T6 &&
    fastTreeOK (forms 27) (0 ||| 2^27) 130023424 q10Shape27T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T6OK,q10Shape27T25OK⟩

private def q10Shape27T26 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape27T26OK : fastTreeOK (forms 27) 67108864 62914560 q10Shape27T26=true := by decide

private def q10Shape27T4 : Tree := .split 26 q10Shape27T5 q10Shape27T26
private theorem q10Shape27T4OK : fastTreeOK (forms 27) 0 62914560 q10Shape27T4=true := by
  change (fastTreeOK (forms 27) 0 (62914560 ||| 2^26) q10Shape27T5 &&
    fastTreeOK (forms 27) (0 ||| 2^26) 62914560 q10Shape27T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T5OK,q10Shape27T26OK⟩

private def q10Shape27T27 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape27T27OK : fastTreeOK (forms 27) 16777216 46137344 q10Shape27T27=true := by decide

private def q10Shape27T3 : Tree := .split 24 q10Shape27T4 q10Shape27T27
private theorem q10Shape27T3OK : fastTreeOK (forms 27) 0 46137344 q10Shape27T3=true := by
  change (fastTreeOK (forms 27) 0 (46137344 ||| 2^24) q10Shape27T4 &&
    fastTreeOK (forms 27) (0 ||| 2^24) 46137344 q10Shape27T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T4OK,q10Shape27T27OK⟩

private def q10Shape27T28 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape27T28OK : fastTreeOK (forms 27) 33554432 12582912 q10Shape27T28=true := by decide

private def q10Shape27T2 : Tree := .split 25 q10Shape27T3 q10Shape27T28
private theorem q10Shape27T2OK : fastTreeOK (forms 27) 0 12582912 q10Shape27T2=true := by
  change (fastTreeOK (forms 27) 0 (12582912 ||| 2^25) q10Shape27T3 &&
    fastTreeOK (forms 27) (0 ||| 2^25) 12582912 q10Shape27T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T3OK,q10Shape27T28OK⟩

private def q10Shape27T29 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape27T29OK : fastTreeOK (forms 27) 8388608 4194304 q10Shape27T29=true := by decide

private def q10Shape27T1 : Tree := .split 23 q10Shape27T2 q10Shape27T29
private theorem q10Shape27T1OK : fastTreeOK (forms 27) 0 4194304 q10Shape27T1=true := by
  change (fastTreeOK (forms 27) 0 (4194304 ||| 2^23) q10Shape27T2 &&
    fastTreeOK (forms 27) (0 ||| 2^23) 4194304 q10Shape27T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T2OK,q10Shape27T29OK⟩

private def q10Shape27T30 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape27T30OK : fastTreeOK (forms 27) 4194304 0 q10Shape27T30=true := by decide

private def q10Shape27T0 : Tree := .split 22 q10Shape27T1 q10Shape27T30
private theorem q10Shape27T0OK : fastTreeOK (forms 27) 0 0 q10Shape27T0=true := by
  change (fastTreeOK (forms 27) 0 (0 ||| 2^22) q10Shape27T1 &&
    fastTreeOK (forms 27) (0 ||| 2^22) 0 q10Shape27T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape27T1OK,q10Shape27T30OK⟩


theorem q10Shape27_cover (b : Nat→Bool) (H : Ranked (adj (forms 27) b)) :
    ∃ u v w z t,Effective (adj (forms 27) b) (adj (forms 27) b) u v w z t :=
  checked_fastTree (forms 27) b H q10Shape27T0 q10Shape27T0OK

#print axioms q10Shape27_cover
end Graffiti384b.Q10
