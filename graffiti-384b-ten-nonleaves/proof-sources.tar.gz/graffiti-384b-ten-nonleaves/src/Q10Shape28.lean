import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape28T0 : Tree := (.split 22 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 5)) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape28T0OK : fastTreeOK (forms 28) 0 0 q10Shape28T0=true := by decide


theorem q10Shape28_cover (b : Nat→Bool) (H : Ranked (adj (forms 28) b)) :
    ∃ u v w z t,Effective (adj (forms 28) b) (adj (forms 28) b) u v w z t :=
  checked_fastTree (forms 28) b H q10Shape28T0 q10Shape28T0OK

#print axioms q10Shape28_cover
end Graffiti384b.Q10
