import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape3T10 : Tree := (.tip (.cover 0 1 2 3 4))
private theorem q10Shape3T10OK : fastTreeOK (forms 3) 0 268173312 q10Shape3T10=true := by decide

private def q10Shape3T12 : Tree := (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 2 3 4 7))))))
private theorem q10Shape3T12OK : fastTreeOK (forms 3) 67108864 201064480 q10Shape3T12=true := by decide

private def q10Shape3T13 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 2 3 4 9))) (.split 11 (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 2 3 4 7))))
private theorem q10Shape3T13OK : fastTreeOK (forms 3) 67108896 201064448 q10Shape3T13=true := by decide

private def q10Shape3T11 : Tree := .split 5 q10Shape3T12 q10Shape3T13
private theorem q10Shape3T11OK : fastTreeOK (forms 3) 67108864 201064448 q10Shape3T11=true := by
  change (fastTreeOK (forms 3) 67108864 (201064448 ||| 2^5) q10Shape3T12 &&
    fastTreeOK (forms 3) (67108864 ||| 2^5) 201064448 q10Shape3T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T12OK,q10Shape3T13OK⟩

private def q10Shape3T9 : Tree := .split 26 q10Shape3T10 q10Shape3T11
private theorem q10Shape3T9OK : fastTreeOK (forms 3) 0 201064448 q10Shape3T9=true := by
  change (fastTreeOK (forms 3) 0 (201064448 ||| 2^26) q10Shape3T10 &&
    fastTreeOK (forms 3) (0 ||| 2^26) 201064448 q10Shape3T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T10OK,q10Shape3T11OK⟩

private def q10Shape3T16 : Tree := (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7)))))) (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 2 3 4 7)))))
private theorem q10Shape3T16OK : fastTreeOK (forms 3) 33554432 234618912 q10Shape3T16=true := by decide

private def q10Shape3T17 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 5 6 8 9))))) (.split 11 (.split 12 (.split 16 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 2 3 4 7))) (.split 12 (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 2 3 4 7)))))
private theorem q10Shape3T17OK : fastTreeOK (forms 3) 33554464 234618880 q10Shape3T17=true := by decide

private def q10Shape3T15 : Tree := .split 5 q10Shape3T16 q10Shape3T17
private theorem q10Shape3T15OK : fastTreeOK (forms 3) 33554432 234618880 q10Shape3T15=true := by
  change (fastTreeOK (forms 3) 33554432 (234618880 ||| 2^5) q10Shape3T16 &&
    fastTreeOK (forms 3) (33554432 ||| 2^5) 234618880 q10Shape3T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T16OK,q10Shape3T17OK⟩

private def q10Shape3T18 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T18OK : fastTreeOK (forms 3) 100663296 167510016 q10Shape3T18=true := by decide

private def q10Shape3T14 : Tree := .split 26 q10Shape3T15 q10Shape3T18
private theorem q10Shape3T14OK : fastTreeOK (forms 3) 33554432 167510016 q10Shape3T14=true := by
  change (fastTreeOK (forms 3) 33554432 (167510016 ||| 2^26) q10Shape3T15 &&
    fastTreeOK (forms 3) (33554432 ||| 2^26) 167510016 q10Shape3T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T15OK,q10Shape3T18OK⟩

private def q10Shape3T8 : Tree := .split 25 q10Shape3T9 q10Shape3T14
private theorem q10Shape3T8OK : fastTreeOK (forms 3) 0 167510016 q10Shape3T8=true := by
  change (fastTreeOK (forms 3) 0 (167510016 ||| 2^25) q10Shape3T9 &&
    fastTreeOK (forms 3) (0 ||| 2^25) 167510016 q10Shape3T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T9OK,q10Shape3T14OK⟩

private def q10Shape3T22 : Tree := (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 6))))))
private theorem q10Shape3T22OK : fastTreeOK (forms 3) 16777216 251396128 q10Shape3T22=true := by decide

private def q10Shape3T23 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 2 3 4 9))) (.split 11 (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 2 3 4 6))))
private theorem q10Shape3T23OK : fastTreeOK (forms 3) 16777248 251396096 q10Shape3T23=true := by decide

private def q10Shape3T21 : Tree := .split 5 q10Shape3T22 q10Shape3T23
private theorem q10Shape3T21OK : fastTreeOK (forms 3) 16777216 251396096 q10Shape3T21=true := by
  change (fastTreeOK (forms 3) 16777216 (251396096 ||| 2^5) q10Shape3T22 &&
    fastTreeOK (forms 3) (16777216 ||| 2^5) 251396096 q10Shape3T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T22OK,q10Shape3T23OK⟩

private def q10Shape3T24 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape3T24OK : fastTreeOK (forms 3) 83886080 184287232 q10Shape3T24=true := by decide

private def q10Shape3T20 : Tree := .split 26 q10Shape3T21 q10Shape3T24
private theorem q10Shape3T20OK : fastTreeOK (forms 3) 16777216 184287232 q10Shape3T20=true := by
  change (fastTreeOK (forms 3) 16777216 (184287232 ||| 2^26) q10Shape3T21 &&
    fastTreeOK (forms 3) (16777216 ||| 2^26) 184287232 q10Shape3T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T21OK,q10Shape3T24OK⟩

private def q10Shape3T25 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T25OK : fastTreeOK (forms 3) 50331648 150732800 q10Shape3T25=true := by decide

private def q10Shape3T19 : Tree := .split 25 q10Shape3T20 q10Shape3T25
private theorem q10Shape3T19OK : fastTreeOK (forms 3) 16777216 150732800 q10Shape3T19=true := by
  change (fastTreeOK (forms 3) 16777216 (150732800 ||| 2^25) q10Shape3T20 &&
    fastTreeOK (forms 3) (16777216 ||| 2^25) 150732800 q10Shape3T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T20OK,q10Shape3T25OK⟩

private def q10Shape3T7 : Tree := .split 24 q10Shape3T8 q10Shape3T19
private theorem q10Shape3T7OK : fastTreeOK (forms 3) 0 150732800 q10Shape3T7=true := by
  change (fastTreeOK (forms 3) 0 (150732800 ||| 2^24) q10Shape3T8 &&
    fastTreeOK (forms 3) (0 ||| 2^24) 150732800 q10Shape3T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T8OK,q10Shape3T19OK⟩

private def q10Shape3T30 : Tree := (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6)))))) (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 6)))))
private theorem q10Shape3T30OK : fastTreeOK (forms 3) 8388608 259784736 q10Shape3T30=true := by decide

private def q10Shape3T31 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 5 7 8 9))))) (.split 11 (.split 12 (.split 16 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6)))) (.tip (.cover 0 2 3 4 6))) (.split 12 (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 6))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 2 3 4 6)))))
private theorem q10Shape3T31OK : fastTreeOK (forms 3) 8388640 259784704 q10Shape3T31=true := by decide

private def q10Shape3T29 : Tree := .split 5 q10Shape3T30 q10Shape3T31
private theorem q10Shape3T29OK : fastTreeOK (forms 3) 8388608 259784704 q10Shape3T29=true := by
  change (fastTreeOK (forms 3) 8388608 (259784704 ||| 2^5) q10Shape3T30 &&
    fastTreeOK (forms 3) (8388608 ||| 2^5) 259784704 q10Shape3T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T30OK,q10Shape3T31OK⟩

private def q10Shape3T32 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T32OK : fastTreeOK (forms 3) 75497472 192675840 q10Shape3T32=true := by decide

private def q10Shape3T28 : Tree := .split 26 q10Shape3T29 q10Shape3T32
private theorem q10Shape3T28OK : fastTreeOK (forms 3) 8388608 192675840 q10Shape3T28=true := by
  change (fastTreeOK (forms 3) 8388608 (192675840 ||| 2^26) q10Shape3T29 &&
    fastTreeOK (forms 3) (8388608 ||| 2^26) 192675840 q10Shape3T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T29OK,q10Shape3T32OK⟩

private def q10Shape3T33 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape3T33OK : fastTreeOK (forms 3) 41943040 159121408 q10Shape3T33=true := by decide

private def q10Shape3T27 : Tree := .split 25 q10Shape3T28 q10Shape3T33
private theorem q10Shape3T27OK : fastTreeOK (forms 3) 8388608 159121408 q10Shape3T27=true := by
  change (fastTreeOK (forms 3) 8388608 (159121408 ||| 2^25) q10Shape3T28 &&
    fastTreeOK (forms 3) (8388608 ||| 2^25) 159121408 q10Shape3T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T28OK,q10Shape3T33OK⟩

private def q10Shape3T34 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T34OK : fastTreeOK (forms 3) 25165824 142344192 q10Shape3T34=true := by decide

private def q10Shape3T26 : Tree := .split 24 q10Shape3T27 q10Shape3T34
private theorem q10Shape3T26OK : fastTreeOK (forms 3) 8388608 142344192 q10Shape3T26=true := by
  change (fastTreeOK (forms 3) 8388608 (142344192 ||| 2^24) q10Shape3T27 &&
    fastTreeOK (forms 3) (8388608 ||| 2^24) 142344192 q10Shape3T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T27OK,q10Shape3T34OK⟩

private def q10Shape3T6 : Tree := .split 23 q10Shape3T7 q10Shape3T26
private theorem q10Shape3T6OK : fastTreeOK (forms 3) 0 142344192 q10Shape3T6=true := by
  change (fastTreeOK (forms 3) 0 (142344192 ||| 2^23) q10Shape3T7 &&
    fastTreeOK (forms 3) (0 ||| 2^23) 142344192 q10Shape3T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T7OK,q10Shape3T26OK⟩

private def q10Shape3T40 : Tree := (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))))))
private theorem q10Shape3T40OK : fastTreeOK (forms 3) 2097152 266076192 q10Shape3T40=true := by decide

private def q10Shape3T41 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 2 3 4 9))) (.split 11 (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 2 3 4 5))))
private theorem q10Shape3T41OK : fastTreeOK (forms 3) 2097184 266076160 q10Shape3T41=true := by decide

private def q10Shape3T39 : Tree := .split 5 q10Shape3T40 q10Shape3T41
private theorem q10Shape3T39OK : fastTreeOK (forms 3) 2097152 266076160 q10Shape3T39=true := by
  change (fastTreeOK (forms 3) 2097152 (266076160 ||| 2^5) q10Shape3T40 &&
    fastTreeOK (forms 3) (2097152 ||| 2^5) 266076160 q10Shape3T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T40OK,q10Shape3T41OK⟩

private def q10Shape3T42 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape3T42OK : fastTreeOK (forms 3) 69206016 198967296 q10Shape3T42=true := by decide

private def q10Shape3T38 : Tree := .split 26 q10Shape3T39 q10Shape3T42
private theorem q10Shape3T38OK : fastTreeOK (forms 3) 2097152 198967296 q10Shape3T38=true := by
  change (fastTreeOK (forms 3) 2097152 (198967296 ||| 2^26) q10Shape3T39 &&
    fastTreeOK (forms 3) (2097152 ||| 2^26) 198967296 q10Shape3T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T39OK,q10Shape3T42OK⟩

private def q10Shape3T43 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T43OK : fastTreeOK (forms 3) 35651584 165412864 q10Shape3T43=true := by decide

private def q10Shape3T37 : Tree := .split 25 q10Shape3T38 q10Shape3T43
private theorem q10Shape3T37OK : fastTreeOK (forms 3) 2097152 165412864 q10Shape3T37=true := by
  change (fastTreeOK (forms 3) 2097152 (165412864 ||| 2^25) q10Shape3T38 &&
    fastTreeOK (forms 3) (2097152 ||| 2^25) 165412864 q10Shape3T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T38OK,q10Shape3T43OK⟩

private def q10Shape3T44 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape3T44OK : fastTreeOK (forms 3) 18874368 148635648 q10Shape3T44=true := by decide

private def q10Shape3T36 : Tree := .split 24 q10Shape3T37 q10Shape3T44
private theorem q10Shape3T36OK : fastTreeOK (forms 3) 2097152 148635648 q10Shape3T36=true := by
  change (fastTreeOK (forms 3) 2097152 (148635648 ||| 2^24) q10Shape3T37 &&
    fastTreeOK (forms 3) (2097152 ||| 2^24) 148635648 q10Shape3T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T37OK,q10Shape3T44OK⟩

private def q10Shape3T45 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T45OK : fastTreeOK (forms 3) 10485760 140247040 q10Shape3T45=true := by decide

private def q10Shape3T35 : Tree := .split 23 q10Shape3T36 q10Shape3T45
private theorem q10Shape3T35OK : fastTreeOK (forms 3) 2097152 140247040 q10Shape3T35=true := by
  change (fastTreeOK (forms 3) 2097152 (140247040 ||| 2^23) q10Shape3T36 &&
    fastTreeOK (forms 3) (2097152 ||| 2^23) 140247040 q10Shape3T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T36OK,q10Shape3T45OK⟩

private def q10Shape3T5 : Tree := .split 21 q10Shape3T6 q10Shape3T35
private theorem q10Shape3T5OK : fastTreeOK (forms 3) 0 140247040 q10Shape3T5=true := by
  change (fastTreeOK (forms 3) 0 (140247040 ||| 2^21) q10Shape3T6 &&
    fastTreeOK (forms 3) (0 ||| 2^21) 140247040 q10Shape3T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T6OK,q10Shape3T35OK⟩

private def q10Shape3T52 : Tree := (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5)))))) (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5)))))
private theorem q10Shape3T52OK : fastTreeOK (forms 3) 1048576 267124768 q10Shape3T52=true := by decide

private def q10Shape3T53 : Tree := (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 6 7 8 9))) (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9))))) (.split 11 (.split 12 (.split 16 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5)))) (.tip (.cover 0 2 3 4 5))) (.split 12 (.split 16 (.split 17 (.tip (.small 1)) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5)))))
private theorem q10Shape3T53OK : fastTreeOK (forms 3) 1048608 267124736 q10Shape3T53=true := by decide

private def q10Shape3T51 : Tree := .split 5 q10Shape3T52 q10Shape3T53
private theorem q10Shape3T51OK : fastTreeOK (forms 3) 1048576 267124736 q10Shape3T51=true := by
  change (fastTreeOK (forms 3) 1048576 (267124736 ||| 2^5) q10Shape3T52 &&
    fastTreeOK (forms 3) (1048576 ||| 2^5) 267124736 q10Shape3T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T52OK,q10Shape3T53OK⟩

private def q10Shape3T54 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T54OK : fastTreeOK (forms 3) 68157440 200015872 q10Shape3T54=true := by decide

private def q10Shape3T50 : Tree := .split 26 q10Shape3T51 q10Shape3T54
private theorem q10Shape3T50OK : fastTreeOK (forms 3) 1048576 200015872 q10Shape3T50=true := by
  change (fastTreeOK (forms 3) 1048576 (200015872 ||| 2^26) q10Shape3T51 &&
    fastTreeOK (forms 3) (1048576 ||| 2^26) 200015872 q10Shape3T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T51OK,q10Shape3T54OK⟩

private def q10Shape3T55 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape3T55OK : fastTreeOK (forms 3) 34603008 166461440 q10Shape3T55=true := by decide

private def q10Shape3T49 : Tree := .split 25 q10Shape3T50 q10Shape3T55
private theorem q10Shape3T49OK : fastTreeOK (forms 3) 1048576 166461440 q10Shape3T49=true := by
  change (fastTreeOK (forms 3) 1048576 (166461440 ||| 2^25) q10Shape3T50 &&
    fastTreeOK (forms 3) (1048576 ||| 2^25) 166461440 q10Shape3T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T50OK,q10Shape3T55OK⟩

private def q10Shape3T56 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T56OK : fastTreeOK (forms 3) 17825792 149684224 q10Shape3T56=true := by decide

private def q10Shape3T48 : Tree := .split 24 q10Shape3T49 q10Shape3T56
private theorem q10Shape3T48OK : fastTreeOK (forms 3) 1048576 149684224 q10Shape3T48=true := by
  change (fastTreeOK (forms 3) 1048576 (149684224 ||| 2^24) q10Shape3T49 &&
    fastTreeOK (forms 3) (1048576 ||| 2^24) 149684224 q10Shape3T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T49OK,q10Shape3T56OK⟩

private def q10Shape3T57 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape3T57OK : fastTreeOK (forms 3) 9437184 141295616 q10Shape3T57=true := by decide

private def q10Shape3T47 : Tree := .split 23 q10Shape3T48 q10Shape3T57
private theorem q10Shape3T47OK : fastTreeOK (forms 3) 1048576 141295616 q10Shape3T47=true := by
  change (fastTreeOK (forms 3) 1048576 (141295616 ||| 2^23) q10Shape3T48 &&
    fastTreeOK (forms 3) (1048576 ||| 2^23) 141295616 q10Shape3T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T48OK,q10Shape3T57OK⟩

private def q10Shape3T58 : Tree := (.tip (.cover 0 1 5 6 7))
private theorem q10Shape3T58OK : fastTreeOK (forms 3) 3145728 139198464 q10Shape3T58=true := by decide

private def q10Shape3T46 : Tree := .split 21 q10Shape3T47 q10Shape3T58
private theorem q10Shape3T46OK : fastTreeOK (forms 3) 1048576 139198464 q10Shape3T46=true := by
  change (fastTreeOK (forms 3) 1048576 (139198464 ||| 2^21) q10Shape3T47 &&
    fastTreeOK (forms 3) (1048576 ||| 2^21) 139198464 q10Shape3T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T47OK,q10Shape3T58OK⟩

private def q10Shape3T4 : Tree := .split 20 q10Shape3T5 q10Shape3T46
private theorem q10Shape3T4OK : fastTreeOK (forms 3) 0 139198464 q10Shape3T4=true := by
  change (fastTreeOK (forms 3) 0 (139198464 ||| 2^20) q10Shape3T5 &&
    fastTreeOK (forms 3) (0 ||| 2^20) 139198464 q10Shape3T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T5OK,q10Shape3T46OK⟩

private def q10Shape3T59 : Tree := (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 5 (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 6 7 8)))
private theorem q10Shape3T59OK : fastTreeOK (forms 3) 134217728 4980736 q10Shape3T59=true := by decide

private def q10Shape3T3 : Tree := .split 27 q10Shape3T4 q10Shape3T59
private theorem q10Shape3T3OK : fastTreeOK (forms 3) 0 4980736 q10Shape3T3=true := by
  change (fastTreeOK (forms 3) 0 (4980736 ||| 2^27) q10Shape3T4 &&
    fastTreeOK (forms 3) (0 ||| 2^27) 4980736 q10Shape3T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T4OK,q10Shape3T59OK⟩

private def q10Shape3T63 : Tree := (.split 23 (.split 24 (.split 25 (.split 26 (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 5 6)))) (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 1 3 5 6))))) (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 3 5 6)))) (.tip (.cover 0 1 2 5 6)))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape3T63OK : fastTreeOK (forms 3) 4194304 138149888 q10Shape3T63=true := by decide

private def q10Shape3T64 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape3T64OK : fastTreeOK (forms 3) 6291456 136052736 q10Shape3T64=true := by decide

private def q10Shape3T62 : Tree := .split 21 q10Shape3T63 q10Shape3T64
private theorem q10Shape3T62OK : fastTreeOK (forms 3) 4194304 136052736 q10Shape3T62=true := by
  change (fastTreeOK (forms 3) 4194304 (136052736 ||| 2^21) q10Shape3T63 &&
    fastTreeOK (forms 3) (4194304 ||| 2^21) 136052736 q10Shape3T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T63OK,q10Shape3T64OK⟩

private def q10Shape3T65 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape3T65OK : fastTreeOK (forms 3) 5242880 135004160 q10Shape3T65=true := by decide

private def q10Shape3T61 : Tree := .split 20 q10Shape3T62 q10Shape3T65
private theorem q10Shape3T61OK : fastTreeOK (forms 3) 4194304 135004160 q10Shape3T61=true := by
  change (fastTreeOK (forms 3) 4194304 (135004160 ||| 2^20) q10Shape3T62 &&
    fastTreeOK (forms 3) (4194304 ||| 2^20) 135004160 q10Shape3T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T62OK,q10Shape3T65OK⟩

private def q10Shape3T66 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape3T66OK : fastTreeOK (forms 3) 138412032 786432 q10Shape3T66=true := by decide

private def q10Shape3T60 : Tree := .split 27 q10Shape3T61 q10Shape3T66
private theorem q10Shape3T60OK : fastTreeOK (forms 3) 4194304 786432 q10Shape3T60=true := by
  change (fastTreeOK (forms 3) 4194304 (786432 ||| 2^27) q10Shape3T61 &&
    fastTreeOK (forms 3) (4194304 ||| 2^27) 786432 q10Shape3T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T61OK,q10Shape3T66OK⟩

private def q10Shape3T2 : Tree := .split 22 q10Shape3T3 q10Shape3T60
private theorem q10Shape3T2OK : fastTreeOK (forms 3) 0 786432 q10Shape3T2=true := by
  change (fastTreeOK (forms 3) 0 (786432 ||| 2^22) q10Shape3T3 &&
    fastTreeOK (forms 3) (0 ||| 2^22) 786432 q10Shape3T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T3OK,q10Shape3T60OK⟩

private def q10Shape3T71 : Tree := (.split 23 (.split 24 (.split 25 (.split 26 (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 5 6)))) (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9))) (.tip (.cover 0 1 3 5 6))))) (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 6 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 1 4 5 6))) (.tip (.cover 0 1 3 5 6)))) (.tip (.cover 0 1 2 5 6)))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 6 8))) (.tip (.cover 0 1 5 6 9)))
private theorem q10Shape3T71OK : fastTreeOK (forms 3) 524288 141819904 q10Shape3T71=true := by decide

private def q10Shape3T72 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape3T72OK : fastTreeOK (forms 3) 2621440 139722752 q10Shape3T72=true := by decide

private def q10Shape3T70 : Tree := .split 21 q10Shape3T71 q10Shape3T72
private theorem q10Shape3T70OK : fastTreeOK (forms 3) 524288 139722752 q10Shape3T70=true := by
  change (fastTreeOK (forms 3) 524288 (139722752 ||| 2^21) q10Shape3T71 &&
    fastTreeOK (forms 3) (524288 ||| 2^21) 139722752 q10Shape3T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T71OK,q10Shape3T72OK⟩

private def q10Shape3T73 : Tree := (.tip (.cover 0 1 5 6 9))
private theorem q10Shape3T73OK : fastTreeOK (forms 3) 1572864 138674176 q10Shape3T73=true := by decide

private def q10Shape3T69 : Tree := .split 20 q10Shape3T70 q10Shape3T73
private theorem q10Shape3T69OK : fastTreeOK (forms 3) 524288 138674176 q10Shape3T69=true := by
  change (fastTreeOK (forms 3) 524288 (138674176 ||| 2^20) q10Shape3T70 &&
    fastTreeOK (forms 3) (524288 ||| 2^20) 138674176 q10Shape3T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T70OK,q10Shape3T73OK⟩

private def q10Shape3T74 : Tree := (.tip (.cover 0 1 5 6 8))
private theorem q10Shape3T74OK : fastTreeOK (forms 3) 134742016 4456448 q10Shape3T74=true := by decide

private def q10Shape3T68 : Tree := .split 27 q10Shape3T69 q10Shape3T74
private theorem q10Shape3T68OK : fastTreeOK (forms 3) 524288 4456448 q10Shape3T68=true := by
  change (fastTreeOK (forms 3) 524288 (4456448 ||| 2^27) q10Shape3T69 &&
    fastTreeOK (forms 3) (524288 ||| 2^27) 4456448 q10Shape3T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T69OK,q10Shape3T74OK⟩

private def q10Shape3T75 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape3T75OK : fastTreeOK (forms 3) 4718592 262144 q10Shape3T75=true := by decide

private def q10Shape3T67 : Tree := .split 22 q10Shape3T68 q10Shape3T75
private theorem q10Shape3T67OK : fastTreeOK (forms 3) 524288 262144 q10Shape3T67=true := by
  change (fastTreeOK (forms 3) 524288 (262144 ||| 2^22) q10Shape3T68 &&
    fastTreeOK (forms 3) (524288 ||| 2^22) 262144 q10Shape3T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T68OK,q10Shape3T75OK⟩

private def q10Shape3T1 : Tree := .split 19 q10Shape3T2 q10Shape3T67
private theorem q10Shape3T1OK : fastTreeOK (forms 3) 0 262144 q10Shape3T1=true := by
  change (fastTreeOK (forms 3) 0 (262144 ||| 2^19) q10Shape3T2 &&
    fastTreeOK (forms 3) (0 ||| 2^19) 262144 q10Shape3T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T2OK,q10Shape3T67OK⟩

private def q10Shape3T81 : Tree := (.split 23 (.split 24 (.split 25 (.split 26 (.split 5 (.split 6 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7)))) (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 1 3 5 7))))) (.split 6 (.split 11 (.split 12 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 0 5 7 8 9)))) (.split 12 (.split 16 (.tip (.small 1)) (.tip (.cover 0 1 4 5 7))) (.tip (.cover 0 1 3 5 7)))) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 6 7 8))) (.tip (.cover 0 1 6 7 9)))
private theorem q10Shape3T81OK : fastTreeOK (forms 3) 262144 142082048 q10Shape3T81=true := by decide

private def q10Shape3T82 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape3T82OK : fastTreeOK (forms 3) 2359296 139984896 q10Shape3T82=true := by decide

private def q10Shape3T80 : Tree := .split 21 q10Shape3T81 q10Shape3T82
private theorem q10Shape3T80OK : fastTreeOK (forms 3) 262144 139984896 q10Shape3T80=true := by
  change (fastTreeOK (forms 3) 262144 (139984896 ||| 2^21) q10Shape3T81 &&
    fastTreeOK (forms 3) (262144 ||| 2^21) 139984896 q10Shape3T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T81OK,q10Shape3T82OK⟩

private def q10Shape3T83 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape3T83OK : fastTreeOK (forms 3) 1310720 138936320 q10Shape3T83=true := by decide

private def q10Shape3T79 : Tree := .split 20 q10Shape3T80 q10Shape3T83
private theorem q10Shape3T79OK : fastTreeOK (forms 3) 262144 138936320 q10Shape3T79=true := by
  change (fastTreeOK (forms 3) 262144 (138936320 ||| 2^20) q10Shape3T80 &&
    fastTreeOK (forms 3) (262144 ||| 2^20) 138936320 q10Shape3T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T80OK,q10Shape3T83OK⟩

private def q10Shape3T84 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape3T84OK : fastTreeOK (forms 3) 134479872 4718592 q10Shape3T84=true := by decide

private def q10Shape3T78 : Tree := .split 27 q10Shape3T79 q10Shape3T84
private theorem q10Shape3T78OK : fastTreeOK (forms 3) 262144 4718592 q10Shape3T78=true := by
  change (fastTreeOK (forms 3) 262144 (4718592 ||| 2^27) q10Shape3T79 &&
    fastTreeOK (forms 3) (262144 ||| 2^27) 4718592 q10Shape3T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T79OK,q10Shape3T84OK⟩

private def q10Shape3T85 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape3T85OK : fastTreeOK (forms 3) 4456448 524288 q10Shape3T85=true := by decide

private def q10Shape3T77 : Tree := .split 22 q10Shape3T78 q10Shape3T85
private theorem q10Shape3T77OK : fastTreeOK (forms 3) 262144 524288 q10Shape3T77=true := by
  change (fastTreeOK (forms 3) 262144 (524288 ||| 2^22) q10Shape3T78 &&
    fastTreeOK (forms 3) (262144 ||| 2^22) 524288 q10Shape3T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T78OK,q10Shape3T85OK⟩

private def q10Shape3T86 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape3T86OK : fastTreeOK (forms 3) 786432 0 q10Shape3T86=true := by decide

private def q10Shape3T76 : Tree := .split 19 q10Shape3T77 q10Shape3T86
private theorem q10Shape3T76OK : fastTreeOK (forms 3) 262144 0 q10Shape3T76=true := by
  change (fastTreeOK (forms 3) 262144 (0 ||| 2^19) q10Shape3T77 &&
    fastTreeOK (forms 3) (262144 ||| 2^19) 0 q10Shape3T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T77OK,q10Shape3T86OK⟩

private def q10Shape3T0 : Tree := .split 18 q10Shape3T1 q10Shape3T76
private theorem q10Shape3T0OK : fastTreeOK (forms 3) 0 0 q10Shape3T0=true := by
  change (fastTreeOK (forms 3) 0 (0 ||| 2^18) q10Shape3T1 &&
    fastTreeOK (forms 3) (0 ||| 2^18) 0 q10Shape3T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape3T1OK,q10Shape3T76OK⟩


theorem q10Shape3_cover (b : Nat→Bool) (H : Ranked (adj (forms 3) b)) :
    ∃ u v w z t,Effective (adj (forms 3) b) (adj (forms 3) b) u v w z t :=
  checked_fastTree (forms 3) b H q10Shape3T0 q10Shape3T0OK

#print axioms q10Shape3_cover
end Graffiti384b.Q10
