import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape4T7 : Tree := (.tip (.small 1))
private theorem q10Shape4T7OK : fastTreeOK (forms 4) 0 47253536 q10Shape4T7=true := by decide

private def q10Shape4T10 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 1 5 7 9)) (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 8 9))))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape4T10OK : fastTreeOK (forms 4) 1048576 46204984 q10Shape4T10=true := by decide

private def q10Shape4T11 : Tree := (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 9)) (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 4 8 9)))) (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 4 7 8 9)))) (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape4T11OK : fastTreeOK (forms 4) 1048592 46204968 q10Shape4T11=true := by decide

private def q10Shape4T9 : Tree := .split 4 q10Shape4T10 q10Shape4T11
private theorem q10Shape4T9OK : fastTreeOK (forms 4) 1048576 46204968 q10Shape4T9=true := by
  change (fastTreeOK (forms 4) 1048576 (46204968 ||| 2^4) q10Shape4T10 &&
    fastTreeOK (forms 4) (1048576 ||| 2^4) 46204968 q10Shape4T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T10OK,q10Shape4T11OK⟩

private def q10Shape4T12 : Tree := (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 4 5 9))) (.split 14 (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 0 1 5 6 9))) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 3 6 8 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape4T12OK : fastTreeOK (forms 4) 1048584 46204960 q10Shape4T12=true := by decide

private def q10Shape4T8 : Tree := .split 3 q10Shape4T9 q10Shape4T12
private theorem q10Shape4T8OK : fastTreeOK (forms 4) 1048576 46204960 q10Shape4T8=true := by
  change (fastTreeOK (forms 4) 1048576 (46204960 ||| 2^3) q10Shape4T9 &&
    fastTreeOK (forms 4) (1048576 ||| 2^3) 46204960 q10Shape4T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T9OK,q10Shape4T12OK⟩

private def q10Shape4T6 : Tree := .split 20 q10Shape4T7 q10Shape4T8
private theorem q10Shape4T6OK : fastTreeOK (forms 4) 0 46204960 q10Shape4T6=true := by
  change (fastTreeOK (forms 4) 0 (46204960 ||| 2^20) q10Shape4T7 &&
    fastTreeOK (forms 4) (0 ||| 2^20) 46204960 q10Shape4T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T7OK,q10Shape4T8OK⟩

private def q10Shape4T16 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 0 (.tip (.small 1)) (.tip (.cover 0 3 5 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape4T16OK : fastTreeOK (forms 4) 65536 47188024 q10Shape4T16=true := by decide

private def q10Shape4T17 : Tree := (.split 9 (.split 10 (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.split 14 (.tip (.cover 0 5 7 8 9)) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape4T17OK : fastTreeOK (forms 4) 65552 47188008 q10Shape4T17=true := by decide

private def q10Shape4T15 : Tree := .split 4 q10Shape4T16 q10Shape4T17
private theorem q10Shape4T15OK : fastTreeOK (forms 4) 65536 47188008 q10Shape4T15=true := by
  change (fastTreeOK (forms 4) 65536 (47188008 ||| 2^4) q10Shape4T16 &&
    fastTreeOK (forms 4) (65536 ||| 2^4) 47188008 q10Shape4T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T16OK,q10Shape4T17OK⟩

private def q10Shape4T18 : Tree := (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 0 (.tip (.small 1)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.split 14 (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape4T18OK : fastTreeOK (forms 4) 65544 47188000 q10Shape4T18=true := by decide

private def q10Shape4T14 : Tree := .split 3 q10Shape4T15 q10Shape4T18
private theorem q10Shape4T14OK : fastTreeOK (forms 4) 65536 47188000 q10Shape4T14=true := by
  change (fastTreeOK (forms 4) 65536 (47188000 ||| 2^3) q10Shape4T15 &&
    fastTreeOK (forms 4) (65536 ||| 2^3) 47188000 q10Shape4T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T15OK,q10Shape4T18OK⟩

private def q10Shape4T19 : Tree := (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 2 3 8 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 1 6 7 8 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape4T19OK : fastTreeOK (forms 4) 1114112 46139424 q10Shape4T19=true := by decide

private def q10Shape4T13 : Tree := .split 20 q10Shape4T14 q10Shape4T19
private theorem q10Shape4T13OK : fastTreeOK (forms 4) 65536 46139424 q10Shape4T13=true := by
  change (fastTreeOK (forms 4) 65536 (46139424 ||| 2^20) q10Shape4T14 &&
    fastTreeOK (forms 4) (65536 ||| 2^20) 46139424 q10Shape4T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T14OK,q10Shape4T19OK⟩

private def q10Shape4T5 : Tree := .split 16 q10Shape4T6 q10Shape4T13
private theorem q10Shape4T5OK : fastTreeOK (forms 4) 0 46139424 q10Shape4T5=true := by
  change (fastTreeOK (forms 4) 0 (46139424 ||| 2^16) q10Shape4T6 &&
    fastTreeOK (forms 4) (0 ||| 2^16) 46139424 q10Shape4T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T6OK,q10Shape4T13OK⟩

private def q10Shape4T24 : Tree := (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 1 3 6 7 9))) (.tip (.cover 0 1 5 8 9))))) (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 0 (.tip (.small 1)) (.tip (.cover 1 3 6 7 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))
private theorem q10Shape4T24OK : fastTreeOK (forms 4) 2048 47251512 q10Shape4T24=true := by decide

private def q10Shape4T25 : Tree := (.split 9 (.split 10 (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 5 7 8 9))) (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9))))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))
private theorem q10Shape4T25OK : fastTreeOK (forms 4) 2064 47251496 q10Shape4T25=true := by decide

private def q10Shape4T23 : Tree := .split 4 q10Shape4T24 q10Shape4T25
private theorem q10Shape4T23OK : fastTreeOK (forms 4) 2048 47251496 q10Shape4T23=true := by
  change (fastTreeOK (forms 4) 2048 (47251496 ||| 2^4) q10Shape4T24 &&
    fastTreeOK (forms 4) (2048 ||| 2^4) 47251496 q10Shape4T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T24OK,q10Shape4T25OK⟩

private def q10Shape4T26 : Tree := (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 8 9))))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9))))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 4 6 8 9)))) (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape4T26OK : fastTreeOK (forms 4) 2056 47251488 q10Shape4T26=true := by decide

private def q10Shape4T22 : Tree := .split 3 q10Shape4T23 q10Shape4T26
private theorem q10Shape4T22OK : fastTreeOK (forms 4) 2048 47251488 q10Shape4T22=true := by
  change (fastTreeOK (forms 4) 2048 (47251488 ||| 2^3) q10Shape4T23 &&
    fastTreeOK (forms 4) (2048 ||| 2^3) 47251488 q10Shape4T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T23OK,q10Shape4T26OK⟩

private def q10Shape4T27 : Tree := (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9))))
private theorem q10Shape4T27OK : fastTreeOK (forms 4) 1050624 46202912 q10Shape4T27=true := by decide

private def q10Shape4T21 : Tree := .split 20 q10Shape4T22 q10Shape4T27
private theorem q10Shape4T21OK : fastTreeOK (forms 4) 2048 46202912 q10Shape4T21=true := by
  change (fastTreeOK (forms 4) 2048 (46202912 ||| 2^20) q10Shape4T22 &&
    fastTreeOK (forms 4) (2048 ||| 2^20) 46202912 q10Shape4T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T22OK,q10Shape4T27OK⟩

private def q10Shape4T28 : Tree := (.split 20 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9)))) (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))))
private theorem q10Shape4T28OK : fastTreeOK (forms 4) 67584 46137376 q10Shape4T28=true := by decide

private def q10Shape4T20 : Tree := .split 16 q10Shape4T21 q10Shape4T28
private theorem q10Shape4T20OK : fastTreeOK (forms 4) 2048 46137376 q10Shape4T20=true := by
  change (fastTreeOK (forms 4) 2048 (46137376 ||| 2^16) q10Shape4T21 &&
    fastTreeOK (forms 4) (2048 ||| 2^16) 46137376 q10Shape4T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T21OK,q10Shape4T28OK⟩

private def q10Shape4T4 : Tree := .split 11 q10Shape4T5 q10Shape4T20
private theorem q10Shape4T4OK : fastTreeOK (forms 4) 0 46137376 q10Shape4T4=true := by
  change (fastTreeOK (forms 4) 0 (46137376 ||| 2^11) q10Shape4T5 &&
    fastTreeOK (forms 4) (0 ||| 2^11) 46137376 q10Shape4T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T5OK,q10Shape4T20OK⟩

private def q10Shape4T36 : Tree := (.split 14 (.split 15 (.tip (.cover 0 1 5 8 9)) (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 0 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9))) (.tip (.cover 0 1 5 8 9))))) (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 0 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape4T36OK : fastTreeOK (forms 4) 32 47255064 q10Shape4T36=true := by decide

private def q10Shape4T37 : Tree := (.split 14 (.split 15 (.split 18 (.tip (.cover 0 1 7 8 9)) (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9)))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 0 5 7 8 9))) (.split 15 (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9))))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 1 4 8 9))))
private theorem q10Shape4T37OK : fastTreeOK (forms 4) 1056 47254040 q10Shape4T37=true := by decide

private def q10Shape4T35 : Tree := .split 10 q10Shape4T36 q10Shape4T37
private theorem q10Shape4T35OK : fastTreeOK (forms 4) 32 47254040 q10Shape4T35=true := by
  change (fastTreeOK (forms 4) 32 (47254040 ||| 2^10) q10Shape4T36 &&
    fastTreeOK (forms 4) (32 ||| 2^10) 47254040 q10Shape4T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T36OK,q10Shape4T37OK⟩

private def q10Shape4T38 : Tree := (.split 10 (.split 14 (.split 15 (.split 18 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9))))) (.tip (.cover 0 1 5 8 9))) (.split 18 (.split 19 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 1 2 6 7 9))))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 4 6 8 9)))) (.split 15 (.tip (.cover 0 5 6 8 9)) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape4T38OK : fastTreeOK (forms 4) 544 47253528 q10Shape4T38=true := by decide

private def q10Shape4T34 : Tree := .split 9 q10Shape4T35 q10Shape4T38
private theorem q10Shape4T34OK : fastTreeOK (forms 4) 32 47253528 q10Shape4T34=true := by
  change (fastTreeOK (forms 4) 32 (47253528 ||| 2^9) q10Shape4T35 &&
    fastTreeOK (forms 4) (32 ||| 2^9) 47253528 q10Shape4T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T35OK,q10Shape4T38OK⟩

private def q10Shape4T39 : Tree := (.tip (.cover 0 1 2 6 9))
private theorem q10Shape4T39OK : fastTreeOK (forms 4) 48 47253512 q10Shape4T39=true := by decide

private def q10Shape4T33 : Tree := .split 4 q10Shape4T34 q10Shape4T39
private theorem q10Shape4T33OK : fastTreeOK (forms 4) 32 47253512 q10Shape4T33=true := by
  change (fastTreeOK (forms 4) 32 (47253512 ||| 2^4) q10Shape4T34 &&
    fastTreeOK (forms 4) (32 ||| 2^4) 47253512 q10Shape4T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T34OK,q10Shape4T39OK⟩

private def q10Shape4T40 : Tree := (.tip (.cover 0 1 2 7 9))
private theorem q10Shape4T40OK : fastTreeOK (forms 4) 40 47253504 q10Shape4T40=true := by decide

private def q10Shape4T32 : Tree := .split 3 q10Shape4T33 q10Shape4T40
private theorem q10Shape4T32OK : fastTreeOK (forms 4) 32 47253504 q10Shape4T32=true := by
  change (fastTreeOK (forms 4) 32 (47253504 ||| 2^3) q10Shape4T33 &&
    fastTreeOK (forms 4) (32 ||| 2^3) 47253504 q10Shape4T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T33OK,q10Shape4T40OK⟩

private def q10Shape4T41 : Tree := (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 3 4 8 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))
private theorem q10Shape4T41OK : fastTreeOK (forms 4) 1048608 46204928 q10Shape4T41=true := by decide

private def q10Shape4T31 : Tree := .split 20 q10Shape4T32 q10Shape4T41
private theorem q10Shape4T31OK : fastTreeOK (forms 4) 32 46204928 q10Shape4T31=true := by
  change (fastTreeOK (forms 4) 32 (46204928 ||| 2^20) q10Shape4T32 &&
    fastTreeOK (forms 4) (32 ||| 2^20) 46204928 q10Shape4T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T32OK,q10Shape4T41OK⟩

private def q10Shape4T42 : Tree := (.split 20 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape4T42OK : fastTreeOK (forms 4) 65568 46139392 q10Shape4T42=true := by decide

private def q10Shape4T30 : Tree := .split 16 q10Shape4T31 q10Shape4T42
private theorem q10Shape4T30OK : fastTreeOK (forms 4) 32 46139392 q10Shape4T30=true := by
  change (fastTreeOK (forms 4) 32 (46139392 ||| 2^16) q10Shape4T31 &&
    fastTreeOK (forms 4) (32 ||| 2^16) 46139392 q10Shape4T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T31OK,q10Shape4T42OK⟩

private def q10Shape4T43 : Tree := (.split 16 (.split 20 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.split 20 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 1 6 7 8 9))))
private theorem q10Shape4T43OK : fastTreeOK (forms 4) 2080 46137344 q10Shape4T43=true := by decide

private def q10Shape4T29 : Tree := .split 11 q10Shape4T30 q10Shape4T43
private theorem q10Shape4T29OK : fastTreeOK (forms 4) 32 46137344 q10Shape4T29=true := by
  change (fastTreeOK (forms 4) 32 (46137344 ||| 2^11) q10Shape4T30 &&
    fastTreeOK (forms 4) (32 ||| 2^11) 46137344 q10Shape4T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T30OK,q10Shape4T43OK⟩

private def q10Shape4T3 : Tree := .split 5 q10Shape4T4 q10Shape4T29
private theorem q10Shape4T3OK : fastTreeOK (forms 4) 0 46137344 q10Shape4T3=true := by
  change (fastTreeOK (forms 4) 0 (46137344 ||| 2^5) q10Shape4T4 &&
    fastTreeOK (forms 4) (0 ||| 2^5) 46137344 q10Shape4T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T4OK,q10Shape4T29OK⟩

private def q10Shape4T44 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape4T44OK : fastTreeOK (forms 4) 33554432 12582912 q10Shape4T44=true := by decide

private def q10Shape4T2 : Tree := .split 25 q10Shape4T3 q10Shape4T44
private theorem q10Shape4T2OK : fastTreeOK (forms 4) 0 12582912 q10Shape4T2=true := by
  change (fastTreeOK (forms 4) 0 (12582912 ||| 2^25) q10Shape4T3 &&
    fastTreeOK (forms 4) (0 ||| 2^25) 12582912 q10Shape4T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T3OK,q10Shape4T44OK⟩

private def q10Shape4T45 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape4T45OK : fastTreeOK (forms 4) 8388608 4194304 q10Shape4T45=true := by decide

private def q10Shape4T1 : Tree := .split 23 q10Shape4T2 q10Shape4T45
private theorem q10Shape4T1OK : fastTreeOK (forms 4) 0 4194304 q10Shape4T1=true := by
  change (fastTreeOK (forms 4) 0 (4194304 ||| 2^23) q10Shape4T2 &&
    fastTreeOK (forms 4) (0 ||| 2^23) 4194304 q10Shape4T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T2OK,q10Shape4T45OK⟩

private def q10Shape4T46 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape4T46OK : fastTreeOK (forms 4) 4194304 0 q10Shape4T46=true := by decide

private def q10Shape4T0 : Tree := .split 22 q10Shape4T1 q10Shape4T46
private theorem q10Shape4T0OK : fastTreeOK (forms 4) 0 0 q10Shape4T0=true := by
  change (fastTreeOK (forms 4) 0 (0 ||| 2^22) q10Shape4T1 &&
    fastTreeOK (forms 4) (0 ||| 2^22) 0 q10Shape4T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape4T1OK,q10Shape4T46OK⟩


theorem q10Shape4_cover (b : Nat→Bool) (H : Ranked (adj (forms 4) b)) :
    ∃ u v w z t,Effective (adj (forms 4) b) (adj (forms 4) b) u v w z t :=
  checked_fastTree (forms 4) b H q10Shape4T0 q10Shape4T0OK

#print axioms q10Shape4_cover
end Graffiti384b.Q10
