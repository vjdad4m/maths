import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape5T10 : Tree := (.split 16 (.split 17 (.tip (.cover 0 1 5 6 7)) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 3 8 9)))) (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 1 5 6 7))))) (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.tip (.cover 0 1 4 5 7)) (.tip (.cover 0 2 3 8 9)))) (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 6)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 3 4 5))) (.tip (.cover 0 1 2 8 9))))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 6 7))))
private theorem q10Shape5T10OK : fastTreeOK (forms 5) 0 264247392 q10Shape5T10=true := by decide

private def q10Shape5T12 : Tree := (.split 17 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 6 7)))))
private theorem q10Shape5T12OK : fastTreeOK (forms 5) 4096 264308832 q10Shape5T12=true := by decide

private def q10Shape5T13 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 8 9)))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 6 7)))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape5T13OK : fastTreeOK (forms 5) 69632 264243296 q10Shape5T13=true := by decide

private def q10Shape5T11 : Tree := .split 16 q10Shape5T12 q10Shape5T13
private theorem q10Shape5T11OK : fastTreeOK (forms 5) 4096 264243296 q10Shape5T11=true := by
  change (fastTreeOK (forms 5) 4096 (264243296 ||| 2^16) q10Shape5T12 &&
    fastTreeOK (forms 5) (4096 ||| 2^16) 264243296 q10Shape5T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T12OK,q10Shape5T13OK⟩

private def q10Shape5T9 : Tree := .split 12 q10Shape5T10 q10Shape5T11
private theorem q10Shape5T9OK : fastTreeOK (forms 5) 0 264243296 q10Shape5T9=true := by
  change (fastTreeOK (forms 5) 0 (264243296 ||| 2^12) q10Shape5T10 &&
    fastTreeOK (forms 5) (0 ||| 2^12) 264243296 q10Shape5T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T10OK,q10Shape5T11OK⟩

private def q10Shape5T17 : Tree := (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 1 5 7 8)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 8)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9))))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape5T17OK : fastTreeOK (forms 5) 2048 264441952 q10Shape5T17=true := by decide

private def q10Shape5T18 : Tree := (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.split 9 (.split 10 (.split 14 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9)))) (.split 4 (.split 9 (.split 10 (.split 14 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 8 9)))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape5T18OK : fastTreeOK (forms 5) 133120 264310880 q10Shape5T18=true := by decide

private def q10Shape5T16 : Tree := .split 17 q10Shape5T17 q10Shape5T18
private theorem q10Shape5T16OK : fastTreeOK (forms 5) 2048 264310880 q10Shape5T16=true := by
  change (fastTreeOK (forms 5) 2048 (264310880 ||| 2^17) q10Shape5T17 &&
    fastTreeOK (forms 5) (2048 ||| 2^17) 264310880 q10Shape5T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T17OK,q10Shape5T18OK⟩

private def q10Shape5T19 : Tree := (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape5T19OK : fastTreeOK (forms 5) 67584 264245344 q10Shape5T19=true := by decide

private def q10Shape5T15 : Tree := .split 16 q10Shape5T16 q10Shape5T19
private theorem q10Shape5T15OK : fastTreeOK (forms 5) 2048 264245344 q10Shape5T15=true := by
  change (fastTreeOK (forms 5) 2048 (264245344 ||| 2^16) q10Shape5T16 &&
    fastTreeOK (forms 5) (2048 ||| 2^16) 264245344 q10Shape5T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T16OK,q10Shape5T19OK⟩

private def q10Shape5T20 : Tree := (.tip (.cover 0 1 3 6 7))
private theorem q10Shape5T20OK : fastTreeOK (forms 5) 6144 264241248 q10Shape5T20=true := by decide

private def q10Shape5T14 : Tree := .split 12 q10Shape5T15 q10Shape5T20
private theorem q10Shape5T14OK : fastTreeOK (forms 5) 2048 264241248 q10Shape5T14=true := by
  change (fastTreeOK (forms 5) 2048 (264241248 ||| 2^12) q10Shape5T15 &&
    fastTreeOK (forms 5) (2048 ||| 2^12) 264241248 q10Shape5T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T15OK,q10Shape5T20OK⟩

private def q10Shape5T8 : Tree := .split 11 q10Shape5T9 q10Shape5T14
private theorem q10Shape5T8OK : fastTreeOK (forms 5) 0 264241248 q10Shape5T8=true := by
  change (fastTreeOK (forms 5) 0 (264241248 ||| 2^11) q10Shape5T9 &&
    fastTreeOK (forms 5) (0 ||| 2^11) 264241248 q10Shape5T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T9OK,q10Shape5T14OK⟩

private def q10Shape5T24 : Tree := (.split 17 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 1 5 7 9)) (.tip (.cover 0 3 4 8 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 9)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 4 5 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))))
private theorem q10Shape5T24OK : fastTreeOK (forms 5) 64 264312864 q10Shape5T24=true := by decide

private def q10Shape5T25 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 9)) (.split 14 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 7 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 6 9))) (.tip (.cover 0 1 4 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape5T25OK : fastTreeOK (forms 5) 65600 264247328 q10Shape5T25=true := by decide

private def q10Shape5T23 : Tree := .split 16 q10Shape5T24 q10Shape5T25
private theorem q10Shape5T23OK : fastTreeOK (forms 5) 64 264247328 q10Shape5T23=true := by
  change (fastTreeOK (forms 5) 64 (264247328 ||| 2^16) q10Shape5T24 &&
    fastTreeOK (forms 5) (64 ||| 2^16) 264247328 q10Shape5T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T24OK,q10Shape5T25OK⟩

private def q10Shape5T26 : Tree := (.split 16 (.split 17 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.tip (.cover 1 5 6 7 9))) (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 1 4 6 7))))
private theorem q10Shape5T26OK : fastTreeOK (forms 5) 4160 264243232 q10Shape5T26=true := by decide

private def q10Shape5T22 : Tree := .split 12 q10Shape5T23 q10Shape5T26
private theorem q10Shape5T22OK : fastTreeOK (forms 5) 64 264243232 q10Shape5T22=true := by
  change (fastTreeOK (forms 5) 64 (264243232 ||| 2^12) q10Shape5T23 &&
    fastTreeOK (forms 5) (64 ||| 2^12) 264243232 q10Shape5T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T23OK,q10Shape5T26OK⟩

private def q10Shape5T29 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))))
private theorem q10Shape5T29OK : fastTreeOK (forms 5) 2112 264310816 q10Shape5T29=true := by decide

private def q10Shape5T30 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape5T30OK : fastTreeOK (forms 5) 67648 264245280 q10Shape5T30=true := by decide

private def q10Shape5T28 : Tree := .split 16 q10Shape5T29 q10Shape5T30
private theorem q10Shape5T28OK : fastTreeOK (forms 5) 2112 264245280 q10Shape5T28=true := by
  change (fastTreeOK (forms 5) 2112 (264245280 ||| 2^16) q10Shape5T29 &&
    fastTreeOK (forms 5) (2112 ||| 2^16) 264245280 q10Shape5T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T29OK,q10Shape5T30OK⟩

private def q10Shape5T31 : Tree := (.tip (.cover 0 1 3 6 7))
private theorem q10Shape5T31OK : fastTreeOK (forms 5) 6208 264241184 q10Shape5T31=true := by decide

private def q10Shape5T27 : Tree := .split 12 q10Shape5T28 q10Shape5T31
private theorem q10Shape5T27OK : fastTreeOK (forms 5) 2112 264241184 q10Shape5T27=true := by
  change (fastTreeOK (forms 5) 2112 (264241184 ||| 2^12) q10Shape5T28 &&
    fastTreeOK (forms 5) (2112 ||| 2^12) 264241184 q10Shape5T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T28OK,q10Shape5T31OK⟩

private def q10Shape5T21 : Tree := .split 11 q10Shape5T22 q10Shape5T27
private theorem q10Shape5T21OK : fastTreeOK (forms 5) 64 264241184 q10Shape5T21=true := by
  change (fastTreeOK (forms 5) 64 (264241184 ||| 2^11) q10Shape5T22 &&
    fastTreeOK (forms 5) (64 ||| 2^11) 264241184 q10Shape5T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T22OK,q10Shape5T27OK⟩

private def q10Shape5T7 : Tree := .split 6 q10Shape5T8 q10Shape5T21
private theorem q10Shape5T7OK : fastTreeOK (forms 5) 0 264241184 q10Shape5T7=true := by
  change (fastTreeOK (forms 5) 0 (264241184 ||| 2^6) q10Shape5T8 &&
    fastTreeOK (forms 5) (0 ||| 2^6) 264241184 q10Shape5T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T8OK,q10Shape5T21OK⟩

private def q10Shape5T37 : Tree := (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 14 (.tip (.cover 0 1 5 7 8)) (.tip (.cover 0 3 4 8 9)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 1 5 6 8)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 1 4 5 8))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 6 7)))
private theorem q10Shape5T37OK : fastTreeOK (forms 5) 32 264443968 q10Shape5T37=true := by decide

private def q10Shape5T38 : Tree := (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 1 4 5 8)) (.split 14 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 7 8)))) (.split 10 (.split 14 (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 1 4 6 8))) (.tip (.cover 0 1 4 7 8))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.split 3 (.split 4 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 6 7))))
private theorem q10Shape5T38OK : fastTreeOK (forms 5) 131104 264312896 q10Shape5T38=true := by decide

private def q10Shape5T36 : Tree := .split 17 q10Shape5T37 q10Shape5T38
private theorem q10Shape5T36OK : fastTreeOK (forms 5) 32 264312896 q10Shape5T36=true := by
  change (fastTreeOK (forms 5) 32 (264312896 ||| 2^17) q10Shape5T37 &&
    fastTreeOK (forms 5) (32 ||| 2^17) 264312896 q10Shape5T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T37OK,q10Shape5T38OK⟩

private def q10Shape5T39 : Tree := (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 6 7))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape5T39OK : fastTreeOK (forms 5) 65568 264247360 q10Shape5T39=true := by decide

private def q10Shape5T35 : Tree := .split 16 q10Shape5T36 q10Shape5T39
private theorem q10Shape5T35OK : fastTreeOK (forms 5) 32 264247360 q10Shape5T35=true := by
  change (fastTreeOK (forms 5) 32 (264247360 ||| 2^16) q10Shape5T36 &&
    fastTreeOK (forms 5) (32 ||| 2^16) 264247360 q10Shape5T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T36OK,q10Shape5T39OK⟩

private def q10Shape5T41 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.split 9 (.split 10 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 6 8))) (.tip (.cover 0 1 3 7 8))) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.split 3 (.split 4 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 5 6 7)))) (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 3 4 5 8)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 2 3 4 5))))
private theorem q10Shape5T41OK : fastTreeOK (forms 5) 4128 264308800 q10Shape5T41=true := by decide

private def q10Shape5T42 : Tree := (.split 17 (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 1 4 6 7)))
private theorem q10Shape5T42OK : fastTreeOK (forms 5) 69664 264243264 q10Shape5T42=true := by decide

private def q10Shape5T40 : Tree := .split 16 q10Shape5T41 q10Shape5T42
private theorem q10Shape5T40OK : fastTreeOK (forms 5) 4128 264243264 q10Shape5T40=true := by
  change (fastTreeOK (forms 5) 4128 (264243264 ||| 2^16) q10Shape5T41 &&
    fastTreeOK (forms 5) (4128 ||| 2^16) 264243264 q10Shape5T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T41OK,q10Shape5T42OK⟩

private def q10Shape5T34 : Tree := .split 12 q10Shape5T35 q10Shape5T40
private theorem q10Shape5T34OK : fastTreeOK (forms 5) 32 264243264 q10Shape5T34=true := by
  change (fastTreeOK (forms 5) 32 (264243264 ||| 2^12) q10Shape5T35 &&
    fastTreeOK (forms 5) (32 ||| 2^12) 264243264 q10Shape5T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T35OK,q10Shape5T40OK⟩

private def q10Shape5T43 : Tree := (.split 12 (.split 16 (.split 17 (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 5 6 7))) (.split 20 (.split 21 (.split 3 (.split 4 (.tip (.cover 0 1 3 4 5)) (.tip (.cover 0 1 2 6 9))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 2 3 4 5))) (.tip (.cover 0 6 7 8 9)))) (.split 17 (.tip (.cover 1 5 6 7 8)) (.tip (.cover 0 1 4 6 7)))) (.tip (.cover 0 1 3 6 7)))
private theorem q10Shape5T43OK : fastTreeOK (forms 5) 2080 264241216 q10Shape5T43=true := by decide

private def q10Shape5T33 : Tree := .split 11 q10Shape5T34 q10Shape5T43
private theorem q10Shape5T33OK : fastTreeOK (forms 5) 32 264241216 q10Shape5T33=true := by
  change (fastTreeOK (forms 5) 32 (264241216 ||| 2^11) q10Shape5T34 &&
    fastTreeOK (forms 5) (32 ||| 2^11) 264241216 q10Shape5T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T34OK,q10Shape5T43OK⟩

private def q10Shape5T44 : Tree := (.tip (.cover 0 1 2 6 7))
private theorem q10Shape5T44OK : fastTreeOK (forms 5) 96 264241152 q10Shape5T44=true := by decide

private def q10Shape5T32 : Tree := .split 6 q10Shape5T33 q10Shape5T44
private theorem q10Shape5T32OK : fastTreeOK (forms 5) 32 264241152 q10Shape5T32=true := by
  change (fastTreeOK (forms 5) 32 (264241152 ||| 2^6) q10Shape5T33 &&
    fastTreeOK (forms 5) (32 ||| 2^6) 264241152 q10Shape5T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T33OK,q10Shape5T44OK⟩

private def q10Shape5T6 : Tree := .split 5 q10Shape5T7 q10Shape5T32
private theorem q10Shape5T6OK : fastTreeOK (forms 5) 0 264241152 q10Shape5T6=true := by
  change (fastTreeOK (forms 5) 0 (264241152 ||| 2^5) q10Shape5T7 &&
    fastTreeOK (forms 5) (0 ||| 2^5) 264241152 q10Shape5T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T7OK,q10Shape5T32OK⟩

private def q10Shape5T45 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape5T45OK : fastTreeOK (forms 5) 67108864 197132288 q10Shape5T45=true := by decide

private def q10Shape5T5 : Tree := .split 26 q10Shape5T6 q10Shape5T45
private theorem q10Shape5T5OK : fastTreeOK (forms 5) 0 197132288 q10Shape5T5=true := by
  change (fastTreeOK (forms 5) 0 (197132288 ||| 2^26) q10Shape5T6 &&
    fastTreeOK (forms 5) (0 ||| 2^26) 197132288 q10Shape5T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T6OK,q10Shape5T45OK⟩

private def q10Shape5T46 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape5T46OK : fastTreeOK (forms 5) 33554432 163577856 q10Shape5T46=true := by decide

private def q10Shape5T4 : Tree := .split 25 q10Shape5T5 q10Shape5T46
private theorem q10Shape5T4OK : fastTreeOK (forms 5) 0 163577856 q10Shape5T4=true := by
  change (fastTreeOK (forms 5) 0 (163577856 ||| 2^25) q10Shape5T5 &&
    fastTreeOK (forms 5) (0 ||| 2^25) 163577856 q10Shape5T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T5OK,q10Shape5T46OK⟩

private def q10Shape5T47 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape5T47OK : fastTreeOK (forms 5) 16777216 146800640 q10Shape5T47=true := by decide

private def q10Shape5T3 : Tree := .split 24 q10Shape5T4 q10Shape5T47
private theorem q10Shape5T3OK : fastTreeOK (forms 5) 0 146800640 q10Shape5T3=true := by
  change (fastTreeOK (forms 5) 0 (146800640 ||| 2^24) q10Shape5T4 &&
    fastTreeOK (forms 5) (0 ||| 2^24) 146800640 q10Shape5T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T4OK,q10Shape5T47OK⟩

private def q10Shape5T48 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape5T48OK : fastTreeOK (forms 5) 8388608 138412032 q10Shape5T48=true := by decide

private def q10Shape5T2 : Tree := .split 23 q10Shape5T3 q10Shape5T48
private theorem q10Shape5T2OK : fastTreeOK (forms 5) 0 138412032 q10Shape5T2=true := by
  change (fastTreeOK (forms 5) 0 (138412032 ||| 2^23) q10Shape5T3 &&
    fastTreeOK (forms 5) (0 ||| 2^23) 138412032 q10Shape5T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T3OK,q10Shape5T48OK⟩

private def q10Shape5T49 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape5T49OK : fastTreeOK (forms 5) 4194304 134217728 q10Shape5T49=true := by decide

private def q10Shape5T1 : Tree := .split 22 q10Shape5T2 q10Shape5T49
private theorem q10Shape5T1OK : fastTreeOK (forms 5) 0 134217728 q10Shape5T1=true := by
  change (fastTreeOK (forms 5) 0 (134217728 ||| 2^22) q10Shape5T2 &&
    fastTreeOK (forms 5) (0 ||| 2^22) 134217728 q10Shape5T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T2OK,q10Shape5T49OK⟩

private def q10Shape5T50 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape5T50OK : fastTreeOK (forms 5) 134217728 0 q10Shape5T50=true := by decide

private def q10Shape5T0 : Tree := .split 27 q10Shape5T1 q10Shape5T50
private theorem q10Shape5T0OK : fastTreeOK (forms 5) 0 0 q10Shape5T0=true := by
  change (fastTreeOK (forms 5) 0 (0 ||| 2^27) q10Shape5T1 &&
    fastTreeOK (forms 5) (0 ||| 2^27) 0 q10Shape5T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape5T1OK,q10Shape5T50OK⟩


theorem q10Shape5_cover (b : Nat→Bool) (H : Ranked (adj (forms 5) b)) :
    ∃ u v w z t,Effective (adj (forms 5) b) (adj (forms 5) b) u v w z t :=
  checked_fastTree (forms 5) b H q10Shape5T0 q10Shape5T0OK

#print axioms q10Shape5_cover
end Graffiti384b.Q10
