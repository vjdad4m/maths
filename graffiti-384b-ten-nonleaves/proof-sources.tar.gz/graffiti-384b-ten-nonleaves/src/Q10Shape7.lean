import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape7T0 : Tree := (.tip (.small 0))
private theorem q10Shape7T0OK : fastTreeOK (forms 7) 0 0 q10Shape7T0=true := by decide


theorem q10Shape7_cover (b : Nat→Bool) (H : Ranked (adj (forms 7) b)) :
    ∃ u v w z t,Effective (adj (forms 7) b) (adj (forms 7) b) u v w z t :=
  checked_fastTree (forms 7) b H q10Shape7T0 q10Shape7T0OK

#print axioms q10Shape7_cover
end Graffiti384b.Q10
