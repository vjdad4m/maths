import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape8T0 : Tree := (.split 22 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 9)))))))
private theorem q10Shape8T0OK : fastTreeOK (forms 8) 0 0 q10Shape8T0=true := by decide


theorem q10Shape8_cover (b : Nat→Bool) (H : Ranked (adj (forms 8) b)) :
    ∃ u v w z t,Effective (adj (forms 8) b) (adj (forms 8) b) u v w z t :=
  checked_fastTree (forms 8) b H q10Shape8T0 q10Shape8T0OK

#print axioms q10Shape8_cover
end Graffiti384b.Q10
