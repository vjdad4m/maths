import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape9T1 : Tree := (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 1 2 8 9))))))))
private theorem q10Shape9T1OK : fastTreeOK (forms 9) 0 1 q10Shape9T1=true := by decide

private def q10Shape9T3 : Tree := (.split 4 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 22 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 2 4 6 8 9)))) (.split 2 (.split 13 (.tip (.small 0)) (.tip (.cover 2 5 6 8 9))) (.tip (.cover 0 2 6 8 9))))))))
private theorem q10Shape9T3OK : fastTreeOK (forms 9) 1 8 q10Shape9T3=true := by decide

private def q10Shape9T5 : Tree := (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 22 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 2 4 7 8 9)))) (.split 2 (.split 13 (.tip (.small 0)) (.tip (.cover 2 5 7 8 9))) (.tip (.cover 0 2 7 8 9)))))))
private theorem q10Shape9T5OK : fastTreeOK (forms 9) 9 16 q10Shape9T5=true := by decide

private def q10Shape9T7 : Tree := (.split 10 (.tip (.small 1)) (.split 22 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 2 4 7 8 9)))) (.split 2 (.split 13 (.tip (.small 0)) (.tip (.cover 2 5 7 8 9))) (.tip (.cover 0 1 2 8 9))))))
private theorem q10Shape9T7OK : fastTreeOK (forms 9) 25 512 q10Shape9T7=true := by decide

private def q10Shape9T8 : Tree := (.split 10 (.split 22 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 2 4 6 8 9)))) (.split 2 (.split 13 (.tip (.small 0)) (.tip (.cover 2 5 6 8 9))) (.tip (.cover 0 1 2 8 9))))) (.split 1 (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 3 8 9)))) (.split 2 (.split 7 (.tip (.small 0)) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 0 1 2 8 9)))))
private theorem q10Shape9T8OK : fastTreeOK (forms 9) 537 0 q10Shape9T8=true := by decide

private def q10Shape9T6 : Tree := .split 9 q10Shape9T7 q10Shape9T8
private theorem q10Shape9T6OK : fastTreeOK (forms 9) 25 0 q10Shape9T6=true := by
  change (fastTreeOK (forms 9) 25 (0 ||| 2^9) q10Shape9T7 &&
    fastTreeOK (forms 9) (25 ||| 2^9) 0 q10Shape9T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape9T7OK,q10Shape9T8OK⟩

private def q10Shape9T4 : Tree := .split 4 q10Shape9T5 q10Shape9T6
private theorem q10Shape9T4OK : fastTreeOK (forms 9) 9 0 q10Shape9T4=true := by
  change (fastTreeOK (forms 9) 9 (0 ||| 2^4) q10Shape9T5 &&
    fastTreeOK (forms 9) (9 ||| 2^4) 0 q10Shape9T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape9T5OK,q10Shape9T6OK⟩

private def q10Shape9T2 : Tree := .split 3 q10Shape9T3 q10Shape9T4
private theorem q10Shape9T2OK : fastTreeOK (forms 9) 1 0 q10Shape9T2=true := by
  change (fastTreeOK (forms 9) 1 (0 ||| 2^3) q10Shape9T3 &&
    fastTreeOK (forms 9) (1 ||| 2^3) 0 q10Shape9T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape9T3OK,q10Shape9T4OK⟩

private def q10Shape9T0 : Tree := .split 0 q10Shape9T1 q10Shape9T2
private theorem q10Shape9T0OK : fastTreeOK (forms 9) 0 0 q10Shape9T0=true := by
  change (fastTreeOK (forms 9) 0 (0 ||| 2^0) q10Shape9T1 &&
    fastTreeOK (forms 9) (0 ||| 2^0) 0 q10Shape9T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape9T1OK,q10Shape9T2OK⟩


theorem q10Shape9_cover (b : Nat→Bool) (H : Ranked (adj (forms 9) b)) :
    ∃ u v w z t,Effective (adj (forms 9) b) (adj (forms 9) b) u v w z t :=
  checked_fastTree (forms 9) b H q10Shape9T0 q10Shape9T0OK

#print axioms q10Shape9_cover
end Graffiti384b.Q10
