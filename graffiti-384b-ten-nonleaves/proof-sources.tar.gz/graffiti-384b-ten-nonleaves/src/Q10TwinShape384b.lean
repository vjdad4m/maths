import Q10MaskKernel384b
namespace Graffiti384b.Q10
set_option maxHeartbeats 2000000
set_option maxRecDepth 100000
theorem true_twins_shape11 (bits : Nat→Bool) :
    score (adj (forms 11) bits) 0 = score (adj (forms 11) bits) 1 := by
  rfl

#print axioms true_twins_shape11
end Graffiti384b.Q10
